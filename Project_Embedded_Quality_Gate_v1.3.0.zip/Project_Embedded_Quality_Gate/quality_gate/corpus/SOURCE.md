# Corpus provenance

`content_defense_corpus.json` is derived from **microsoft/BIPIA** — *"Benchmarking and Defending
Against Indirect Prompt Injection Attacks on Large Language Models"* — pulled from the GitHub
Junkyard bare mirror `BIPIA.git` at HEAD.

| Role | Donor file | Use here |
|---|---|---|
| Attack cases | `benchmark/code_attack_test.json` | Indirect prompt-injection payloads, grouped by attack class. Each becomes a case labelled `attack`; the content-defense detector is expected to flag it. |
| Control cases | `benchmark/text_attack_test.json` | Ordinary task prompts by category. Each becomes a case labelled `benign`; a flag here is a false positive. |

**Licence:** MIT (Microsoft Corporation). The donor `LICENSE` is reproduced in
`THIRD-PARTY-NOTICES.md` at the repository root. The payload text is used unmodified so that
detection results remain comparable with the published benchmark; only the surrounding case
structure (ids, labels, classes) is ours.

**Why a control set matters.** Before this corpus existed, `run_offline_evaluation` compared the
code against five hand-written expectations and then set `grounding_rate = 1.0 if all(...) else 0.0`.
A false-positive rate is only meaningful against content that *should not* fire, which is what the
benign half supplies. Exact digests of both donor files are recorded in `corpus_manifest.json`, so a
future run can prove it measured against the same corpus.

---

# Held-out corpus provenance

`heldout_corpus.json` exists because the corpus above cannot measure generalisation. Its cases come
from the BIPIA **test** splits, and the detector's signals were developed against those same cases, so
a rate measured there shows how well the detector fits what it was built on. That is worth knowing and
it is not a detection claim.

| Role | Donor | Donor file | Cases |
|---|---|---|---|
| Held-out attacks | **BIPIA** | `benchmark/code_attack_train.json` | 50 |
| Held-out benign, same domain | **BIPIA** | `benchmark/text_attack_train.json` | 75 |
| Held-out benign, different domain | **llmail-inject-challenge** | `src/agent/data/fp_tests.json` | 203 |

**Disjointness is asserted, not assumed.** The corpus was built only after checking that no case text
appears in `content_defense_corpus.json`, exactly or after whitespace normalisation, and
`quality_gate/tests/test_project_application.py` re-checks both on every test run. Exact donor digests
are in `heldout_manifest.json`.

**Why the third source matters.** BIPIA's benign controls are task prompts, written in the same
register as its attacks. The LLMail-Inject false-positive tests are ordinary business email — a
different content domain entirely — so a false positive there says something a same-domain control set
cannot: that the detector fires on ordinary prose. It fired on none of the 203.

**Floors, not gates.** `quality_gate/config/thresholds.json` declares `heldout.min_attack_recall` 0.80
and `heldout.max_false_positive_rate` 0.10. They were written down before the measurement was read,
and they are deliberately looser than the tuned-corpus thresholds because this corpus is unseen. They
are reported floors: `evaluate` fails closed if the corpus is missing, but the measured rates do not
block a release, because turning a new measurement into a release gate changes the release semantics
of an audited programme and is the owner's decision.

**Licence:** both donors are MIT (Microsoft Corporation); the texts are reproduced in
`THIRD-PARTY-NOTICES.md` §3 and §7.
