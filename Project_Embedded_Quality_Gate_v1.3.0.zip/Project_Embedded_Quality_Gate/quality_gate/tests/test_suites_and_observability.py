"""The verification suites themselves, plus tracing and metrics."""
import unittest
from pathlib import Path

from embedded_quality_gate.adversarial import run_adversarial_suite
from embedded_quality_gate.e2e import run_e2e_suite
from embedded_quality_gate.metrics import INDETERMINATE, MetricsCollector
from embedded_quality_gate.tracing import Tracer

REPO = Path(__file__).resolve().parents[2]


class SuiteTests(unittest.TestCase):
    def test_every_adversarial_case_is_blocked(self):
        result = run_adversarial_suite(REPO)
        self.assertEqual(result["case_count"], 7)
        unblocked = [c["id"] for c in result["cases"] if not c["blocked"]]
        self.assertEqual(unblocked, [], f"controls did not block: {unblocked}")

    def test_every_e2e_scenario_passes(self):
        result = run_e2e_suite()
        self.assertEqual(result["scenario_count"], 6)
        failed = [s["id"] for s in result["scenarios"] if not s["passed"]]
        self.assertEqual(failed, [], f"scenarios failed: {failed}")


class ObservabilityTests(unittest.TestCase):
    def test_error_span_records_the_exception_type(self):
        tracer = Tracer("run-1")
        with self.assertRaises(PermissionError):
            with tracer.span("apply_guardrail"):
                raise PermissionError("denied")
        span = tracer.spans[-1]
        self.assertEqual(span.status, "ERROR")
        self.assertEqual(span.attributes["error.type"], "PermissionError")
        self.assertIsNotNone(span.duration_ms)

    def test_nested_spans_carry_parents(self):
        tracer = Tracer("run-1")
        with tracer.span("invoke_agent"):
            with tracer.span("execute_tool"):
                pass
        outer, inner = tracer.spans
        self.assertIsNone(outer.parent_span_id)
        self.assertEqual(inner.parent_span_id, outer.span_id)

    def test_unmeasured_rates_are_none_not_zero(self):
        metrics = MetricsCollector()
        snapshot = metrics.snapshot()
        self.assertIsNone(snapshot["tool_failure_rate"])
        self.assertIsNone(snapshot["accuracy"]["false_positive_rate"])

    def test_unpriced_cost_is_indeterminate_not_zero(self):
        self.assertEqual(MetricsCollector().snapshot()["cost"], INDETERMINATE)
