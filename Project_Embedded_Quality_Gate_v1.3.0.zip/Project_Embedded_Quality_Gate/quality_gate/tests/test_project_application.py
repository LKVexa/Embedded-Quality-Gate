"""Tests for the gate's application to the generic project repository.

Covers the units added by work order
``Project_Embedded_Quality_Gate-20260904-2207``: the held-out evaluation corpus,
the SARIF writer, the manifest-drift analyzer, the release-manifest verifier, the
packaging guard, and the approval-request generator.
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.analyzers import check_manifest_drift
from embedded_quality_gate.evaluation import run_heldout_evaluation, run_offline_evaluation
from embedded_quality_gate.release import BLOCKED, evaluate_readiness
from embedded_quality_gate.sarif import LEVEL_BY_SEVERITY, SARIF_VERSION, build_sarif_log, write_sarif

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = REPO / "quality_gate" / "scripts"


def run_script(name, cwd=None):
    # noqa reason on every subprocess call in this module: the executable is
    # sys.executable and every argument is a path this test just built.
    return subprocess.run([sys.executable, str(SCRIPTS / name)], cwd=str(cwd or REPO),  # noqa: S603
                          capture_output=True, text=True)


class HeldOutCorpusTests(unittest.TestCase):
    def setUp(self):
        self.tuned = json.loads((REPO / "quality_gate" / "corpus" / "content_defense_corpus.json").read_text(encoding="utf-8"))
        self.heldout = json.loads((REPO / "quality_gate" / "corpus" / "heldout_corpus.json").read_text(encoding="utf-8"))

    def test_heldout_corpus_is_disjoint_from_the_tuned_corpus(self):
        """A held-out corpus that shares cases with the tuned one measures nothing."""
        tuned = {c["text"] for c in self.tuned["cases"]}
        overlap = [c["id"] for c in self.heldout["cases"] if c["text"] in tuned]
        self.assertEqual(overlap, [], f"held-out cases also present in the tuned corpus: {overlap[:5]}")

    def test_heldout_corpus_is_disjoint_after_whitespace_normalisation(self):
        def norm(text):
            return " ".join(text.split())
        tuned = {norm(c["text"]) for c in self.tuned["cases"]}
        overlap = [c["id"] for c in self.heldout["cases"] if norm(c["text"]) in tuned]
        self.assertEqual(overlap, [])

    def test_heldout_corpus_carries_both_labels_and_multiple_sources(self):
        labels = {c["label"] for c in self.heldout["cases"]}
        self.assertEqual(labels, {"attack", "benign"})
        sources = {c["source"] for c in self.heldout["cases"]}
        self.assertGreaterEqual(len(sources), 3, "generalisation needs more than one donor")

    def test_manifest_digests_match_the_shipped_corpus(self):
        manifest = json.loads((REPO / "quality_gate" / "corpus" / "heldout_manifest.json").read_text(encoding="utf-8"))
        entry = manifest["corpora"][0]
        actual = hashlib.sha256((REPO / entry["path"]).read_bytes()).hexdigest()
        self.assertEqual(entry["sha256"], actual)
        self.assertEqual(entry["disjoint_from"]["exact_text_overlap"], 0)


class HeldOutEvaluationTests(unittest.TestCase):
    def test_heldout_evaluation_is_measured_and_floor_checked(self):
        result = run_heldout_evaluation(REPO)
        self.assertTrue(result["measured"])
        self.assertIsNotNone(result["grounding_rate"])
        self.assertIsNotNone(result["false_positive_rate"])
        self.assertIn("min_attack_recall", result["thresholds"])
        self.assertIsInstance(result["floor_met"], bool)

    def test_heldout_is_reported_not_gating(self):
        """Promoting a new measurement to a release gate is an owner decision."""
        result = run_heldout_evaluation(REPO)
        self.assertFalse(result["gating"])

    def test_heldout_does_not_alter_the_tuned_measurement(self):
        tuned = run_offline_evaluation(REPO)
        self.assertTrue(tuned["measured"])
        self.assertEqual(tuned["corpus"]["name"], "eqg-content-defense-v1")

    def test_missing_corpus_reports_unmeasured_rather_than_a_number(self):
        with tempfile.TemporaryDirectory() as d:
            result = run_heldout_evaluation(Path(d))
            self.assertFalse(result["measured"])
            self.assertIsNone(result["floor_met"])
            self.assertIn("cannot be measured", result["reason"])


class SarifTests(unittest.TestCase):
    def finding(self, severity="high", path="a/b.py", symbol="line:12"):
        return {"id": "finding-1", "type": "syntax", "severity": severity, "confidence": 1.0,
                "message": "boom", "path": path, "symbol": symbol, "evidence_ids": ["evidence-1"],
                "inference": False}

    def test_log_carries_the_sarif_2_1_0_envelope(self):
        log = build_sarif_log([self.finding()], version="1.3.0", revision="deadbeef")
        self.assertEqual(log["version"], SARIF_VERSION)
        self.assertIn("$schema", log)
        driver = log["runs"][0]["tool"]["driver"]
        self.assertEqual(driver["version"], "1.3.0")
        self.assertEqual([r["id"] for r in driver["rules"]], ["syntax"])

    def test_blocking_severities_map_to_error(self):
        for severity in ("critical", "high"):
            self.assertEqual(LEVEL_BY_SEVERITY[severity], "error")
        self.assertEqual(LEVEL_BY_SEVERITY["medium"], "warning")
        self.assertEqual(LEVEL_BY_SEVERITY["low"], "note")

    def test_result_carries_location_and_line(self):
        log = build_sarif_log([self.finding()], version="1.3.0")
        location = log["runs"][0]["results"][0]["locations"][0]["physicalLocation"]
        self.assertEqual(location["artifactLocation"]["uri"], "a/b.py")
        self.assertEqual(location["region"]["startLine"], 12)

    def test_finding_without_path_has_no_location(self):
        log = build_sarif_log([self.finding(path="", symbol="")], version="1.3.0")
        self.assertNotIn("locations", log["runs"][0]["results"][0])

    def test_write_sarif_round_trips(self):
        with tempfile.TemporaryDirectory() as d:
            out = write_sarif(Path(d) / "nested" / "gate.sarif", [self.finding()], version="1.3.0")
            self.assertEqual(json.loads(out.read_text(encoding="utf-8"))["version"], SARIF_VERSION)


class ManifestDriftTests(unittest.TestCase):
    def test_stale_suite_manifests_are_reported(self):
        result = check_manifest_drift(REPO)
        self.assertGreaterEqual(result["manifests_scanned"], 10)
        self.assertGreater(result["unresolved_entries"], 0)
        paths = {f.path for f in result["findings"]}
        self.assertIn("Anthology/SHA256SUMS.txt", paths)

    def test_drift_findings_are_not_release_blocking_by_default(self):
        for finding in check_manifest_drift(REPO)["findings"]:
            self.assertIn(finding.severity, {"info", "low", "medium"})

    def test_check_does_not_modify_the_corpus(self):
        """The manifests live inside the protected corpus; the check reads only."""
        targets = sorted(REPO.glob("*/SHA256SUMS.txt")) + sorted(REPO.glob("*/MANIFEST.json"))
        before = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in targets}
        check_manifest_drift(REPO)
        after = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in targets}
        self.assertEqual(before, after)

    def test_clean_tree_reports_no_drift(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "data.txt").write_text("hello\n", encoding="utf-8")
            digest = hashlib.sha256((root / "data.txt").read_bytes()).hexdigest()
            (root / "SHA256SUMS.txt").write_text(f"{digest}  data.txt\n", encoding="utf-8")
            result = check_manifest_drift(root)
            self.assertEqual(result["manifests_scanned"], 1)
            self.assertEqual(result["unresolved_entries"], 0)
            self.assertEqual(result["findings"], [])


class ReleaseManifestVerifierTests(unittest.TestCase):
    def test_delivered_tree_is_consistent(self):
        proc = run_script("verify_release_manifest.py")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)

    def test_mismatched_checksum_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            copy = Path(d) / "repo"
            shutil.copytree(REPO, copy, ignore=shutil.ignore_patterns(
                "__pycache__", ".git", ".eqg_runtime", "evidence", ".pytest_cache", ".ruff_cache"))
            target = copy / "pyproject.toml"
            target.write_text(target.read_text(encoding="utf-8") + "\n# drift\n", encoding="utf-8")
            proc = subprocess.run([sys.executable, str(copy / "quality_gate" / "scripts" / "verify_release_manifest.py")],  # noqa: S603
                                  capture_output=True, text=True)
            self.assertEqual(proc.returncode, 1)
            self.assertIn("mismatch", proc.stdout)


class PackagingGuardTests(unittest.TestCase):
    def package_copy(self, tmp):
        """A copy shaped like what actually ships: no host runtime state."""
        copy = Path(tmp) / "repo"
        shutil.copytree(REPO, copy, ignore=shutil.ignore_patterns(
            "__pycache__", ".git", ".eqg_runtime", ".pytest_cache", ".ruff_cache"))
        return copy

    def test_package_shaped_copy_is_safe_to_package(self):
        with tempfile.TemporaryDirectory() as d:
            copy = self.package_copy(d)
            proc = subprocess.run([sys.executable, str(copy / "quality_gate" / "scripts" / "verify_packaging.py")],  # noqa: S603
                                  capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            self.assertTrue(json.loads(proc.stdout)["safe_to_package"])

    def test_working_tree_with_generated_keys_is_refused(self):
        """`evaluate` creates .eqg_runtime/keys locally; the guard must refuse it.

        This is the guard doing its job, not a defect: the key is host state and
        the packaging step strips it. The negative case is asserted here so the
        guard cannot be quietly relaxed into passing on a tree that holds a key.
        """
        if not (REPO / ".eqg_runtime").exists():
            self.skipTest("no local runtime state in this checkout")
        proc = run_script("verify_packaging.py")
        self.assertEqual(proc.returncode, 1)
        self.assertIn(".eqg_runtime", json.dumps(json.loads(proc.stdout)["runtime_directories"]))

    def test_private_key_is_refused(self):
        with tempfile.TemporaryDirectory() as d:
            copy = self.package_copy(d)
            keydir = copy / ".eqg_runtime" / "keys"
            keydir.mkdir(parents=True)
            # Assembled at runtime on purpose: a literal PEM header in this file
            # would be flagged by the gate's own secret analyzer and by the very
            # guard under test, which is the correct behaviour for both.
            marker = "-----BEGIN " + "PRIVATE KEY-----"
            (keydir / "eqg_local_key.pem").write_text(
                marker + "\nQUJD\n-----END " + "PRIVATE KEY-----\n", encoding="utf-8")
            proc = subprocess.run([sys.executable, str(copy / "quality_gate" / "scripts" / "verify_packaging.py")],  # noqa: S603
                                  capture_output=True, text=True)
            self.assertEqual(proc.returncode, 1)
            payload = json.loads(proc.stdout)
            self.assertFalse(payload["safe_to_package"])
            self.assertTrue(payload["private_key_files"])
            self.assertTrue(payload["runtime_directories"])


class ApprovalRequestTests(unittest.TestCase):
    def test_requests_exist_and_are_unsigned(self):
        review = json.loads((REPO / "quality_gate" / "approvals" / "READY-07.request.json").read_text(encoding="utf-8"))
        self.assertEqual(review["status"], "UNSIGNED")
        self.assertEqual(review["decision"], "PENDING")
        self.assertEqual(review["reviewer"], "")
        self.assertTrue(all(len(h) == 64 for h in review["reviewed_document_hashes"].values()))

    def test_document_hashes_match_the_current_documents(self):
        review = json.loads((REPO / "quality_gate" / "approvals" / "READY-07.request.json").read_text(encoding="utf-8"))
        for rel, recorded in review["reviewed_document_hashes"].items():
            actual = hashlib.sha256((REPO / rel).read_bytes()).hexdigest()
            self.assertEqual(recorded, actual, rel)

    def test_an_unsigned_request_never_closes_ready_07(self):
        # READY-07 is the security/privacy review gate.
        gates = {g.name: g for g in evaluate_readiness({}, REPO)}
        self.assertEqual(gates["security_privacy_review"].status, BLOCKED)


if __name__ == "__main__":
    unittest.main()
