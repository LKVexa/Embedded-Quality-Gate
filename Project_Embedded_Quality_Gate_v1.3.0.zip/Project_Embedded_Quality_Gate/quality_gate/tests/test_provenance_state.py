import json
import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.provenance import AppendOnlyLedger, LedgerError
from embedded_quality_gate.state import RunState, StateError


class ProvenanceStateTests(unittest.TestCase):
 def test_hash_chain_detects_tamper(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'ledger.jsonl'; ledger=AppendOnlyLedger(p); ledger.append('a',{'x':1},source_revision='r1'); ledger.append('b',{'x':2},source_revision='r1'); self.assertTrue(ledger.verify())
   rows=p.read_text().splitlines(); r=json.loads(rows[0]); r['payload']['x']=9; rows[0]=json.dumps(r); p.write_text('\n'.join(rows)+'\n')
   with self.assertRaises(LedgerError): ledger.verify()
 def test_phase_prerequisite_fail_closed(self):
  with tempfile.TemporaryDirectory() as d:
   s=RunState(Path(d)/'state.json','run','rev')
   with self.assertRaises(StateError): s.set_phase('P01','PASS',['P00'])
   s.set_phase('P00','PASS'); s.set_phase('P01','PASS',['P00']); self.assertEqual(s.data['phases']['P01'],'PASS')
