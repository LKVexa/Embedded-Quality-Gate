"""Backup, verified restore, and the non-destructive restore drill (AUDIT-11)."""
import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.backup import (
    RestoreVerificationError,
    backup_file,
    restore_drill,
    restore_file,
)


class BackupTests(unittest.TestCase):
    def test_backup_restore_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            src = root / "state.json"
            bak = root / "backup" / "state.json"
            src.write_text("original", encoding="utf-8")
            record = backup_file(src, bak)
            src.write_text("changed", encoding="utf-8")
            digest = restore_file(bak, src, record.sha256)
            self.assertEqual(src.read_text(encoding="utf-8"), "original")
            self.assertEqual(record.sha256, digest)

    def test_restore_rejects_unexpected_digest(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            bak = root / "b.json"
            bak.write_text("payload", encoding="utf-8")
            with self.assertRaises(RestoreVerificationError):
                restore_file(bak, root / "out.json", "0" * 64)

    def test_restore_drill_is_non_destructive(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            src = root / "evidence.jsonl"
            src.write_text("line\n", encoding="utf-8")
            record = backup_file(src, root / "backup" / "evidence.jsonl")
            result = restore_drill(record, root / "scratch")
            self.assertTrue(result["verified"])
            self.assertFalse(result["destructive"])
            # the live file is untouched by the drill
            self.assertEqual(src.read_text(encoding="utf-8"), "line\n")
