import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.evaluation import run_offline_evaluation
from embedded_quality_gate.impact import minimal_impact
from embedded_quality_gate.norms import repository_norms
from embedded_quality_gate.review_session import ReviewError, ReviewSession
from embedded_quality_gate.sources import SourceSpec, discover
from embedded_quality_gate.testgap import analyze_test_gaps
from embedded_quality_gate.uncertainty import EvidenceState, confidence_from_validation


class MoreControlsTests(unittest.TestCase):
 def test_optional_source_absence_is_explicit(self):
  with tempfile.TemporaryDirectory() as d:
   out=discover(Path(d),SourceSpec('ci',('*.ci',),False),'r');self.assertEqual(out['state'],'missing_optional')
 def test_impact_includes_changed_file_without_graph(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);(r/'x.ja').write_text('module x\n');out=minimal_impact(r,['x.ja']);self.assertIn('x.ja',out['impacted_paths'])
 def test_test_gap_is_not_fabricated_as_coverage(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);(r/'x.py').write_text('x=1');out=analyze_test_gaps(r,['x.py']);self.assertEqual(out['coverage_state'],'unknown_without_instrumented_toolchain');self.assertEqual(len(out['gaps']),1)
 def test_norms_are_deterministic(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);(r/'x.jasec').write_text('module chair.x\npolicy no_network\n');out=repository_norms(r);self.assertEqual(out['security_source_files'],1);self.assertEqual(out['module_prefixes']['chair'],1)
 def test_uncertainty_routes(self):
  self.assertEqual(EvidenceState('missing',None,'x').disposition(),'abstain');self.assertEqual(EvidenceState('uncertain',.9,'x',True).disposition(),'review');self.assertAlmostEqual(confidence_from_validation(9,10),.9)
 def test_review_operations_and_no_self_issue(self):
  s=ReviewSession(['a','b'],['e1'],['deterministic'],['coverage']);s.narrow_scope(['a']);s.request_more_evidence('need tests');s.edit_draft('clarify')
  with self.assertRaises(ReviewError):s.approve_preview()
  s.reject('not acceptable');self.assertEqual(s.state,'rejected');self.assertEqual(s.final_accountability,'human')
 def test_offline_eval(self):
  out=run_offline_evaluation('.')
  # Guardrail behaviour must still fail closed...
  self.assertTrue(out['guardrails_fail_closed'])
  # ...but the grounding rate is now measured against a named corpus, so it is
  # whatever the corpus says. Asserting 1.0 was what made the old check a tautology.
  self.assertTrue(out['measured'])
  self.assertIsNotNone(out['corpus'].get('name'))
  self.assertIsInstance(out['grounding_rate'],float)
  self.assertGreaterEqual(out['grounding_rate'],0.0)
  self.assertLessEqual(out['grounding_rate'],1.0)
