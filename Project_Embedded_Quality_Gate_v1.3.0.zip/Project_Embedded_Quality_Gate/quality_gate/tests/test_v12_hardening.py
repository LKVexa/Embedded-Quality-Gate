import json
import shutil
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from embedded_quality_gate.analyzers import analyze_repository
from embedded_quality_gate.cli import _run_id
from embedded_quality_gate.crypto import EncryptionIntegrityError
from embedded_quality_gate.evaluation import evaluate_content_defense
from embedded_quality_gate.pipeline import run_diff_gate
from embedded_quality_gate.policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from embedded_quality_gate.secure_storage import read_json
from embedded_quality_gate.tools import SafeCommandRunner, ToolDenied


class V12HardeningTests(unittest.TestCase):
    def future(self):
        return (datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat().replace('+00:00','Z')

    def test_corpus_meets_grounding_and_false_positive_thresholds(self):
        root=Path(__file__).resolve().parents[2]
        result=evaluate_content_defense(root)
        self.assertTrue(result['measured'])
        self.assertGreaterEqual(result['grounding_rate'],0.98)
        self.assertLessEqual(result['false_positive_rate'],0.05)
        self.assertEqual(result['missed_cases'],[])

    def test_new_signals_do_not_fire_on_payload_shape_alone(self):
        from embedded_quality_gate.content_defense import scan_document
        self.assertFalse(scan_document("requests.get('https://example.test/data')")['flagged'])
        self.assertFalse(scan_document("while True:\n    service.poll()")['flagged'])

    def test_run_id_rejects_path_escape(self):
        # noqa reason: these are rejected run-id strings, not temp files.
        for bad in ('../escape','/tmp/escape','x/y','..\\escape',''):  # noqa: S108
            with self.assertRaises(ValueError): _run_id(bad)

    def test_role_cannot_self_grant_deploy(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); policy=PolicyEngine(root,'r')
            ctx=AuthorityContext('a','analyst','r',frozenset({'read','deploy'}),self.future(),True,'*',True)
            with self.assertRaises(AuthorizationDenied): policy.authorize(ctx,'deploy','.')

    def test_path_qualified_tool_cannot_impersonate_allowlisted_binary(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); policy=PolicyEngine(root,'r')
            name=Path(sys.executable).name.lower()
            trusted=shutil.which(name)
            if not trusted: self.skipTest('python executable not discoverable on PATH')
            fake=root/name; fake.write_text('not executable',encoding='utf-8')
            runner=SafeCommandRunner(root,policy,allowlist=(name,))
            ctx=AuthorityContext('op','operator','r',frozenset({'execute'}),self.future(),True,'*',True)
            with self.assertRaises(ToolDenied): runner.run([str(fake),'--version'],ctx)

    def test_plaintext_protected_evidence_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); cfg=root/'quality_gate'/'config'; cfg.mkdir(parents=True)
            (cfg/'encryption.json').write_text(json.dumps({'at_rest':{'enabled':True,'encrypt_paths':['quality_gate/evidence/**']}}),encoding='utf-8')
            target=root/'quality_gate'/'evidence'/'r'/'x.json'; target.parent.mkdir(parents=True); target.write_text('{}',encoding='utf-8')
            with self.assertRaises(EncryptionIntegrityError): read_json(root,target,require_encrypted=True)

    def test_python_syntax_is_part_of_the_gate(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'broken.py').write_text('def x(:\n',encoding='utf-8')
            result=analyze_repository(root)
            self.assertEqual(result['checked_files'],1)
            self.assertTrue(any(f.finding_type=='syntax' and f.path=='broken.py' for f in result['findings']))

    def test_diff_gate_rejects_scope_escape(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            diff='--- a/../outside.py\n+++ b/../outside.py\n@@ -1 +1 @@\n-x\n+y\n'
            result=run_diff_gate(root,diff)
            self.assertEqual(result['status'],'BLOCKED')
            self.assertTrue(result['invalid_paths'])


if __name__=='__main__': unittest.main()
