import os
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from embedded_quality_gate.classification import can_export, classify_text
from embedded_quality_gate.contracts import ContractError
from embedded_quality_gate.model_control import build_context, validate_output
from embedded_quality_gate.monitor import PermissionMonitor
from embedded_quality_gate.policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from embedded_quality_gate.retention import enforce_retention
from embedded_quality_gate.retrieval import rank_sources


class SecurityExtendedTests(unittest.TestCase):
 def future(self):return (datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat().replace('+00:00','Z')
 def test_secret_evidence_excluded_from_model_context(self):
  c=build_context('s',[{'evidence_id':'e1','classification':'secret'},{'evidence_id':'e2','classification':'internal'}],[]);self.assertEqual([e['evidence_id'] for e in c['evidence']],['e2'])
 def test_model_cannot_fabricate_approval(self):
  with self.assertRaises(ContractError):validate_output({'status':'ok','approval_token':'fake','findings':[]},{'e1'})
 def test_cross_project_authority_denied(self):
  with tempfile.TemporaryDirectory() as d:
   p=PolicyEngine(Path(d),'repo-a');ctx=AuthorityContext('x','analyst','repo-b',frozenset({'read'}),self.future(),False,'',True)
   with self.assertRaises(AuthorizationDenied):p.authorize(ctx,'read','.')
 def test_sensitive_output_classification(self):
  self.assertEqual(classify_text('password=secretvalue'),'secret');self.assertFalse(can_export('secret'))
 def test_retention_delete_requires_approved_modify(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);p=root/'old.txt';p.write_text('x');os.utime(p,(1,1));pol=PolicyEngine(root,'r')
   self.assertEqual(enforce_retention(root,1,pol,None,dry_run=True)['candidates'],['old.txt'])
   ctx=AuthorityContext('op','repository_operator','r',frozenset({'modify'}),self.future(),False,'*',True)
   with self.assertRaises(AuthorizationDenied):enforce_retention(root,1,pol,ctx,dry_run=False)
 def test_stale_source_ranked_below_current(self):
  now=datetime.now(timezone.utc);old=(now-timedelta(days=3)).isoformat().replace('+00:00','Z');new=now.isoformat().replace('+00:00','Z')
  r=rank_sources([{'id':'old','observed_at':old},{'id':'new','observed_at':new}],now=now);self.assertEqual(r[0]['id'],'new');self.assertEqual(r[-1]['freshness'],'stale')
 def test_permission_monitor_alerts_privileged_denial(self):
  m=PermissionMonitor();m.record('read',False,'x');m.record('deploy',False,'x');self.assertEqual(len(m.alerts()),1)
