import json
import os
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from embedded_quality_gate.cli import _run_id
from embedded_quality_gate.content_defense import scan_document
from embedded_quality_gate.diff_parser import parse_unified_diff, reconstruct_new_text
from embedded_quality_gate.pipeline import run_diff_gate
from embedded_quality_gate.policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from embedded_quality_gate.release import (
    BLOCKED,
    evaluate_delivery_preconditions,
    evaluate_readiness,
    promotion_allowed,
    review_document_hashes,
)
from embedded_quality_gate.tools import SafeCommandRunner, trusted_path


class V13HardeningTests(unittest.TestCase):
    def future(self):
        return (datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat().replace('+00:00','Z')

    def test_new_file_syntax_error_in_diff_is_blocking(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            diff='--- /dev/null\n+++ b/evil.py\n@@ -0,0 +1,2 @@\n+def x(:\n+    pass\n'
            result=run_diff_gate(root,diff)
            self.assertEqual(result['status'],'BLOCKED')
            findings=result['summary']['findings']
            self.assertTrue(any(f.get('type')=='syntax' for f in findings))

    def test_reconstruct_new_file_from_hunks(self):
        diff='--- /dev/null\n+++ b/new.py\n@@ -0,0 +1,2 @@\n+def ok():\n+    return 1\n'
        files=parse_unified_diff(diff)
        text=reconstruct_new_text(files[0])
        self.assertIn('def ok()', text)

    def test_binary_and_rename_are_impacted(self):
        files=parse_unified_diff('Binary files a/secret.bin and b/secret.bin differ\n')
        self.assertEqual([f.new_path for f in files],['secret.bin'])
        files=parse_unified_diff('diff --git a/old.py b/new.py\nrename from old.py\nrename to new.py\n')
        self.assertTrue(any(f.new_path=='new.py' for f in files))

    def test_quoted_git_path(self):
        diff='--- "a/foo bar.py"\n+++ "b/foo bar.py"\n@@ -1 +1 @@\n-old\n+new\n'
        files=parse_unified_diff(diff)
        self.assertEqual(files[0].new_path,'foo bar.py')

    def test_malformed_policy_does_not_widen(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            cfg=root/'quality_gate'/'config'; cfg.mkdir(parents=True)
            (cfg/'policy.json').write_text('{not json',encoding='utf-8')
            policy=PolicyEngine(root,'r')
            ctx=AuthorityContext('a','analyst','r',frozenset({'read'}),self.future())
            with self.assertRaises(AuthorizationDenied):
                policy.authorize(ctx,'read','.')

    def test_missing_policy_in_configured_repo_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'quality_gate'/'config').mkdir(parents=True)
            policy=PolicyEngine(root,'r')
            ctx=AuthorityContext('a','analyst','r',frozenset({'read'}),self.future())
            with self.assertRaises(AuthorizationDenied):
                policy.authorize(ctx,'read','.')

    def test_poisoned_path_cannot_satisfy_allowlist(self):
        import sys
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            name=Path(sys.executable).name.lower()
            fake_dir=root/'hijack'; fake_dir.mkdir()
            fake=fake_dir/name
            fake.write_text('#!/bin/sh\necho HIJACKED\n',encoding='utf-8')
            fake.chmod(0o755)
            old=os.environ.get('PATH','')
            os.environ['PATH']=str(fake_dir)+os.pathsep+old
            try:
                policy=PolicyEngine(root,'r')
                runner=SafeCommandRunner(root,policy,allowlist=(name,))
                ctx=AuthorityContext('op','operator','r',frozenset({'execute'}),self.future(),True,'*',True)
                result=runner.run([name,'-c','print("trusted")'],ctx)
                self.assertNotIn('HIJACKED', result.stdout)
                self.assertIn('trusted', result.stdout)
            finally:
                os.environ['PATH']=old
            self.assertTrue(trusted_path())

    def test_placeholder_qualification_is_rejected(self):
        repo=Path(__file__).resolve().parents[2]
        env=repo/'quality_gate'/'environments'
        target=env/'ci_qualification.json'
        self.assertFalse(target.exists())
        pre=evaluate_delivery_preconditions(repo)
        by={g.name:g for g in pre}
        self.assertNotEqual(by['DEPLOY-02'].status,'PASS')
        # dropping a three-boolean PASS without evidence_refs must not open the gate
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'quality_gate'/'environments').mkdir(parents=True)
            (root/'quality_gate'/'config').mkdir(parents=True)
            (root/'quality_gate'/'config'/'encryption.json').write_text(json.dumps({
                'at_rest':{'enabled':True,'provider':'local_rsa','encrypt_paths':['quality_gate/evidence/**']}
            }),encoding='utf-8')
            (root/'quality_gate'/'environments'/'ci_qualification.json').write_text(json.dumps({
                'environment':'ci','status':'PASS','qualified_at':'2026-09-04T00:00:00Z',
                'qualified_by':'ci','revision':'deadbeef','smoke_pass':True,'security_pass':True,
                'rollback_pass':True,
            }),encoding='utf-8')
            from embedded_quality_gate.release import _qualification
            from embedded_quality_gate.repository import repo_revision
            result=_qualification(root,'DEPLOY-02','ci_qualification.json',current_revision=repo_revision(root))
            self.assertEqual(result.status, BLOCKED)

    def test_na_qualification_requires_current_revision(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'quality_gate'/'environments').mkdir(parents=True)
            (root/'quality_gate'/'environments'/'privileged_path_qualification.json').write_text(json.dumps({
                'status':'NOT_APPLICABLE','approved_by':'Ada Lovelace','reason':'privileged path excluded',
            }),encoding='utf-8')
            from embedded_quality_gate.release import _qualification
            from embedded_quality_gate.repository import repo_revision
            result=_qualification(root,'DEPLOY-05','privileged_path_qualification.json',allow_na=True,current_revision=repo_revision(root))
            self.assertEqual(result.status, BLOCKED)

    def test_model_identity_cannot_sign_security_review(self):
        repo=Path(__file__).resolve().parents[2]
        sig=repo/'quality_gate'/'approvals'/'security_privacy_review.json'
        self.assertFalse(sig.exists())
        payload={
            'reviewer':'Grok','reviewer_role':'security_privacy_reviewer','decision':'APPROVED',
            'reviewed_revision':'x','reviewed_at':'2026-09-04T00:00:00Z','scope':'all',
            'evidence_refs':['quality_gate/docs/THREAT_MODEL.md'],
            'reviewed_document_hashes':review_document_hashes(repo),
        }
        # Write to a temp repo clone of the approval path only.
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            dest=root/'quality_gate'/'approvals'; dest.mkdir(parents=True)
            (dest/'security_privacy_review.json').write_text(json.dumps(payload),encoding='utf-8')
            from embedded_quality_gate.release import _v_security_review
            status,reason,_=_v_security_review(root)
            self.assertEqual(status, BLOCKED)
            self.assertIn('model identity', reason)

    def test_promotion_requires_delivery_preconditions(self):
        repo=Path(__file__).resolve().parents[2]
        gates=evaluate_readiness({}, repo)
        self.assertFalse(promotion_allowed(gates))
        self.assertFalse(promotion_allowed(gates, None))

    def test_while_1_alone_is_benign(self):
        self.assertFalse(scan_document('while 1:\n    server.serve()')['flagged'])

    def test_run_id_still_rejects_escape(self):
        with self.assertRaises(ValueError):
            _run_id('../escape')


if __name__=='__main__':
    unittest.main()
