import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.analyzers import analyze_repository, validate_dmk_references
from embedded_quality_gate.diff_parser import impacted_paths, parse_unified_diff


class DiffAnalyzerTests(unittest.TestCase):
 def test_diff_parse_and_impact(self):
  d='--- a/a.txt\n+++ b/a.txt\n@@ -1 +1 @@\n-old\n+new\n'; f=parse_unified_diff(d); self.assertEqual(impacted_paths(f),['a.txt'])
 def test_malformed_diff_rejected(self):
  with self.assertRaises(ValueError): parse_unified_diff('--- a/a\nnot-plus\n')
 def test_structural_analyzer(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d); (r/'x.ja').write_text('ja source 0.3\nmodule x\nblock { }\n',encoding='utf-8'); out=analyze_repository(r); self.assertEqual(out['findings'],[])
 def test_dmk_missing_is_detected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d); (r/'x.jad').write_text('module x\nfrom dmk("missing.dmk")\n',encoding='utf-8'); out=validate_dmk_references(r); self.assertEqual(len(out['missing']),1)
