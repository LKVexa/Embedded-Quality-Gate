import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from embedded_quality_gate.contracts import ContractError, Finding, ScopeContract
from embedded_quality_gate.policy import AuthorityContext, AuthorizationDenied, PolicyEngine


class ContractPolicyTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.root=Path(self.t.name); (self.root/'a.txt').write_text('x')
  self.repo='repo-fixture'; self.policy=PolicyEngine(self.root,self.repo)
 def tearDown(self): self.t.cleanup()
 def future(self): return (datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat().replace('+00:00','Z')
 def ctx(self,actions=('read',),approved=False,role='analyst'):
  return AuthorityContext('fixture-human',role,self.repo,frozenset(actions),self.future(),approved,'*',True)
 def test_scope_contract_requires_revision(self):
  with self.assertRaises(ContractError): ScopeContract('repo','')
 def test_finding_requires_evidence(self):
  with self.assertRaises(ContractError): Finding('syntax','high',1.0,'x',())
 def test_default_deny_missing_authority(self):
  with self.assertRaises(AuthorizationDenied): self.policy.authorize(None,'read','a.txt')
 def test_privileged_requires_human_approval(self):
  with self.assertRaises(AuthorizationDenied): self.policy.authorize(self.ctx(('modify',),False),'modify','a.txt')
 def test_scope_escape_denied(self):
  with self.assertRaises(AuthorizationDenied): self.policy.authorize(self.ctx(),'read','../outside')
 def test_unknown_action_denied(self):
  with self.assertRaises(AuthorizationDenied): self.policy.authorize(self.ctx(),'root_shell','.')
