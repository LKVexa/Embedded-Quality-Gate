import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from embedded_quality_gate.contracts import ContractError
from embedded_quality_gate.model_control import DeterministicFixtureProvider, NoModelProvider, validate_output
from embedded_quality_gate.policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from embedded_quality_gate.review import approve_suggestion, stage_suggestion
from embedded_quality_gate.tools import SafeCommandRunner, ToolDenied


class ModelReviewToolsTests(unittest.TestCase):
 def future(self): return (datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat().replace('+00:00','Z')
 def test_no_model_abstains(self): self.assertEqual(NoModelProvider().synthesize({})['status'],'abstain')
 def test_model_unauthorized_evidence_rejected(self):
  with self.assertRaises(ContractError): validate_output({'status':'ok','findings':[{'evidence_ids':['bad'],'confidence':.5,'inference':True}]},{'good'})
 def test_fixture_model_labels_inference(self):
  o=DeterministicFixtureProvider().synthesize({'evidence':[{'evidence_id':'e1'}]}); self.assertTrue(o['findings'][0]['inference']); self.assertTrue(validate_output(o,{'e1'}))
 def test_self_approval_denied_and_other_approval_allowed(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); pol=PolicyEngine(root,'r'); s=stage_suggestion('author','scope','hash',['e1'])
   same=AuthorityContext('author','human_reviewer','r',frozenset({'approve'}),self.future(),True,'scope',True)
   with self.assertRaises(AuthorizationDenied): approve_suggestion(s,same,pol,self.future())
   other=AuthorityContext('reviewer','human_reviewer','r',frozenset({'approve'}),self.future(),True,'scope',True)
   a=approve_suggestion(s,other,pol,self.future()); self.assertEqual(a.approver_identity,'reviewer')
 def test_tool_allowlist_fail_closed(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); pol=PolicyEngine(root,'r'); runner=SafeCommandRunner(root,pol,allowlist=())
   ctx=AuthorityContext('op','repository_operator','r',frozenset({'execute'}),self.future(),True,'*',True)
   with self.assertRaises(ToolDenied): runner.run(['python','-V'],ctx)
