"""Envelope encryption at rest (XSEC-04)."""
import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate import crypto


class CryptoTests(unittest.TestCase):
    def _encryptor(self, tmp):
        cfg = {"at_rest": {"enabled": True, "provider": "local_rsa",
                           "key_material_path": "keys/test.pem", "key_id": "test-key"},
               "in_transit": {"enabled": False, "reason": "no network in tests"}}
        return crypto.build_encryptor(Path(tmp), cfg), cfg

    @unittest.skipUnless(crypto.backend_available(), "crypto extra not installed")
    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            enc, _ = self._encryptor(d)
            env = enc.encrypt(b"evidence bytes", aad=b"run-1")
            self.assertEqual(env.algorithm, "AES-256-GCM")
            self.assertEqual(env.key_algorithm, "RSA-OAEP-SHA256")
            self.assertEqual(enc.decrypt(env, aad=b"run-1"), b"evidence bytes")

    @unittest.skipUnless(crypto.backend_available(), "crypto extra not installed")
    def test_ciphertext_is_authenticated(self):
        """A tampered envelope must fail, not decrypt to something plausible."""
        with tempfile.TemporaryDirectory() as d:
            enc, _ = self._encryptor(d)
            env = enc.encrypt(b"evidence bytes", aad=b"run-1")
            broken = env.__class__(**{**env.__dict__, "ciphertext": "A" + env.ciphertext[1:]})
            with self.assertRaises(crypto.EncryptionIntegrityError):
                enc.decrypt(broken, aad=b"run-1")

    @unittest.skipUnless(crypto.backend_available(), "crypto extra not installed")
    def test_associated_data_is_bound(self):
        with tempfile.TemporaryDirectory() as d:
            enc, _ = self._encryptor(d)
            env = enc.encrypt(b"x", aad=b"run-1")
            with self.assertRaises(crypto.EncryptionIntegrityError):
                enc.decrypt(env, aad=b"run-2")

    def test_disabled_provider_fails_closed(self):
        """Never plaintext under an encryption claim."""
        with tempfile.TemporaryDirectory() as d:
            enc = crypto.build_encryptor(Path(d), {"at_rest": {"enabled": False}})
            self.assertFalse(enc.available)
            with self.assertRaises(crypto.EncryptionUnavailable):
                enc.encrypt(b"x")

    def test_status_never_claims_transit_without_transit(self):
        with tempfile.TemporaryDirectory() as d:
            status = crypto.crypto_status(Path(d), {"at_rest": {"enabled": False},
                                                    "in_transit": {"enabled": False, "reason": "local mode"}})
            self.assertEqual(status["in_transit"]["status"], "not_applicable")
            self.assertNotEqual(status["in_transit"]["status"], "enforced")
