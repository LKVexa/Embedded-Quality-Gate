"""Workflow transitions, verified readiness, and redacted logging.

Two of these tests replace assertions that encoded defects:

* the old suite asserted that supplying every readiness fact promoted the
  release. That is the rubber stamp READY-03/READY-05 forbid, so the assertion
  is inverted here: caller-supplied facts must never be sufficient.
* the old redaction test expected the six-key matcher's `[REDACTED]` marker.
  Redaction now masks by key name *and* by value shape.
"""
import json
import tempfile
import unittest
from pathlib import Path

from embedded_quality_gate.observability import EventLog
from embedded_quality_gate.release import (
    INDETERMINATE,
    evaluate_readiness,
    promotion_allowed,
)
from embedded_quality_gate.workflow import WorkflowError, WorkflowRun

FACT_KEYS = [
    "guardrails_enforced", "evaluation_thresholds", "no_hidden_write_authority",
    "traceable_outputs", "human_gate_bypass_tests", "rollback_exercised",
    "security_privacy_review", "limitations_published",
]


class WorkflowReleaseTests(unittest.TestCase):
    def test_workflow_cannot_skip(self):
        run = WorkflowRun()
        with self.assertRaises(WorkflowError):
            run.advance("INGEST")
        run.advance("PIN_SCOPE")
        self.assertEqual(run.state, "PIN_SCOPE")

    def test_abort_is_terminal_and_raises_workflow_error(self):
        run = WorkflowRun()
        run.advance("PIN_SCOPE")
        record = run.abort("evidence", "required source missing")
        self.assertEqual(record["aborted_from"], "PIN_SCOPE")
        self.assertTrue(run.is_terminal)
        # previously this raised ValueError out of STEPS.index()
        with self.assertRaises(WorkflowError):
            run.advance("INGEST")
        with self.assertRaises(WorkflowError):
            run.abort("scope", "second abort")

    def test_abort_reason_must_be_recognised(self):
        with self.assertRaises(WorkflowError):
            WorkflowRun().abort("because", "not a recognised condition")

    def test_readiness_without_a_repository_is_indeterminate(self):
        gates = evaluate_readiness({})
        self.assertFalse(promotion_allowed(gates))
        self.assertTrue(all(g.status == INDETERMINATE for g in gates))

    def test_caller_facts_alone_cannot_promote(self):
        """The rubber-stamp regression guard: asserting facts must not promote."""
        facts = {k: True for k in FACT_KEYS}
        self.assertFalse(promotion_allowed(evaluate_readiness(facts)))
        self.assertFalse(promotion_allowed(evaluate_readiness(facts, None)))

    def test_caller_facts_can_only_lower_a_verdict(self):
        repo = Path(__file__).resolve().parents[2]
        honest = {g.name: g.status for g in evaluate_readiness({}, repo)}
        denied = {g.name: g.status for g in evaluate_readiness({k: False for k in FACT_KEYS}, repo)}
        for name, status in honest.items():
            if status == "PASS":
                self.assertEqual(denied[name], "BLOCKED", f"{name} should have been lowered")

    def test_log_redacts_secrets_by_key_and_by_value(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "events.jsonl"
            EventLog(path).emit("tool", {
                "token": "abc",
                "nested": {"password": "xyz"},
                "message": "use sk-ant-aaaaaaaaaaaaaaaaaaaaaa now",
                "sha256": "a" * 64,
            })
            fields = json.loads(path.read_text(encoding="utf-8"))["fields"]
            self.assertEqual(fields["token"], "[REDACTED:SECRET]")
            self.assertEqual(fields["nested"]["password"], "[REDACTED:SECRET]")
            self.assertNotIn("sk-ant-aaaaaaaaaaaaaaaaaaaaaa", fields["message"])
            # hash-chain join keys must survive byte-identical
            self.assertEqual(fields["sha256"], "a" * 64)
