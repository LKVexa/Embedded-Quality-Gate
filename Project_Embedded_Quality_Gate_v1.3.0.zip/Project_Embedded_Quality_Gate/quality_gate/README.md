# Embedded Quality Gate for Code and Tests — Repository Integration v1.0.0

This directory is the repository-local application of the supplied Embedded Quality Gate master prompt/workflow package. It adds executable deterministic controls around the existing 66-suite JA/DeepML specification corpus without rewriting the corpus or claiming a production compiler/runtime that is not present.

## Operating posture

- Evidence-first and deterministic-first.
- Default deny for unknown actions, missing authority, scope escape, stale authority, and privileged actions without explicit human approval.
- No model self-approval and no silent code/test modification path.
- Production promotion is fail-closed; missing CI/staging/production qualifications and human security/release sign-offs remain blocking.
- The local reference mode performs no network access and ships with no external connector credentials.

## Run locally

Windows: `RUN_QUALITY_GATE.cmd` or `RUN_QUALITY_GATE.ps1`.

Portable: `python -B -m embedded_quality_gate analyze --repo .`

Tests: `python -B -m unittest discover -s quality_gate/tests -v`

## Evidence and traceability

See `quality_gate/traceability/TRACEABILITY_MATRIX_APPLIED.csv`, `quality_gate/traceability/REQUIREMENT_CLOSEOUT.csv`, and the latest directory under `quality_gate/evidence/`.
