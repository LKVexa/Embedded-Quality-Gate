#!/usr/bin/env python3
"""Fail when the release manifest or the checksum file describes a different build.

Serves: PROV-* / REL-*. The v1.2.0 build shipped a ``RELEASE_MANIFEST.json``
declaring 65 tests and version 1.2.0 alongside a v1.3.0 tree with 78 tests, and a
``CHECKSUMS.sha256`` that no longer matched 21 of the files it listed. Both read
as verification and were not, which is the failure mode this script closes.

Checks
  1. ``RELEASE_MANIFEST.json`` version equals ``embedded_quality_gate.version``.
  2. Every ``CHECKSUMS.sha256`` line resolves and matches, except the excluded
     prefixes below, which change every time the gate runs.
  3. Every non-excluded file in the tree appears in ``CHECKSUMS.sha256`` — an
     omission is as misleading as a mismatch.

Exit 0 when the manifest describes this tree, 1 otherwise.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "RELEASE_MANIFEST.json"
CHECKSUMS = ROOT / "CHECKSUMS.sha256"

#: Paths whose bytes change on every run, so covering them would guarantee a
#: stale file. The same list is written into the checksum file's own header.
#:
#: ``quality_gate/traceability/`` is excluded for a different reason: those CSVs
#: are regenerated from evidence by ``regenerate_closeout.py`` and re-pointed by
#: ``retarget_traceability_evidence.py`` every time a run closes, so a checksum
#: over them is stale by construction. They are not left unverified: READY-04
#: validates the whole matrix — census, required fields, every referenced path,
#: and parent/closeout agreement — which is a stronger check than a digest.
EXCLUDED_PREFIXES = ("quality_gate/evidence/", "quality_gate/traceability/", ".eqg_runtime/", ".git/")
EXCLUDED_FILES = {"CHECKSUMS.sha256"}
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".ruff_cache"}


def covered(rel: str, parts: tuple[str, ...]) -> bool:
    if rel in EXCLUDED_FILES or rel.startswith(EXCLUDED_PREFIXES):
        return False
    return not any(part in EXCLUDED_PARTS for part in parts)


def tree_files() -> dict[str, Path]:
    out = {}
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if covered(rel, path.parts):
            out[rel] = path
    return out


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def declared() -> dict[str, str]:
    out = {}
    if not CHECKSUMS.exists():
        return out
    for line in CHECKSUMS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) == 2 and len(parts[0]) == 64:
            out[parts[1].strip().lstrip("*")] = parts[0].lower()
    return out


def main() -> int:
    sys.path.insert(0, str(ROOT))
    from embedded_quality_gate.version import __version__

    problems: list[str] = []
    manifest = {}
    if not MANIFEST.exists():
        problems.append("RELEASE_MANIFEST.json is missing")
    else:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        if manifest.get("version") != __version__:
            problems.append(
                f"RELEASE_MANIFEST.json declares version {manifest.get('version')!r} "
                f"but the package is {__version__!r}"
            )
        report = manifest.get("audit_report")
        if report and not (ROOT / report).exists():
            problems.append(f"RELEASE_MANIFEST.json points at a missing audit report: {report}")

    files = tree_files()
    listed = declared()
    if not listed:
        problems.append("CHECKSUMS.sha256 is missing or empty")
    mismatched = sorted(rel for rel, want in listed.items() if rel in files and digest(files[rel]) != want)
    unresolved = sorted(rel for rel in listed if rel not in files)
    uncovered = sorted(rel for rel in files if rel not in listed)
    if mismatched:
        problems.append(f"{len(mismatched)} checksum mismatch(es), first: {mismatched[0]}")
    if unresolved:
        problems.append(f"{len(unresolved)} listed path(s) missing from the tree, first: {unresolved[0]}")
    if uncovered:
        problems.append(f"{len(uncovered)} file(s) present but not listed, first: {uncovered[0]}")

    print(json.dumps({
        "version": manifest.get("version"),
        "package_version": __version__,
        "files_covered": len(files),
        "checksum_entries": len(listed),
        "mismatched": mismatched[:20],
        "unresolved": unresolved[:20],
        "uncovered": uncovered[:20],
        "excluded_prefixes": list(EXCLUDED_PREFIXES),
        "consistent": not problems,
        "problems": problems,
    }, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
