#!/usr/bin/env python3
"""Fail if any file of the original 66-suite corpus has changed.

Serves: the standing constraint that the overhaul never edits the corpus it
analyses. Run by CI and by the release report.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASELINE = ROOT / "quality_gate" / "corpus_integrity_baseline.json"

#: Everything the Embedded Quality Gate itself owns. The corpus is what is left.
GATE_PREFIXES = (
    "embedded_quality_gate/", "quality_gate/", ".github/", ".eqg_runtime/",
)
GATE_FILES = {
    "LICENSE", "README.md", "THIRD-PARTY-NOTICES.md", "pyproject.toml",
    ".gitignore", ".pylintrc", "CHECKSUMS.sha256", "RELEASE_MANIFEST.json",
    "QUALITY_GATE_APPLICATION_REPORT.md", "RUN_QUALITY_GATE.sh",
    "RUN_QUALITY_GATE.cmd", "RUN_QUALITY_GATE.ps1",
}

#: Gate documentation that is added over time. Without this, every new audit or
#: remediation document at the repository root was reported as a corpus
#: ``added`` entry, which made real drift harder to see rather than easier.
GATE_FILE_PATTERNS = ("AUDIT_AND_REMEDIATION_", "APPLICATION_REPORT")


def is_gate_file(rel: str) -> bool:
    if rel.startswith(GATE_PREFIXES) or rel in GATE_FILES:
        return True
    name = rel.rsplit("/", 1)[-1]
    return "/" not in rel and any(token in name for token in GATE_FILE_PATTERNS)


def corpus_files() -> list[Path]:
    out = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if is_gate_file(rel):
            continue
        if "__pycache__" in path.parts or ".git" in path.parts:
            continue
        out.append(path)
    return out


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    current = {p.relative_to(ROOT).as_posix(): digest(p) for p in corpus_files()}
    if not BASELINE.exists():
        BASELINE.write_text(json.dumps({"file_count": len(current), "files": current},
                                       indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"baseline written: {len(current)} corpus files")
        return 0
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))["files"]
    changed = sorted(k for k in baseline if current.get(k) != baseline[k])
    missing = sorted(k for k in baseline if k not in current)
    added = sorted(k for k in current if k not in baseline)
    print(json.dumps({
        "baseline_files": len(baseline), "current_files": len(current),
        "changed": changed, "missing": missing, "added": added,
        # ``added`` is reported but never fails the check: the corpus is intact
        # when nothing in it changed or disappeared. A new file at the root is a
        # gate artefact, not corpus drift, and is classified as such above.
        "intact": not (changed or missing),
    }, indent=2))
    return 0 if not (changed or missing) else 1


if __name__ == "__main__":
    sys.exit(main())
