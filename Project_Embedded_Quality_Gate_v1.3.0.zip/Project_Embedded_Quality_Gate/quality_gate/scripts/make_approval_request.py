#!/usr/bin/env python3
"""Generate the UNSIGNED approval requests the blocked gates are waiting on.

Serves: READY-07, DEPLOY-04, DEPLOY-05. Repository-local code cannot close these
gates: they require a named human. What it *can* do is remove every excuse for
delay — bind the request to the current repository revision and to the SHA-256 of
every document under review, so signing is a decision rather than a research
task, and so a signature taken today cannot silently cover a document edited
tomorrow.

The generated files are ``*.request.json`` and carry ``status: "UNSIGNED"``.
Readiness reads ``security_privacy_review.json`` and
``<environment>_qualification.json``; a request file cannot satisfy a gate no
matter what it contains, and this script never writes those names.

Exit 0 on success.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

REVIEW_DOCUMENTS = (
    "quality_gate/docs/THREAT_MODEL.md",
    "quality_gate/docs/DATA_FLOW_TRUST_BOUNDARIES.md",
    "quality_gate/docs/KNOWN_LIMITATIONS_NON_GOALS.md",
    "quality_gate/docs/ENCRYPTION_KEY_MANAGEMENT.md",
    "quality_gate/docs/DATA_GOVERNANCE.md",
)


def digest(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        return "MISSING"
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    sys.path.insert(0, str(ROOT))
    from embedded_quality_gate.repository import repo_revision
    from embedded_quality_gate.util import utc_now

    revision = repo_revision(ROOT)
    generated = utc_now()
    written: list[str] = []

    review = {
        "status": "UNSIGNED",
        "request_for": "READY-07",
        "reviewer": "",
        "reviewer_role": "security_privacy_reviewer",
        "decision": "PENDING",
        "reviewed_revision": revision,
        "reviewed_at": "",
        "scope": "Embedded Quality Gate code, tests, policies, evidence handling, and documented limitations",
        "evidence_refs": list(REVIEW_DOCUMENTS),
        "reviewed_document_hashes": {rel: digest(rel) for rel in REVIEW_DOCUMENTS},
        "generated_at": generated,
        "instructions": (
            "A named human completes reviewer/reviewed_at, sets decision to APPROVED or REJECTED, removes "
            "status, and saves the result as quality_gate/approvals/security_privacy_review.json. Model or "
            "tool identities are rejected. If any document changes after signing, its hash no longer matches "
            "and readiness reopens the gate."
        ),
    }
    out = ROOT / "quality_gate" / "approvals" / "READY-07.request.json"
    out.write_text(json.dumps(review, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    written.append(out.relative_to(ROOT).as_posix())

    for gate, environment in (("DEPLOY-04", "production_readonly"), ("DEPLOY-05", "privileged_path")):
        record = {
            "status": "UNSIGNED",
            "request_for": gate,
            "environment": environment,
            "proposed_status": "NOT_APPLICABLE",
            "qualified_at": "",
            "qualified_by": "",
            "approved_by": "",
            "revision": revision,
            "smoke_pass": False,
            "security_pass": False,
            "rollback_pass": False,
            "credentials_boundary": "",
            "data_boundary": "",
            "evidence_refs": [],
            "reason": (
                f"Proposed disposition for {gate}: this repository is a local, offline analysis gate with no "
                f"{environment.replace('_', ' ')} deployment. A named human must confirm that no such "
                "environment exists for this revision, or supply a real qualification instead."
            ),
            "generated_at": generated,
            "instructions": (
                f"A named human completes qualified_by/approved_by/qualified_at and saves the result as "
                f"quality_gate/environments/{environment}_qualification.json. Until then the gate stays BLOCKED."
            ),
        }
        out = ROOT / "quality_gate" / "environments" / f"{gate}.request.json"
        out.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        written.append(out.relative_to(ROOT).as_posix())

    print(json.dumps({"revision": revision, "generated_at": generated, "written": written,
                      "signed": False,
                      "note": "requests only; no gate is closed by this script"}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
