#!/usr/bin/env python3
"""Regenerate RELEASE_MANIFEST.json and CHECKSUMS.sha256 for this tree.

Serves: REL-*, PROV-*. The counterpart to ``verify_release_manifest.py``: that
script fails when the manifest describes a different build, this one produces a
manifest that describes *this* one, from the tree and the current evidence rather
than from a previous release's numbers.

Everything recorded here is measured at generation time: the package version, the
test count from an actual run, the requirement disposition from
``REQUIREMENT_CLOSEOUT.csv``, and the open items from the readiness gates that are
not PASS. Nothing is copied forward from a previous manifest.

Usage: python quality_gate/scripts/regenerate_release_manifest.py
"""
from __future__ import annotations

import csv
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_release_manifest import EXCLUDED_PREFIXES, digest, tree_files  # noqa: E402

HEADER = (
    "# SHA-256 of every file in this release, except paths that change on every run:\n"
    "#   " + ", ".join(EXCLUDED_PREFIXES) + ", and CHECKSUMS.sha256 itself.\n"
    "# quality_gate/traceability/ is regenerated from evidence on each run and is\n"
    "# verified by READY-04 rather than by digest. Verify with:\n"
    "#   python quality_gate/scripts/verify_release_manifest.py\n"
)


def main() -> int:
    from embedded_quality_gate.release import (
        BLOCKED,
        INDETERMINATE,
        PASS,
        evaluate_delivery_preconditions,
        evaluate_readiness,
    )
    from embedded_quality_gate.repository import repo_revision
    from embedded_quality_gate.util import utc_now
    from embedded_quality_gate.version import __version__

    tests = subprocess.run(  # noqa: S603 - sys.executable running this repository's own suite
        [sys.executable, "-B", "-m", "unittest", "discover", "-s", "quality_gate/tests", "-t", "."],
        cwd=str(ROOT), capture_output=True, text=True)
    test_count = 0
    for line in tests.stderr.splitlines():
        if line.startswith("Ran ") and " test" in line:
            try:
                test_count = int(line.split()[1])
            except (IndexError, ValueError):
                test_count = 0

    closeout = ROOT / "quality_gate" / "traceability" / "REQUIREMENT_CLOSEOUT.csv"
    counts: Counter[str] = Counter()
    if closeout.is_file():
        with closeout.open(encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                counts[row.get("status", "")] += 1

    gates = list(evaluate_readiness({}, ROOT)) + list(evaluate_delivery_preconditions(ROOT))
    open_items = [f"{g.name} — {g.status}: {g.reason}" for g in gates if g.status != PASS]

    manifest = {
        "schema_version": "eqg.release-manifest/1.3",
        "name": "Project — Embedded Quality Gate applied",
        "version": __version__,
        "generated_at": utc_now(),
        "revision": repo_revision(ROOT),
        "audit_report": "QUALITY_GATE_APPLICATION_REPORT.md",
        "gate_opening_runbook": "quality_gate/docs/GATE_OPENING_RUNBOOK.md",
        "status": "release_candidate_fail_closed",
        "local_audit": {
            "tests": f"{test_count}/{test_count} PASS" if tests.returncode == 0 else f"{test_count} run, suite FAILED",
            "tests_passed": tests.returncode == 0,
            "requirements": {
                "total": sum(counts.values()),
                "pass": counts.get(PASS, 0),
                "blocked": counts.get(BLOCKED, 0),
                "indeterminate": counts.get(INDETERMINATE, 0),
            },
        },
        "open_item_count": len(open_items),
        "open_items": open_items,
        "packaging": {
            "private_key_packaged": False,
            "enforced_by": "quality_gate/scripts/verify_packaging.py",
            "recipient_action": (
                "Install the crypto extra and run `evaluate` with a new unique run ID. Evidence in this "
                "package is encrypted to the producing host's key, which is deliberately not shipped."
            ),
        },
        "checksums": {"file": "CHECKSUMS.sha256", "excluded_prefixes": list(EXCLUDED_PREFIXES)},
    }
    (ROOT / "RELEASE_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    lines = [HEADER]
    files = tree_files()
    for rel in sorted(files):
        lines.append(f"{digest(files[rel])}  {rel}\n")
    (ROOT / "CHECKSUMS.sha256").write_text("".join(lines), encoding="utf-8")

    print(json.dumps({"version": __version__, "tests": manifest["local_audit"]["tests"],
                      "requirements": manifest["local_audit"]["requirements"],
                      "open_items": len(open_items), "checksum_entries": len(files)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
