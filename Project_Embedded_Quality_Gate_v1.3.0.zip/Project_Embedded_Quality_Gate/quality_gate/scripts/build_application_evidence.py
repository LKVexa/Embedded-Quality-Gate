#!/usr/bin/env python3
"""Produce this repository's application-run evidence bundle.

Serves: READY-04 (traceable outputs), PROV-*. The traceability matrix references
an evidence bundle by path. When the gate is applied to a new repository, the
bundle the matrix inherited belongs to a different host and a different revision;
pointing at it would be exactly the "evidence points at a stale target revision"
condition the programme calls a release failure, and deleting it without
replacement would leave 1,021 rows referencing nothing.

So this script regenerates the bundle here, from this repository's own runs:

  01_tests.json                       the unit/integration suite, actually executed
  02_repository_analysis.json         deterministic analysis of this tree
  02b_original_corpus_integrity.json  the 612-file corpus check
  06_offline_evaluation.json          measured detection on the tuned corpus
  06b_heldout_evaluation.json         measured generalisation on the held-out corpus
  07_local_environment_qualification.json  what the local sandbox does and does not qualify
  08_release_readiness.json           the readiness gates, verbatim, including the blocked ones
  evidence_manifest.json              sha256 and size of every artifact above

Artifacts are written through the at-rest encryption enforcement point, like all
other evidence, and the run directory is immutable once written.

Usage: python quality_gate/scripts/build_application_evidence.py [--run-id ID]
"""
from __future__ import annotations

import argparse
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    sys.path.insert(0, str(ROOT))
    from embedded_quality_gate.analyzers import analyze_repository, validate_dmk_references
    from embedded_quality_gate.evaluation import run_heldout_evaluation, run_offline_evaluation
    from embedded_quality_gate.quality import summarize
    from embedded_quality_gate.release import (
        evaluate_delivery_preconditions,
        evaluate_readiness,
        promotion_allowed,
    )
    from embedded_quality_gate.repository import repo_revision
    from embedded_quality_gate.secure_storage import write_json
    from embedded_quality_gate.util import sha256_file, utc_now
    from embedded_quality_gate.version import __version__

    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", default=None)
    args = ap.parse_args()
    run_id = args.run_id or ("PEQG-APPLY-" + time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()))
    out = ROOT / "quality_gate" / "evidence" / run_id
    if out.exists():
        print(f"refusing to overwrite an existing evidence run: {run_id}", file=sys.stderr)
        return 2
    revision = repo_revision(ROOT)

    started = time.time()
    tests = subprocess.run(  # noqa: S603 - sys.executable running this repository's own suite
        [sys.executable, "-B", "-m", "unittest", "discover", "-s", "quality_gate/tests", "-t", "."],
        cwd=str(ROOT), capture_output=True, text=True)
    ran = 0
    for line in tests.stderr.splitlines():
        if line.startswith("Ran ") and " test" in line:
            try:
                ran = int(line.split()[1])
            except (IndexError, ValueError):
                ran = 0
    tests_artifact = {
        "command": "python -B -m unittest discover -s quality_gate/tests -t .",
        "elapsed_seconds": round(time.time() - started, 6),
        "returncode": tests.returncode,
        "status": "PASS" if tests.returncode == 0 else "FAIL",
        "tests_run": ran,
        "output_tail": tests.stderr.strip().splitlines()[-12:],
    }

    started = time.time()
    analysis = analyze_repository(ROOT)
    refs = validate_dmk_references(ROOT)
    analysis_artifact = {
        "revision": revision,
        "elapsed_seconds": round(time.time() - started, 6),
        "summary": summarize(analysis["findings"], analysis["checked_files"]),
        "dmk_references": refs,
        "manifest_drift": analysis.get("manifest_drift", {}),
    }
    analysis_artifact["status"] = "PASS" if not (
        analysis_artifact["summary"]["release_blocking"] or refs["missing"]) else "FAIL"

    integrity = subprocess.run(  # noqa: S603 - this repository's own script
        [sys.executable, str(ROOT / "quality_gate" / "scripts" / "verify_corpus_integrity.py")],
        cwd=str(ROOT), capture_output=True, text=True)
    import json as _json
    integrity_data = _json.loads(integrity.stdout) if integrity.stdout.strip() else {}
    corpus_artifact = {
        "original_files": integrity_data.get("baseline_files"),
        "changed_original_files": integrity_data.get("changed", []),
        "missing_original_files": integrity_data.get("missing", []),
        "status": "PASS" if integrity.returncode == 0 else "FAIL",
    }

    offline = run_offline_evaluation(ROOT)
    heldout = run_heldout_evaluation(ROOT)

    local_qualification = {
        "environment": "developer/local sandbox",
        "credentials": "none",
        "data_boundary": "local repository only",
        "privileged_execution": False,
        "network_used": False,
        "platform": platform.platform(),
        "python": platform.python_version(),
        "gate_version": __version__,
        "revision": revision,
        "qualified_at": utc_now(),
        "limitations": [
            "Qualifies the local sandbox only: not CI, staging, production read-only, "
            "privileged-path, or isolated security/privacy tenant execution.",
            "No human approval is created or implied by this record.",
        ],
        "promotion_behavior": {"missing_release_evidence_must_deny": True},
    }

    gates = [g.__dict__ for g in evaluate_readiness({}, ROOT)]
    preconditions = [g.__dict__ for g in evaluate_delivery_preconditions(ROOT)]
    readiness_artifact = {
        "revision": revision,
        "evaluated_at": utc_now(),
        "promotion_allowed": promotion_allowed(evaluate_readiness({}, ROOT),
                                               evaluate_delivery_preconditions(ROOT)),
        "gates": gates,
        "delivery_preconditions": preconditions,
        "blocking_external_requirements": [
            "Named human security/privacy review (READY-07)",
            "CI qualification produced by a real CI run (DEPLOY-02)",
            "Staging, production read-only, privileged-path and isolated-tenant "
            "qualifications (DEPLOY-03…06)",
        ],
    }

    artifacts = {
        "01_tests.json": tests_artifact,
        "02_repository_analysis.json": analysis_artifact,
        "02b_original_corpus_integrity.json": corpus_artifact,
        "06_offline_evaluation.json": {**offline, "run_id": run_id, "revision": revision},
        "06b_heldout_evaluation.json": {**heldout, "run_id": run_id, "revision": revision},
        "07_local_environment_qualification.json": local_qualification,
        "08_release_readiness.json": readiness_artifact,
    }
    for name, payload in artifacts.items():
        write_json(ROOT, out / name, payload, immutable=True, create_key_if_missing=True)

    manifest = {
        "schema_version": "eqg.application-evidence/1.0",
        "run_id": run_id,
        "revision": revision,
        "created_at": utc_now(),
        "gate_version": __version__,
        "artifacts": [
            {"file": (out / name).relative_to(ROOT).as_posix(),
             "sha256": sha256_file(out / name),
             "bytes": (out / name).stat().st_size}
            for name in artifacts
        ],
    }
    write_json(ROOT, out / "evidence_manifest.json", manifest, immutable=True, create_key_if_missing=True)

    print(_json.dumps({
        "run_id": run_id,
        "revision": revision,
        "evidence_dir": out.relative_to(ROOT).as_posix(),
        "tests": {"run": ran, "status": tests_artifact["status"]},
        "analysis": analysis_artifact["status"],
        "corpus_integrity": corpus_artifact["status"],
        "artifacts": len(manifest["artifacts"]),
    }, indent=2))
    return 0 if tests_artifact["status"] == "PASS" and analysis_artifact["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
