#!/usr/bin/env python3
"""Point the traceability matrix at this repository's own evidence bundle.

Serves: READY-04. The traceability CSVs reference an application-evidence bundle
by path. Applying the gate to a new repository leaves those references aimed at
the bundle of whatever repository the matrix came from — a bundle that does not
exist here and was produced against a revision that does not exist here.

This script rewrites those references to the newest bundle under
``quality_gate/evidence/`` that carries an ``evidence_manifest.json``, and reports
what it changed. It touches only generated traceability artifacts; it never edits
a requirement's status, and it never invents a reference to a file that is absent.

Usage: python quality_gate/scripts/retarget_traceability_evidence.py [--run-id ID]
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRACE = ROOT / "quality_gate" / "traceability"
EVIDENCE = ROOT / "quality_gate" / "evidence"
TARGETS = ("TRACEABILITY_MATRIX_APPLIED.csv", "TRACEABILITY_MATRIX.csv",
           "REQUIREMENT_CLOSEOUT.csv", "APPLICATION_ORDER.csv", "MANIFEST.json")
REF = re.compile(r"quality_gate/evidence/([A-Za-z0-9._-]+)/([A-Za-z0-9._-]+)")


def newest_bundle() -> str | None:
    candidates = [p.parent for p in EVIDENCE.glob("*/evidence_manifest.json")]
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime).name


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", default=None, help="bundle to point at; default is the newest")
    args = ap.parse_args()
    run_id = args.run_id or newest_bundle()
    if not run_id:
        print("no application-evidence bundle found (no quality_gate/evidence/*/evidence_manifest.json)",
              file=sys.stderr)
        return 2
    if not (EVIDENCE / run_id / "evidence_manifest.json").is_file():
        print(f"not an application-evidence bundle: {run_id}", file=sys.stderr)
        return 2

    changed = {}
    replaced_ids: set[str] = set()
    for name in TARGETS:
        path = TRACE / name
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        stale: set[str] = set()

        def rewrite(match: re.Match, stale: set[str] = stale) -> str:
            """Rewrite one reference, but only when it is genuinely dangling.

            A reference to a *different* run that still exists is left alone: the
            evaluate runs and the application bundle are separate evidence, and
            re-pointing a live reference would corrupt it rather than repair it.
            The tail after the run id must also exist in the target bundle, so a
            reference is never redirected to a file that is not there.
            """
            ref = match.group(0)
            rid, tail = match.group(1), match.group(2)
            if rid == run_id:
                return ref
            if (EVIDENCE / rid / tail).exists():
                return ref
            if not (EVIDENCE / run_id / tail).exists():
                return ref
            stale.add(rid)
            return f"quality_gate/evidence/{run_id}/{tail}"

        new_text = REF.sub(rewrite, text)
        if new_text == text:
            continue
        path.write_text(new_text, encoding="utf-8")
        changed[name] = sorted(stale)
        replaced_ids |= stale

    import json
    print(json.dumps({"run_id": run_id, "files_updated": changed,
                      "replaced_run_ids": sorted(replaced_ids)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
