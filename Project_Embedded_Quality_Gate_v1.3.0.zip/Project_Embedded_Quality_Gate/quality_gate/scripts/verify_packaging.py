#!/usr/bin/env python3
"""Refuse to package a tree that leaks key material or foreign evidence.

Serves: XSEC-*, PROV-*. The v1.3.0 upload shipped
``.eqg_runtime/keys/eqg_local_key.pem`` — a live RSA private key — inside the
delivered archive, while ``.gitignore`` excluded the directory and the release
manifest recorded ``"private_key_packaged": false``. Three statements said the
key was absent and the key was there. This script is the enforcement point that
makes the claim checkable instead of asserted.

Refuses when the tree contains
  * a PEM private key block, in any file;
  * an ``.eqg_runtime/`` directory (host key material and scratch state);
  * an evidence run whose manifest is bound to a different repository revision,
    which cannot be verified here and reads as this repository's history.

Exit 0 when the tree is safe to package, 1 otherwise.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PRIVATE_KEY = re.compile(rb"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----")
SKIP_PARTS = {".git", "__pycache__", ".pytest_cache", ".ruff_cache"}
BINARY_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf", ".zip", ".tar", ".gz", ".woff", ".woff2"}


def main() -> int:
    sys.path.insert(0, str(ROOT))
    from embedded_quality_gate.repository import repo_revision

    revision = repo_revision(ROOT)
    key_files: list[str] = []
    runtime_dirs: list[str] = []
    foreign_evidence: list[str] = []

    for path in sorted(ROOT.rglob("*")):
        parts = path.parts
        if any(part in SKIP_PARTS for part in parts):
            continue
        rel = path.relative_to(ROOT).as_posix()
        if path.is_dir():
            if path.name == ".eqg_runtime":
                runtime_dirs.append(rel)
            continue
        if not path.is_file() or path.suffix.lower() in BINARY_SUFFIXES:
            continue
        try:
            if PRIVATE_KEY.search(path.read_bytes()):
                key_files.append(rel)
        except OSError:
            continue

    evidence_root = ROOT / "quality_gate" / "evidence"
    if evidence_root.is_dir():
        for manifest in sorted(evidence_root.glob("*/run_manifest.json")):
            rel = manifest.relative_to(ROOT).as_posix()
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                # Encrypted manifests are the normal case and are not readable
                # here; an unreadable manifest is not evidence of a foreign run.
                continue
            recorded = data.get("revision")
            if recorded and recorded != revision:
                foreign_evidence.append(rel)

    problems = []
    if key_files:
        problems.append(f"{len(key_files)} file(s) contain a private key block, first: {key_files[0]}")
    if runtime_dirs:
        problems.append(f"{len(runtime_dirs)} .eqg_runtime director(y/ies) present, first: {runtime_dirs[0]}")
    if foreign_evidence:
        problems.append(f"{len(foreign_evidence)} evidence run(s) bound to another revision, first: {foreign_evidence[0]}")

    print(json.dumps({
        "revision": revision,
        "private_key_files": key_files,
        "runtime_directories": runtime_dirs,
        "foreign_evidence_runs": foreign_evidence,
        "safe_to_package": not problems,
        "problems": problems,
    }, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
