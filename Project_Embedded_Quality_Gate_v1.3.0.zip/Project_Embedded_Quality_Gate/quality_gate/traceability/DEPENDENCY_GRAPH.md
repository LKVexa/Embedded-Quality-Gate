# Phase Dependency Graph

- **P00 — Program definition & audit closure** ← ENTRY
- **P01 — Authority, identity & policy foundation** ← P00
- **P02 — Canonical contracts, IDs & API schemas** ← P00, P01
- **P03 — State, storage & provenance ledger** ← P01, P02
- **P04 — Authorized data ingestion & retrieval** ← P01, P02, P03
- **P05 — Diff parsing & impact analysis** ← P02, P04
- **P06 — Deterministic analyzers & test/coverage engines** ← P02, P04, P05
- **P07 — Quality model, repository norms & ranking** ← P03, P05, P06
- **P08 — Model orchestration, uncertainty & abstention** ← P01, P02, P03, P04, P06, P07
- **P09 — Authoring integration & quality summary UX** ← P05, P06, P07, P08
- **P10 — Human review & approval control** ← P01, P02, P03, P09
- **P11 — Security, privacy & sandbox hardening** ← P01, P02, P03, P04, P06, P08, P10
- **P12 — Observability & operational controls** ← P03, P04, P06, P08, P10, P11
- **P13 — Unit & integration verification** ← P01, P02, P03, P04, P05, P06, P07, P08, P09, P10, P11, P12
- **P14 — Adversarial, E2E & offline evaluation** ← P13
- **P15 — Deployment environments & pilot rollout** ← P14
- **P16 — Production-readiness gate** ← P15
- **P17 — Documentation, acceptance & handoff** ← P16

## Critical sequencing invariant

No model-generated finding becomes author-visible before authority/scope, canonical schemas, revision pinning/provenance, and deterministic analyzer outputs are available. No state-changing capability is enabled before human-review, policy, audit, and bypass-resistance gates pass.
