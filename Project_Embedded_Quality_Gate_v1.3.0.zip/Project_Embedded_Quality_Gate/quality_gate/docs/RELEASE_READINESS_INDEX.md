# Release and Readiness Index — v1.0.0

Authoritative controls: `embedded_quality_gate/release.py`, `quality_gate/config/release_change_control.json`, `quality_gate/config/deployment_environments.json`.

Required documents: architecture; data flow/trust boundaries; source inventory; permission matrix; threat model; model/tool inventory; provenance schema; run-state schema; human approval policy; evaluation plan; incident/rollback runbook; limitations/non-goals.

Promotion is fail-closed. This candidate is not production-qualified while non-local deployment environments, named human security/privacy review, and release sign-off are absent.
