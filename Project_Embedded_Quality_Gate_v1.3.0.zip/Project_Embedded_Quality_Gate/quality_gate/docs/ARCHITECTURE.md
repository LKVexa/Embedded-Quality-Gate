# Architecture — Embedded Quality Gate v1.0.0
Owner: platform role  
Review trigger: any contract, policy, storage, model/tool, or release-gate version change.

```text
Repository / diff
      |
      v
[Scope + Authority] -- default deny --> [Ingestion + canonical evidence]
      |                                      |
      v                                      v
[Policy enforcement]                [Diff/impact + deterministic analyzers]
      |                                      |
      +----------------------+---------------+
                             v
                    [Canonical quality model]
                             |
                  optional authorized context
                             v
                    [Model orchestration]
                    (default = abstain)
                             |
                             v
                     [Quality summary]
                             |
                             v
                  [Human review / approval]
                             |
                             v
                 [Decision + provenance ledger]
                             |
                             v
                [Independent verification]
                             |
                             v
                    [Release readiness]
```

Authoritative implementation: `embedded_quality_gate/`. Contracts: `quality_gate/contracts/`. Policy: `quality_gate/config/policy.json`.
