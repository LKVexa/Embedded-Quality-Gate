# P00 Program Definition — v1.0.0

The machine-readable program controls are split across `quality_gate/config/`: measurable thresholds, toolchain matrix, role/RACI map, source inventory, finding taxonomy, data governance, release/change control, deployment inventory, and policy. The application order and traceability matrix are retained under `quality_gate/traceability/`. Delivery is dependency ordered P00 through P17 and release promotion defaults to deny.
