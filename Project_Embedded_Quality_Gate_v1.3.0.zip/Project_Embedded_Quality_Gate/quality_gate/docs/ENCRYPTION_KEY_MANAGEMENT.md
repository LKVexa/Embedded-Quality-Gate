# Encryption and Key Management — v1.2.0 (XSEC-04)

## Enforced storage path

`embedded_quality_gate.secure_storage` is the write/read enforcement point for paths listed in `quality_gate/config/encryption.json`. v1.1.0 had a capable crypto provider but evidence writers bypassed it and wrote plaintext JSON. v1.2.0 routes protected run evidence and protected run state through the enforcement layer; protected plaintext is rejected when verification requires encryption.

| Layer | Algorithm | Note |
|---|---|---|
| Payload | **AES-256-GCM** | Authenticated encryption; associated data binds ciphertext to its repository-relative path. |
| Data key | 256-bit fresh key per envelope | Generated with `secrets.token_bytes`; never stored in cleartext. |
| Key wrapping | **RSA-OAEP / SHA-256** | Wraps each data key using the configured provider. |
| Run integrity | SHA-256 payload inventory | The encrypted run manifest binds each evidence filename to the canonical plaintext payload hash and target repository revision. |

Protected JSON evidence uses immutable exclusive-create semantics. Reusing a run ID is refused rather than overwriting prior evidence. Protected provenance JSONL records, when used under an encrypted path, are encrypted per record and bind associated data to path plus record index.

## Reference provider

`local_rsa` stores an RSA-3072 private wrapping key at `.eqg_runtime/keys/eqg_local_key.pem`, git-ignored and mode 0600 where supported. The key is created only on the host that writes/decrypts the evidence.

This is a reference provider. The private key being on the same host as ciphertext is a material limitation. Production must replace it with managed key custody so the wrapping key does not leave the managed boundary.

## Fail-closed behavior

If encryption is enabled but the crypto backend/provider is unavailable, a protected write raises `EncryptionUnavailable`. There is no fallback to plaintext. Readiness accepts only decryptable protected evidence with a valid current-revision manifest.

## In transit

Repository-local mode has no network transport, so in-transit status is `not_applicable`, not `enforced`. CI/staging/production networked deployments must enable and qualify transport encryption as part of their environment qualification.

## Rotation and backup

The reference configuration sets a 90-day maximum wrapping-key age. Production rotation should re-wrap data keys rather than rewriting ciphertext payloads where the provider supports it. Backups that include encrypted evidence must preserve the corresponding managed-key recovery path; copying ciphertext without recoverable key custody does not constitute a restorable backup.

## Packaging rule

Do not package `.eqg_runtime/keys/` into distributable release archives. A recipient should create a new host-bound key and run `evaluate` to generate current encrypted evidence on that host. Historical plaintext v1.1.0 evidence is not accepted as current readiness proof by v1.2.0.
