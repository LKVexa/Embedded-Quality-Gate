# Gate Opening Runbook — v1.3.0

Owner: release authority / environment owner. Review trigger: any code, policy, model/tool, schema, or deployment change.

This runbook distinguishes gates the repository can prove locally from gates that require an external environment or a named human decision. Do not copy a template to its live filename until the represented action actually occurred. v1.3.0 rejects placeholder values, model identities, missing evidence_refs, mismatched environment names, and (for READY-07) stale document hashes.

## 1. Establish current revision and local evidence

Install the optional crypto provider, run tests, then create a unique evidence run:

```sh
pip install -e ".[crypto]"
python -m unittest discover -s quality_gate/tests -t .
python -m embedded_quality_gate analyze --repo .
python -m embedded_quality_gate evaluate --repo . --run-id EQG-LOCAL-<UNIQUE-ID>
python -m embedded_quality_gate readiness --repo .
```

A successful evaluation closes the measured grounding/evaluation condition and XEVAL-06 local read/draft-only pilot condition for that exact repository revision. The run is rejected if its ID already exists, and incomplete runs without a valid manifest cannot be reused. Protected evidence must be encrypted, decryptable, evaluation-passed, and hash-consistent with its manifest. Latest-run selection uses parsed creation time, not directory name.

## 2. DEPLOY-02 — qualify CI

Run `.github/workflows/validation.yml` on the same source revision. The `gate` job derives `smoke_pass` / `security_pass` / `rollback_pass` from the encrypted evaluate artifacts rather than hardcoding True. Preserve the CI run URL/ID and evidence artifact. Copy the uploaded `ci_qualification.json` into `quality_gate/environments/ci_qualification.json`. The record must:

- omit `"template": true`
- set `environment` to `ci`
- name the current `repo_revision()`
- include non-placeholder `qualified_by`, `qualified_at`, `credentials_boundary`, `data_boundary`
- include `evidence_refs` that resolve (local path and/or CI URL)
- set the three pass booleans true only if those checks actually ran and passed

Until that record exists, the gate reports DEPLOY-02 as INDETERMINATE rather than assuming CI worked. YAML existence is still not a PASS.

## 3. DEPLOY-03 — qualify staging/pre-production

Deploy the same revision to the actual staging/pre-production environment. Exercise a smoke run, security/bypass suite, and rollback/abort drill. Record environment-specific credential scope and data boundary. Complete `staging_qualification.template.json` as `staging_qualification.json` only after those checks pass. `environment` must be `staging`. `NOT_APPLICABLE` is not accepted for this gate.

## 4. DEPLOY-04 — production read-only integration

If production read-only integration applies, connect the gate with read-only/draft-only authority, prove state-changing actions are unavailable, run smoke/security/rollback checks, and complete `production_readonly_qualification.json` with `environment: production_readonly`.

If this deployment mode is genuinely not applicable, `NOT_APPLICABLE` is accepted only with a reason, a named human `approved_by` that is not a model identity, and the **current** repository revision. It is not inferred automatically and a leftover N/A from another revision does not apply.

## 5. DEPLOY-05 — privileged execution path

Only if privileged execution is explicitly part of the intended deployment, qualify it separately with short-lived credentials, a distinct human authorization path, bypass-resistance checks, and rollback. Complete `privileged_path_qualification.json` with `environment: privileged_path`.

If privileged execution is outside the product scope, record a human-approved `NOT_APPLICABLE` disposition that names the current revision rather than creating a fake privileged environment.

## 6. DEPLOY-06 — isolated security/privacy test tenant

Provision an isolated tenant/data set and run cross-project leakage, sensitive-output, retention/deletion, redaction, and rollback checks. Complete `isolated_test_qualification.json` only with evidence from that environment. `environment` must be `isolated_test`. `NOT_APPLICABLE` is not accepted.

## 7. READY-07 — named human security/privacy review

Copy `quality_gate/approvals/security_privacy_review.template.json` to `security_privacy_review.json` after an actual reviewer has inspected the threat model, trust boundaries, encryption/key limitations, data governance, retention policy, bypass tests, and known limitations.

The file must:

- omit `"template": true`
- name a human `reviewer` (model identities such as Grok, ChatGPT, Claude, Copilot are rejected)
- use `reviewer_role` of `security_privacy_reviewer`, `human_reviewer`, or `release_authority`
- set `decision` to `APPROVED`
- set `reviewed_revision` equal to the current `repo_revision()`
- set `reviewed_at` to a real ISO-8601 timestamp no more than 90 days old
- list existing `evidence_refs`
- include `reviewed_document_hashes` matching SHA-256 of the five load-bearing docs (compute with `embedded_quality_gate.release.review_document_hashes`)

This is a named-file human attestation bound to those documents. It is not a cryptographic identity proof. The model/tool cannot create this approval for itself.

## 8. Final promotion check

Run:

```sh
python -m embedded_quality_gate readiness --repo .
```

Promotion is allowed only when every READY gate and every delivery precondition returns PASS. Any missing, stale, malformed, placeholder, plaintext-protected, or revision-mismatched evidence keeps promotion closed. The library API also refuses promotion when delivery preconditions are omitted.
