# Data Governance — v1.3.0

Owner: documentation/release roles. Review trigger: encryption, retention, or evidence-path change.

This document must match `config/data_governance.json`. READY-07 binds its approval to the hash of this file.

## What the local/reference mode actually stores

- **Evidence** under `quality_gate/evidence/**` is envelope-encrypted at rest (AES-256-GCM data keys wrapped with RSA-OAEP/SHA-256). Writes refuse rather than falling back to plaintext.
- **Run state** under `.eqg_runtime/state/**` is likewise protected when the encryption policy is enabled.
- **Wrapping key:** the local RSA provider stores a PKCS#8 private key at `.eqg_runtime/keys/eqg_local_key.pem` (git-ignored, mode 0600). This is a reference provider, not production key custody. Production must substitute managed KMS/HSM so the unwrapping key never sits beside the ciphertext.
- **Approvals and environment qualification records** are plaintext JSON by design so a human or CI system can write them without the wrapping key. They are excluded from `repo_revision()` so they cannot self-invalidate, and the gate therefore validates placeholders, identity, timestamps, evidence refs, and (for READY-07) hashes of load-bearing documents instead of encrypting those files.

## Retention

- Reference mode retains append-only audit/evidence records **indefinitely**. The gate will not delete the audit trail.
- A 90-day figure is not applied locally. Production must define a governed archival/destruction policy that preserves required audit guarantees rather than silently rewriting or deleting the reference trail.
- Backup restore is not permitted to overwrite immutable encrypted evidence.

## Network and secrets

- Local reference mode makes no network calls and ships with no connector credentials.
- Secret values are redacted from structured logs by key name and by value shape.
- In-transit encryption is `not_applicable` here because there is no transit. Networked CI/staging/production must enable and qualify transport protection in their own environment.
