# Provenance Schema — v1.0.0
Owner: storage/security roles. Review trigger: provenance contract change.

Each ledger event records event type, UTC timestamp, pinned source revision, authority ID where applicable, payload, previous record hash, and canonical record hash. `AppendOnlyLedger.verify()` recomputes the entire chain before every append. Evidence records carry stable evidence IDs, source revision, observation time, SHA-256, location, and freshness. Model-derived conclusions must preserve evidence IDs and be labeled inference.
