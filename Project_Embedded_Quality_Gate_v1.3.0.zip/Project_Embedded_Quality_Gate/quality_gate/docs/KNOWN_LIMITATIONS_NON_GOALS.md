# Known Limitations and Non-Goals — v1.3.0 (applied to the generic project repository)

Owner: documentation/release roles. Review trigger: capability or deployment change.

This document is load-bearing: READY-08 fails if it is missing or a stub. It records what the repository can and cannot prove; unavailable environments and human approvals are never converted into synthetic PASS states.

## Measured local status

- The content-defense corpus contains **125 labelled cases**: 50 attacks and 75 benign controls. v1.2.0 measures **1.00 attack recall** and **0.00 false-positive rate**, above/below the configured 0.98/0.05 thresholds respectively. The v1.1.0 misses ATK-0007, ATK-0020, and ATK-0029 were closed with general document-level signals for outbound GET requests and unbounded loops; each signal is deliberately sub-threshold alone so ordinary network clients and service loops remain benign.
- The repository-local read/draft-only pilot is implemented and is part of `evaluate`. It proves the permitted read/analyze/draft actions work, privileged actions are refused, deterministic analysis runs, and the repository revision is byte-stable before/after. This qualifies **XEVAL-06 only**; it is not a substitute for CI, staging, production, or isolated-tenant qualification.
- Deterministic analysis covers the custom JA/DeepML extensions plus Python and JSON implementation/configuration files. It is not a semantic compiler for the custom DSLs.
- The deterministic analyzers now include a **provenance manifest drift check**. It verifies every `SHA256SUMS*.txt` and `MANIFEST.json` in the repository against what is on disk. It is read-only: the manifests it inspects are corpus files, and the corpus is immutable.

## Generalisation: what the 1.00 recall figure does and does not show

- The 125-case content-defense corpus above is built from the BIPIA **test** splits, and the detector's signals were developed against those same cases. A rate measured there shows **fit**, not generalisation, and should not be read as a general detection claim.
- A second, **held-out** corpus (`quality_gate/corpus/heldout_corpus.json`, 328 cases: 50 attacks and 278 benign) is therefore measured alongside it. It is disjoint by construction — attacks and benign task prompts from the BIPIA **train** splits, plus 203 benign business emails from a different donor and a different content domain — and the disjointness is asserted by test, not by assumption.
- Measured on this repository: **0.98 attack recall (49/50) and 0.00 false-positive rate over 278 benign cases**, against declared floors of 0.80 and 0.10 that were written down before the measurement was read.
- **The one miss is documented rather than fixed.** `HO-ATK-0012` ("Dumpster Diving") moves a file out of a trash directory and uploads it over **FTP**; `ftplib` is not among the network-exfiltration signals, and the remaining directive signal is deliberately sub-threshold on its own. Adding a signal for it now would tune the detector against its own held-out corpus and destroy the only unbiased measurement in this repository. The gap is real and stays recorded here until it is closed against a *new* held-out set.
- The held-out result is **reported, not gating**: `evaluate` fails closed if the corpus is missing, but the rates themselves do not block a release. Promoting them to release gates changes the release semantics of an audited programme and is an owner decision, not a repository-local one. See `quality_gate/config/thresholds.json` → `heldout.rationale`.

## External environments and human actions still required

- **READY-07** remains BLOCKED until a named human security/privacy reviewer records an approval for the current repository revision in `quality_gate/approvals/security_privacy_review.json`. v1.3.0 rejects placeholder/model identities, requires ISO-8601 `reviewed_at`, existing `evidence_refs`, an allowed reviewer role, and SHA-256 hashes of the load-bearing review documents. That is a named-file human attestation bound to those documents — **not** a cryptographic identity proof. A human who can write the file can still complete it; a model identity cannot.
- **DEPLOY-02** remains INDETERMINATE until the CI workflow actually runs on the revision and a CI qualification record is retained. The record must cite evidence_refs, non-placeholder fields, the `ci` environment name, and a current revision. Copying a three-boolean PASS file is no longer sufficient.
- **DEPLOY-03** requires a real staging/pre-production qualification of the same shape.
- **DEPLOY-04** requires a real production read-only integration qualification, or a named human-approved `NOT_APPLICABLE` disposition that names the **current** revision.
- **DEPLOY-05** requires a separately authorized privileged-execution qualification, or a named human-approved `NOT_APPLICABLE` disposition that names the **current** revision.

`quality_gate/scripts/make_approval_request.py` generates the **unsigned** requests these three gates are waiting on — `quality_gate/approvals/READY-07.request.json` and `quality_gate/environments/DEPLOY-0{4,5}.request.json` — each bound to the current revision and to the SHA-256 of every document under review. They are requests, not approvals: they carry `status: "UNSIGNED"`, readiness never reads them, and a signature only counts once a named human saves the completed file under the name readiness does read.
- **DEPLOY-06** requires a real isolated security/privacy test tenant/data-set qualification.

Exact record formats and steps are in `GATE_OPENING_RUNBOOK.md`. These items are intentionally not auto-opened by repository-local code. Model output cannot create READY-07.

## Evidence encryption and portability

- New protected run evidence is envelope-encrypted (AES-256-GCM; RSA-OAEP/SHA-256 wrapping) through the storage enforcement layer. A crypto backend/provider failure refuses the write.
- The reference RSA private wrapping key lives under `.eqg_runtime/keys/` on the same host as ciphertext. This is not production key custody and does not defend against full host compromise. Production deployment must substitute managed KMS/HSM custody appropriate to its environment.
- The key is git-ignored and should not be packaged as a portable release secret. **This is now enforced rather than stated:** `quality_gate/scripts/verify_packaging.py` refuses to package a tree containing a PEM private key, an `.eqg_runtime/` directory, or evidence bound to another revision. The v1.3.0 upload shipped its wrapping key inside the archive while its release manifest recorded `"private_key_packaged": false`; that is the defect this check closes. Consequently, encrypted evidence generated on one host is not expected to be decryptable on another host unless key custody is deliberately migrated. A freshly extracted package should generate its own current evidence run.
- Historical v1.1.0 evidence remains historical plaintext. v1.2.0 readiness does not accept it as current-revision proof because current evidence must have a decryptable encrypted run manifest and matching payload hashes.
- In-transit encryption is `not_applicable` in repository-local mode because there is no network transport. Networked CI/staging/production deployments must enable and qualify transport protection in their own environment.

## Retention and audit history

- Reference mode treats audit/evidence records as append-only and retains them indefinitely; retention does not silently delete the audit trail. Production deployments must define a governed archival/destruction policy that preserves required audit guarantees.
- Protected JSON run evidence is immutable by run ID. Protected JSONL provenance records are encrypted per record when used under a configured protected path and append operations are serialized to avoid concurrent hash-chain forks.

## Tooling and platform limits

- The runtime remains stdlib-only except for the optional `cryptography` extra needed to satisfy protected at-rest writes. Development linting uses the optional dev extra (`ruff`, `pytest`). SARIF output is produced by a local writer for the same reason: the donor formatter that supplied the record shape is JavaScript and carries its own dependency tree.
- `RELEASE_MANIFEST.json` and `CHECKSUMS.sha256` are verified against the tree by `quality_gate/scripts/verify_release_manifest.py`, which excludes only the paths that change on every run (`quality_gate/evidence/**`, `.eqg_runtime/**`) and names those exclusions in the checksum file's own header.
- No production SCM, ticket, external documentation, security-platform, production model, or privileged-execution connector is configured in the repository-local reference deployment.
- The deterministic fixture model is test-only and is not evidence of production LLM quality.
- No production approver, security reviewer, or release authority is invented in the repository.
- The minimal-impact mapper has repository-specific dependency logic for the supplied suite corpus; general multi-language semantic dependency analysis still requires language/toolchain adapters.

## Standing non-goals

- No production JA/DeepML compiler/runtime is claimed.
- No silent source/test modification, auto-submit, auto-approval, or model self-approval is permitted.
- No production environment, credential boundary, security sign-off, or rollback exercise is claimed unless its evidence record exists for the current revision.
