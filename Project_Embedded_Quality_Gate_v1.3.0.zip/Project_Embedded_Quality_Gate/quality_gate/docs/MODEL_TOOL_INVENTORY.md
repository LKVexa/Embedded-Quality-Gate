# Model and Tool Inventory — v1.0.0
Owner: model/security roles. Review trigger: provider, model, prompt, context policy, or tool allowlist change.

Production model provider: none (safe abstention). Test-only provider: deterministic fixture provider; it cannot access external facts and must cite supplied evidence. Tool runner: `SafeCommandRunner`, no shell, explicit allowlist, bounded timeout, scrubbed environment, repository-confined working directory, privileged `execute` permission required. Default allowlist: empty.
