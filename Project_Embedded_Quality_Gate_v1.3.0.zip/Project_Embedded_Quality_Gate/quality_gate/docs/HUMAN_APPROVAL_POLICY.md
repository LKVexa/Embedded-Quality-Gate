# Human Approval Policy — v1.0.0
Owner: security/release roles. Review trigger: approval semantics change.

Suggestions are staged, evidence-linked artifacts. Approval is a separate record bound to the exact suggestion ID and scope. Privileged actions require explicit human approval. Self-approval is denied. Model output can never create an approval. Approval does not override explicit denial, repository-scope mismatch, expired authority, or missing evidence. Production approvers must be configured outside the repository; they are intentionally not invented here.
