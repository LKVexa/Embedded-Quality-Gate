# Source and Connector Inventory — v1.0.0
Owner: platform/security roles. Review trigger: source authorization or connector change.

Authoritative machine-readable inventory: `quality_gate/config/source_inventory.json`. Only the uploaded/local repository is authorized in this release candidate. SCM, CI, ticket, external documentation, and security-platform connectors are intentionally unconfigured and default-denied.
