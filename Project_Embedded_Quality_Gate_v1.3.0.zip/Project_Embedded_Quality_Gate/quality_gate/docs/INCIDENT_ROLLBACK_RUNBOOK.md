# Incident and Rollback Runbook — v1.0.0
Owner: operations/release roles. Review trigger: storage/deployment/promotion procedure change.

1. Stop privileged execution and model/tool providers; retain read-only deterministic analysis if safe.
2. Freeze the affected revision and preserve state, logs, ledger, failed evidence, and approval records.
3. Verify provenance chain before triage. Do not delete or rewrite failure evidence.
4. Revert the smallest mutable change set or restore the last verified backup.
5. Re-run contract, security/bypass, regression, and provenance verification.
6. Require a new human approval for changed scope/content. Never reuse stale approval.
7. Promotion remains denied until rollback exercise evidence and security/privacy review are present.

Local backup/restore behavior is exercised by `test_backup_recovery.py`. External production rollback remains unqualified until an actual deployment environment is supplied.
