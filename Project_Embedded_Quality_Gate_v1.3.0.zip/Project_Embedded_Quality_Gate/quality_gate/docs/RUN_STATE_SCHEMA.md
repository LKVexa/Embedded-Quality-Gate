# Run-State Schema — v1.0.0
Owner: platform/storage roles. Review trigger: phase/workflow contract change.

`RunState` persists run ID, target revision, P00-P17 status, per-item terminal dispositions, and append-style state history via atomic file replacement. A phase cannot be marked PASS if a declared prerequisite phase is not PASS. The schema is documented at `quality_gate/contracts/run_state.schema.json`.
