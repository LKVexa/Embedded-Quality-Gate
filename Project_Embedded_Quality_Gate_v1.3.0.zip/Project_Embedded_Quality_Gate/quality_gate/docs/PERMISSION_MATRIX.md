# Permission Matrix — v1.0.0
Owner: security role. Review trigger: permission or role change.

The machine-readable source is `quality_gate/config/policy.json`. Read/analyze/draft are distinct from modify/commit/approve/deploy/communicate/execute. All privileged actions require explicit human approval; unknown actions are denied. Approval requires a human-review/release role and self-approval is denied. Production identities are not embedded in the repository.
