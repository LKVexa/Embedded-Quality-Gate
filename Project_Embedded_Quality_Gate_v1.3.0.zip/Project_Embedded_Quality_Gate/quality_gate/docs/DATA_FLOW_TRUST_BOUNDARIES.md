# Data Flow and Trust Boundaries — v1.0.0
Owner: security role. Review trigger: connector, tool, model, or deployment-boundary change.

Trust boundaries are explicit: uploaded/local repository content is untrusted data; authority metadata is trusted only after schema and freshness checks; external connectors are absent and therefore denied; model context accepts only authorized evidence IDs; tool execution is allowlist-only with `shell=False`; approval must come from a distinct human-review role; provenance is append-only hash chained; promotion consumes gate evidence and fails closed if any mandatory fact is absent.
