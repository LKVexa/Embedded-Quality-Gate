# Evaluation Plan and Benchmark Corpus — v1.0.0
Owner: evaluation role. Review trigger: analyzer/model/policy/version or threshold change.

The local corpus covers valid/invalid contracts, default denial, path escape, privileged-action approval, provenance tampering, phase-order bypass, diff parsing, missing DMK references, structural source checks, unauthorized model evidence, explicit abstention, self-approval, tool allowlisting, workflow skipping, log redaction, release fail-closed/pass fixtures, and backup/restore. `quality_gate/tests/` is the executable corpus; `quality_gate/fixtures/` stores representative deterministic inputs. Performance qualification uses repository inventory/analyzer wall-clock metrics retained in run evidence.
