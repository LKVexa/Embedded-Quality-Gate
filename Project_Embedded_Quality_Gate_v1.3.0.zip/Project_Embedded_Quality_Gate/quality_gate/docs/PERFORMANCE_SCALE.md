# Performance and Scale Qualification — v1.0.0

Configured maximums are in `config/thresholds.json`: 100,000 files, 2 GiB repository profile, 5 MiB diff, 4 MiB individual file, concurrency 4, 30 s deterministic analyzer timeout. Local evidence records actual inventory and analyzer wall-clock time. Pathological dependency-graph and large external build/test-suite qualification are not claimed without representative runnable toolchains.
