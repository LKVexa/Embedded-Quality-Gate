$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$EqgArgs = @($args)
if ($EqgArgs.Count -eq 0) { $EqgArgs = @("analyze", "--repo", ".") }
if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 -B -m embedded_quality_gate @EqgArgs; exit $LASTEXITCODE }
if (Get-Command python -ErrorAction SilentlyContinue) { & python -B -m embedded_quality_gate @EqgArgs; exit $LASTEXITCODE }
Write-Error "Python 3 was not found on PATH."
exit 127
