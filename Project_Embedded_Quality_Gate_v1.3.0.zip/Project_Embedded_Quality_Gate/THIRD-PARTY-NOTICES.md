# Third-party notices

Components pulled from the GitHub Junkyard into this repository, with the licence each carries.
Every entry names what was taken and how it was adapted. All nine donors are MIT-licensed; no copyleft
and no unlicensed component is present. Entries 1-6 arrived with the v1.3.0 gate; entries 7-9 were
pulled when the gate was applied to this repository (work order
`Project_Embedded_Quality_Gate-20260904-2207`).

---

## 1. microsoft/amplifier-bundle-redaction — vendored

**Used as:** `embedded_quality_gate/redaction.py`
**Taken:** `redaction/__init__.py`, copied byte-for-byte apart from a provenance header.
**Adaptation:** none to the file itself. EQG-specific configuration lives in
`embedded_quality_gate/redaction_policy.py`, which *extends* the frozen defaults (adding hash-chain
join keys as identifier keys so provenance digests survive byte-identical) and never replaces them.

```
MIT License

Copyright (c) Microsoft Corporation.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

---

## 2. microsoft/custom-azure-data-encryption — architecture adapted, code not copied

**Used as:** `embedded_quality_gate/crypto.py`
**Taken:** the envelope-encryption architecture from `azure_encryption_helper/encryptor.py`,
`aescipher.py` and `aeskeywrapper.py` — a random data key protecting the payload, wrapped by an
asymmetric key held behind a provider boundary.
**Adaptation:** the donor's cipher implementation is deliberately not carried over. It used AES-CBC
with NUL padding stripped by `rstrip` (lossy and unauthenticated) and SHA-1 in OAEP/MGF1. This
implementation uses AES-256-GCM with the record's associated data bound into the tag, and
RSA-OAEP/SHA-256. Azure Key Vault is replaced by a local key provider plus a fail-closed null
provider. Licence text as in §1 (MIT, Microsoft Corporation).

---

## 3. microsoft/BIPIA — data corpus

**Used as:** `quality_gate/corpus/content_defense_corpus.json`
**Taken:** `benchmark/code_attack_test.json` (indirect prompt-injection payloads) and
`benchmark/text_attack_test.json` (benign control prompts), from
*"Benchmarking and Defending Against Indirect Prompt Injection Attacks on Large Language Models"*.
**Also taken:** `benchmark/code_attack_train.json` and `benchmark/text_attack_train.json` — the
**train** splits — which become the attack half and part of the benign half of
`quality_gate/corpus/heldout_corpus.json`. The tuned corpus uses the *test* splits, so the train
cases have never been seen by the detector and can measure generalisation rather than fit.
**Adaptation:** payload text is unmodified so results stay comparable with the published benchmark;
only the case structure (ids, labels, classes) is ours. Exact donor digests are recorded in
`quality_gate/corpus/corpus_manifest.json` and `quality_gate/corpus/heldout_manifest.json`, and
provenance in `quality_gate/corpus/SOURCE.md`.
Licence: MIT (Microsoft Corporation); text as in §1.

---

## 4. microsoft/sarif-tools — CI and lint configuration

**Used as:** `.github/workflows/validation.yml`, `.pylintrc`
**Taken:** the hygiene/test workflow structure and the pylint type-check exclusion file.
**Adaptation:** Poetry replaced with pip so the gate keeps zero runtime dependencies; the
`if: github.repository == 'microsoft/sarif-tools'` guard removed; a Python version matrix added; and
two gate-specific jobs added (verification suites with evidence upload, and original-corpus
integrity). Licence: MIT (Microsoft Corporation); text as in §1.

---

## 5. microsoft/AI-Red-Teaming-Playground-Labs — record shape only

**Used as:** the case schema in `embedded_quality_gate/adversarial.py`
**Taken:** the `challenge_id` / `challenge_title` / `category` / `goal` record shape from
`challenges/challenges.json`.
**Adaptation:** no challenge content is copied. Those labs target chat assistants; the seven cases
here are written against this gate's own guardrails.
Licence: MIT, Copyright (c) 2025 Microsoft Corporation; text otherwise as in §1.

---

## 6. microsoft/opentelemetry-distro-python — convention only

**Used as:** attribute keys and span operation names in `embedded_quality_gate/tracing.py`
**Taken:** the OpenTelemetry semantic-convention naming from
`src/microsoft/opentelemetry/a365/core/constants.py` (`error.type`, `execute_tool`,
`apply_guardrail`, and similar).
**Adaptation:** no code is copied and the OpenTelemetry SDK is not a dependency — pulling it would
contradict this package's stdlib-only, offline posture, so the convention is adopted and the
implementation is local. Licence: MIT (Microsoft Corporation); text as in §1.

---

## 7. microsoft/llmail-inject-challenge — data corpus

**Used as:** the out-of-domain benign half of `quality_gate/corpus/heldout_corpus.json`
**Taken:** `src/agent/data/fp_tests.json` — 203 benign business-email bodies used by the LLMail-Inject
competition harness as false-positive controls.
**Adaptation:** the email text is unmodified; ids (`HO-EML-*`), labels and the source attribution are
ours. These cases matter because they come from a different content domain than BIPIA's code and task
prompts: a false positive here is evidence that the detector over-triggers on ordinary prose, which a
same-domain control set cannot show. Donor digests are recorded in
`quality_gate/corpus/heldout_manifest.json`.
Licence: MIT (Microsoft Corporation); text as in §1.

---

## 8. microsoft/sarif-js-sdk — record shape only

**Used as:** `embedded_quality_gate/sarif.py`
**Taken:** the SARIF 2.1.0 log structure from `packages/eslint-formatter-sarif/sarif.js` — the
`version`/`$schema` header, `runs[].tool.driver` with its rule table, `results[]` carrying `ruleId`,
`level`, `message.text` and a physical location, and the severity-to-level mapping.
**Adaptation:** no donor code is copied. That formatter is JavaScript and depends on `lodash`, `utf8`
and `jschardet`; this package is stdlib-only so it can run offline and air-gapped, so the shape is
adopted and the writer is local. Gate finding ids, confidence and evidence references are carried in
each result's `properties` so a code-scanning alert traces back to the evidence that produced it.
Licence: MIT (Microsoft Corporation); text as in §1.

---

## 9. microsoft/msvc-code-analysis-action — CI publication pattern

**Used as:** the SARIF publication steps in `.github/workflows/validation.yml`
**Taken:** the workflow pattern from `README.md` and `action.yml` — `github/codeql-action/upload-sarif`
with `sarif_file:`, alongside `actions/upload-artifact` so the log survives as a job artifact.
**Adaptation:** action versions raised to the v3/v4 line already used by this workflow, a `category`
added so the gate's results are distinguishable in code scanning, and `if: always()` so findings are
published even when the analysis step fails the job. None of the donor's CMake/MSVC analysis is used.
Licence: MIT (Microsoft Corporation); text as in §1.
