# Embedded Quality Gate v1.1.0 → v1.2.0 Audit and Remediation

**Audit date:** 2026-09-04  
**Target:** Embedded Quality Gate for Code and Tests  
**Input version:** 1.1.0  
**Remediated version:** 1.2.0  
**Disposition:** Local/reference implementation materially repaired; production promotion remains fail-closed pending external qualification and human security/privacy approval.

## Executive finding

v1.1.0 had a strong requirements/control model and many working controls, but several implementation details made the package more optimistic than its name and reports justified. Most importantly, protected evidence was actually written as plaintext, evaluation returned success even when the measured grounding threshold failed, user-controlled run IDs could escape the evidence directory, evidence could be overwritten, readiness was not bound to the current revision, and the advertised minimal-impact/save-stage behavior was not connected to the CLI. These were gate-integrity defects, not cosmetic documentation issues.

v1.2.0 repairs those defects without lowering thresholds or fabricating external qualifications. The local/reference gate now acts like an Embedded Quality Gate: it has a diff-scoped pre-PR path, deterministic checks run before probabilistic/model work, evidence writes are encrypted and immutable, authority is role-bound, output evidence is revision-bound and hash-verified, and promotion depends on both READY gates and deployment prerequisites.

## Final audited results on the remediation host

| Check | Result |
|---|---|
| Unit/integration suite | **65/65 PASS** |
| Original corpus integrity | **612/612 intact** |
| Deterministic repository analysis | **PASS**, no release-blocking findings |
| Supported files deterministically checked | **621** |
| DMK references | **62/62 resolve** |
| Adversarial suite | **7/7 blocked** |
| End-to-end suite | **6/6 PASS** |
| Content-defense corpus | **125 cases** (50 attack / 75 benign) |
| Grounding / attack recall | **1.00** (threshold 0.98) |
| False-positive rate | **0.00** (maximum 0.05) |
| Read/draft-only pilot | **PASS**, repository hash unchanged |
| Protected run evidence | **Encrypted and decrypt/manifest verified** |
| Traceability | **1021 matrix rows**, 197 source obligations census-complete |
| Parent requirements | **191 PASS / 5 BLOCKED / 1 INDETERMINATE** |
| Phase status | **P00–P14 PASS; P15–P17 closed by remaining external prerequisites** |
| Promotion | **DENIED / fail-closed**, as required |

Final audit revision: `848d5d5a2cb11acc371d3c35d9101fde0f7f4a535f56bd60724c8ecbeb76daac`.

## Problems parsed and fixed

### 1. Critical — encryption existed as a library but was bypassed by evidence writers
**v1.1.0 behavior:** `crypto.py` could encrypt, while CLI evidence and run state were still written with the plaintext JSON writer. `crypto status=enforced` therefore proved backend availability, not that protected data on disk was ciphertext.  
**Fix:** added `secure_storage.py` as the enforcement point. Configured protected paths are envelope-encrypted before write; protected plaintext can be rejected on read. `evaluate` verifies the persisted files are actually encrypted before reporting success.

### 2. High — evaluation returned exit 0 with a failed quality threshold
**v1.1.0 behavior:** measured grounding was 0.94 vs policy 0.98, but `evaluate` exited 0 because only adversarial/E2E booleans controlled its exit.  
**Fix:** evaluation exit status now includes measured grounding, false-positive threshold, fail-closed behavior, encryption persistence, and pilot result. The 0.98 threshold was not weakened.

### 3. Critical — run ID path traversal / scope injection
**v1.1.0 behavior:** `--run-id` was joined directly to the evidence path, permitting `../` or absolute-path escape.  
**Fix:** strict run-ID grammar; slash/backslash/absolute/traversal forms are rejected before any run work. Regression test added.

### 4. High — evidence run IDs were overwriteable
**v1.1.0 behavior:** rerunning the same ID used atomic replacement, so evidence history was not truly append-only.  
**Fix:** evidence artifacts use exclusive-create semantics. An existing run ID is refused. A partial/invalid run without a manifest is never considered readiness evidence.

### 5. High — “latest evidence” was selected lexically by directory name
**v1.1.0 behavior:** a user-chosen directory name could outrank a newer/valid run.  
**Fix:** only decryptable, manifest-valid, current-revision runs are candidates; selection uses manifest creation time.

### 6. High — evidence was not revision/payload bound
**v1.1.0 behavior:** readiness could consume artifacts without proving they came from the code/policy revision being promoted.  
**Fix:** encrypted `run_manifest.json` records the repository revision and canonical SHA-256 of each plaintext evidence payload. Readiness verifies all artifact hashes and revision linkage.

### 7. High — READY-04 checked only non-empty evidence-reference strings
**v1.1.0 behavior:** a row passed if `evidence_refs` contained text, even if evidence was stale or unrelated.  
**Fix:** READY-04 now verifies the 197-source-obligation/12-audit-addition census, required traceability fields, referenced artifact existence, parent status consistency with requirement closeout, and current-revision evidence binding.

### 8. Medium — applied matrix and closeout status drift
**v1.1.0 behavior:** child rows still reflected older prerequisite closures while later closeout reports declared those phases PASS.  
**Fix:** closeout regeneration synchronizes parent, child, phase-gate, and program rollups from one status source.

### 9. Critical — authority context could self-grant role-incompatible privileges
**v1.1.0 behavior:** policy trusted `ctx.actions`; a caller could construct an analyst context carrying a privileged action.  
**Fix:** context actions can only narrow a role's configured grant. Unknown roles are denied. Privileged actions still require explicit human approval.

### 10. High — allowlisted executable could be spoofed by basename
**v1.1.0 behavior:** `/tmp/python` could satisfy an allowlist entry `python`.  
**Fix:** executable is resolved from trusted PATH first; a path-qualified executable must resolve to that exact target.

### 11. High — gate did not analyze its own Python/JSON implementation
**v1.1.0 behavior:** deterministic analysis covered custom corpus extensions, while the gate code/tests were outside the analyzer despite the product name “for Code and Tests.”  
**Fix:** Python AST parse and JSON parse are included in deterministic analysis; syntax errors are evidence-anchored.

### 12. High — minimal-impact save/stage/pre-PR capability was not operationally wired
**v1.1.0 behavior:** diff/impact modules existed, but the CLI `analyze` did a full-repository corpus scan.  
**Fix:** new `gate` command accepts a unified diff, scope-confines paths, computes minimal impact, runs deterministic analysis on the impacted set, and reports test gaps/unchecked coverage.

### 13. Medium — unified diff parser accepted inconsistent hunk counts
**Fix:** old/new observed hunk line counts must match the hunk header; malformed input is rejected.

### 14. Medium — E2E golden path was largely a workflow-state walk
**Fix:** golden path now executes the actual diff → impact → deterministic analysis/test-gap path before completing the workflow/provenance sequence.

### 15. Critical — readiness could theoretically promote while deployment phases were still open
**v1.1.0 behavior:** promotion was only the READY-01…08 verifier set; pilot/deployment prerequisites were tracked elsewhere.  
**Fix:** CLI promotion combines READY gates with XEVAL-06 and DEPLOY-01…06 delivery preconditions. All must PASS.

### 16. Medium — data-governance text contradicted the encryption implementation
**v1.1.0 behavior:** governance said EQG stored no keys while the local RSA provider stored one; at-rest responsibility was described as platform/filesystem even while envelope encryption was claimed.  
**Fix:** governance now accurately names the local wrapping-key path, secure-storage enforcement, and production managed-key requirement.

### 17. Medium — retention semantics conflicted with append-only evidence
**v1.1.0 behavior:** a 90-day evidence retention value coexisted with code that refused evidence deletion.  
**Fix:** reference mode explicitly retains append-only audit evidence indefinitely; production must define governed archival/destruction rather than silently rewriting/deleting the reference trail.

### 18. Medium — provenance appends could fork under concurrency
**Fix:** append operations are serialized with an OS-level lock. Protected-path JSONL records support per-record envelope encryption bound to path and record index.

### 19. High — protected run state was not enforced and stored identity could be silently reused
**Fix:** run state uses secure storage for configured protected paths and verifies stored run ID/revision match the requested state identity.

### 20. Medium — approval expiry could exceed approving authority
**Fix:** approval expiration is validated, must be future, and cannot materially outlive the authority that granted it.

### 21. High — content-defense recall failed policy
**v1.1.0:** 47/50 attacks detected = 0.94 recall.  
**Fix:** general, sub-threshold signals were added for outbound GET actions and unbounded loops. They only cause a document finding when combined with another suspicious directive/payload signal. Final result: 50/50 attacks, 0/75 benign false alarms. Holdout tests ensure network GET or `while True` alone remains benign.

### 22. Low — test-gap discovery counted `__pycache__` bytecode as tests
**Fix:** generated/runtime/evidence directories are excluded and test candidates are constrained to supported source extensions.

### 23. Medium — readiness repeatedly re-hashed the full repository
**Observed during remediation:** closeout could time out because each verifier/environment qualification recomputed the ~800-file revision.  
**Fix:** current revision/evidence lookup is cached per readiness process and environment checks reuse one revision computation.

### 24. Medium — CI definition was treated as a future qualification path but had an unnecessary external hygiene dependency
**Fix:** CI hygiene now uses stdlib `compileall` plus the deterministic gate, then tests and encrypted evaluation. The workflow emits a CI qualification record only after its prerequisite jobs actually pass. The mere existence of workflow YAML is still not a PASS.

### 25. Medium — read-only verification could create key material
**Problem found during packaging:** constructing the local key provider for a decrypt/status operation could generate a new private key when the original key was absent. That makes a verifier state-changing and cannot recover ciphertext created with another host key.  
**Fix:** protected reads/readiness use `create_if_missing=False`; key creation is explicit on the protected-write/evaluation path. Read-only readiness no longer manufactures key material.

## Remaining gates and exactly how to open them

1. **DEPLOY-02 — CI (INDETERMINATE):** run `.github/workflows/validation.yml` on the same revision; retain the emitted `ci_qualification.json` and encrypted evidence artifact.
2. **DEPLOY-03 — staging (BLOCKED):** run smoke, security/bypass, and rollback qualification in an actual staging/pre-production environment; complete `staging_qualification.json` from its template.
3. **DEPLOY-04 — production read-only (BLOCKED):** qualify actual read/draft-only production integration, or record a named human-approved `NOT_APPLICABLE` disposition if this mode is outside product scope.
4. **DEPLOY-05 — privileged path (BLOCKED):** qualify a separately authorized short-lived privileged path, or record a named human-approved `NOT_APPLICABLE` disposition if privileged execution is intentionally excluded.
5. **DEPLOY-06 — isolated security/privacy tenant (BLOCKED):** exercise cross-project leakage, sensitive-output, retention/redaction, security, and rollback behavior against an isolated test tenant/data set.
6. **READY-07 — security/privacy review (BLOCKED):** a named human reviewer must inspect the current revision and complete `quality_gate/approvals/security_privacy_review.json`. Model output cannot create this approval.

See `quality_gate/docs/GATE_OPENING_RUNBOOK.md` for the exact template names and command sequence.

## Packaging note

The remediation host generated encrypted evidence using a host-local RSA wrapping key. The release archive intentionally excludes `.eqg_runtime/keys/`; shipping the private key beside ciphertext would defeat the at-rest control. Encrypted audit-run ciphertext may remain as historical evidence, but a recipient must run `evaluate` after extraction to generate decryptable current evidence under that host's own key.

## Overall assessment

**Efficacy to the name:** v1.1.0 was a strong control specification with a partially operational gate, but did not fully deserve “Embedded Quality Gate for Code and Tests” because minimal-impact authoring integration and implementation-code coverage were not wired through the user-facing path, and key readiness evidence was weaker than reported. v1.2.0 materially closes that gap.

**Operability:** local/reference operation is now coherent and fail-closed. The remaining closed gates are not missing code paths that should be force-opened locally; they are evidence obligations that require real CI/deployment environments or a human security/privacy decision.
