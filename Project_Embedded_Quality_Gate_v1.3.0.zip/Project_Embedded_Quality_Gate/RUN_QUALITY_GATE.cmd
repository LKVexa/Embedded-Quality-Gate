@echo off
setlocal
cd /d "%~dp0"
set "EQG_ARGS=%*"
if "%EQG_ARGS%"=="" set "EQG_ARGS=analyze --repo ."
where py >nul 2>nul && (py -3 -B -m embedded_quality_gate %EQG_ARGS% & exit /b %ERRORLEVEL%)
where python >nul 2>nul && (python -B -m embedded_quality_gate %EQG_ARGS% & exit /b %ERRORLEVEL%)
echo Python 3 was not found on PATH. 1>&2
exit /b 127
