# Quality Gate Application Report — the generic project repository

**Gate:** Embedded Quality Gate v1.3.0
**Target:** the 66-suite JA-family / DeepML project corpus — 612 files, previously ungated
**Applied:** 2026-09-04, junkyard chop shop, work order `Project_Embedded_Quality_Gate-20260904-2207`
**Repository revision:** `4f2303bc441c5643be308b3c32c76e8e49a6ab28c404c98ae842a087d3dd53e6`
**Verdict:** **release candidate, fail-closed.** Promotion is denied, and the reasons are external.

## What was verified on this repository

| Check | Result |
|---|---|
| Unit / integration suite | **103/103 PASS** |
| Deterministic analysis | **PASS** — 642 files checked, 12 findings, **0 release-blocking** (all 12 are the stale-manifest provenance findings below) |
| DMK data-source references | **62/62 resolve** |
| Original corpus integrity | **612/612 unchanged**, `intact: true` |
| Adversarial suite | **7/7 blocked** |
| End-to-end suite | **6/6 PASS**, including the real minimal-impact golden path and rollback |
| Offline evaluation (tuned corpus, 125 cases) | **1.00 attack recall, 0.00 false-positive rate** |
| Offline evaluation (held-out corpus, 328 cases) | **0.98 attack recall, 0.00 false-positive rate** |
| Read/draft-only pilot | **PASS**, repository revision unchanged |
| Lint (`ruff check`, 0.15.11) | **PASS** — see "Lint" below |
| Packaging guard | **PASS** on the packaged tree |
| Release manifest / checksums | **consistent with this tree** |
| Requirements | **190 PASS / 6 BLOCKED / 1 INDETERMINATE** of 197 |
| Phases | **P00–P14 PASS**; P15, P16, P17 BLOCKED |
| Readiness gates | **7 of 8 PASS**; READY-07 BLOCKED |

Evidence is envelope-encrypted, immutable per run ID, and bound to the revision above:
`quality_gate/evidence/PEQG-20260904-2207-E/` (verification suites) and
`quality_gate/evidence/PEQG-APPLY-FINAL/` (application bundle referenced by the traceability matrix).

## Read the two evaluation numbers differently

The **1.00** figure is measured on the corpus the detector was developed against (BIPIA *test* splits).
It shows fit. The **0.98** figure is measured on 328 cases the detector has never seen — BIPIA *train*
splits plus 203 benign business emails from a different donor and a different content domain — and it
shows generalisation. The floors it is checked against (0.80 recall, 0.10 false positives) were written
into the work order before the measurement was read.

**The single miss is not fixed, deliberately.** `HO-ATK-0012` exfiltrates a file over FTP; `ftplib` is
not among the network signals. Adding a signal for it would tune the detector against its own held-out
corpus and destroy the only unbiased measurement in this repository. It is recorded in
`quality_gate/docs/KNOWN_LIMITATIONS_NON_GOALS.md` and stays open until it can be closed against a new
held-out set.

The held-out result is **reported, not gating**: `evaluate` fails closed if the corpus is missing, but
the rates do not block a release. Promoting them to release gates changes the release semantics of an
audited programme, which is your decision, not the repository's.

## Defects found in the v1.3.0 build and closed here

1. **A private key shipped inside the archive.** `.eqg_runtime/keys/eqg_local_key.pem` — a live RSA
   private key — was present in the upload while `.gitignore` excluded the directory and the release
   manifest recorded `"private_key_packaged": false`. It is excluded here, and
   `quality_gate/scripts/verify_packaging.py` now refuses to package any tree that contains one.
2. **A stale release manifest.** It declared version 1.2.0, 65 tests and a 191/197 split against a
   v1.3.0 tree with 78 tests. `regenerate_release_manifest.py` now writes it from the tree and
   `verify_release_manifest.py` fails when they disagree.
3. **A stale checksum file.** 21 of 775 listed files no longer matched, including `cli.py`,
   `crypto.py` and `policy.py`. Regenerated, with its exclusions named in its own header.
4. **Evidence from another host.** Five run directories bound to revisions that do not exist here were
   carried in the upload. They are retained in the work order for provenance and are **not** in this
   repository; all evidence here was produced here.
5. **Lint had never been executed.** The `ruff` configuration was declared and never run.

## Defects found in the corpus and reported, not edited

Five suites — Anthology, Atlas, Compass, Observer, Pencil — carry `SHA256SUMS.txt` and
`MANIFEST.json` written against an earlier packaging layout — they name the pre-migration directory
layout (`02_Anthology/01_anthology_chronology.jad`), `input_templates/*.json` files that the `.json` →
`.dmk` migration replaced, and a `CORPUS_INSPECTION.json` that no longer exists. Across the ten suite
manifests, **62 declared paths do not exist and 2 digests do not match**; `Observer/MANIFEST.json`
resolves none of its six entries. These files read as verification and verify nothing.

They are corpus files, so the gate **reports** them and does not touch them: a new deterministic
`stale_manifest` check raises one `provenance` finding per affected manifest (low for unresolved
paths, medium for digest mismatches, neither release-blocking by default), and a test asserts the check
leaves every corpus digest unchanged. Repairing or removing those manifests is a corpus decision for
you to make.

## Lint

`ruff check` under the repository's declared rule set reported 638 findings on a codebase that had
never been linted. Every finding in the correctness (`F`) and security (`S`) families was fixed:
three unused imports, two unused variables, an `assert` used as a security check in
`provenance.py` (replaced with a real raise, because `python -O` strips asserts), an ambiguous
variable name, a lambda assignment, a bare `try/except/pass`, and import ordering across the package.
Four `subprocess` sites carry per-line `noqa` with the reason they are safe.

`E701` and `E702` — 553 findings — are formatting preferences about a deliberate one-line style used
across roughly 4,000 lines of security-relevant code. Reformatting them would be a large unrelated
refactor, so they are ignored **explicitly, with that reason written into `pyproject.toml`**, rather
than left silently failing. The suite passes with every other selected rule enforced.

## What is still not closed, and why

| Gate | Status | What would close it |
|---|---|---|
| READY-07 security/privacy review | **BLOCKED** | A named human signs `quality_gate/approvals/READY-07.request.json` and saves it as `security_privacy_review.json`. The request is generated, bound to this revision and to the SHA-256 of all five review documents. |
| DEPLOY-02 CI | **INDETERMINATE** | A real CI run. The workflow already writes the qualification record from actual `evaluate` artefacts and refuses to write a PASS the artefacts do not support. No local run can substitute for it. |
| DEPLOY-03 staging | **BLOCKED** | A real staging qualification record. |
| DEPLOY-04 production read-only | **BLOCKED** | A real qualification, or a named human signing `quality_gate/environments/DEPLOY-04.request.json`. |
| DEPLOY-05 privileged path | **BLOCKED** | A real qualification, or a named human signing `DEPLOY-05.request.json`. |
| DEPLOY-06 isolated tenant | **BLOCKED** | A real isolated security/privacy tenant qualification. |

**No threshold was lowered, no environment qualification was invented, and nothing was signed.** Six of
the seven open items require a human or an environment this session does not have; the seventh
(DEPLOY-02) requires CI to actually run.

Gate-opening steps: `quality_gate/docs/GATE_OPENING_RUNBOOK.md`.
Limitations and non-goals: `quality_gate/docs/KNOWN_LIMITATIONS_NON_GOALS.md`.
