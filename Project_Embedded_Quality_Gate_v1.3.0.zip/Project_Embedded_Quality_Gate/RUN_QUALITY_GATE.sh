#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -eq 0 ]; then set -- analyze --repo .; fi
exec python3 -B -m embedded_quality_gate "$@"
