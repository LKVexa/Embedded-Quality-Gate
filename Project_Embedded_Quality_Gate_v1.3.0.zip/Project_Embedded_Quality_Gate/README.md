# Project — with the Embedded Quality Gate applied

This repository is the 66-suite JA-family / DeepML project corpus with a repository-local,
evidence-bound quality gate embedded in it. Two things live here, deliberately separated:

| | What it is |
|---|---|
| **The corpus** — 66 suite folders, **612 files** | The subject matter: `.ja`, `.jaa`, `.jad`, `.jasp`, `.jasec`, `.jaops`, `.jaui`, `.jate`, `.deepml`, `.dmk`, `.ebnf` sources plus each suite's README. The gate does not edit it. `quality_gate/scripts/verify_corpus_integrity.py` detects a single changed byte. |
| **The gate** — `embedded_quality_gate/` + `quality_gate/` | Default-deny authority, minimal-impact diff analysis, deterministic checks before probabilistic ones, encrypted and immutable run evidence, human approval controls, and fail-closed release readiness. |

The gate is **v1.3.0**, applied here by the junkyard chop shop under work order
`Project_Embedded_Quality_Gate-20260904-2207`. The corpus was verified byte-identical to the corpus
inside that gate build before the port, so nothing in the 612 files changed to accommodate it.

## Quick start

```sh
# Deterministic whole-repository verification (add --sarif gate.sarif for code scanning)
python -m embedded_quality_gate analyze --repo .

# Minimal-impact gate over a unified diff (save / stage / pre-pr)
python -m embedded_quality_gate gate --repo . --mode pre-pr --diff-file change.diff

# Read/draft-only pilot: proves privileged actions are refused and the tree is unchanged
python -m embedded_quality_gate pilot --repo .

# Adversarial + E2E + measured offline evaluation + held-out generalisation.
# Evidence is encrypted and immutable; a run ID cannot be reused.
python -m embedded_quality_gate evaluate --repo . --run-id EQG-MY-RUN-001

# READY-01…08 plus deployment preconditions; exits 0 only when every required gate is PASS
python -m embedded_quality_gate readiness --repo .

# Tests
python -m unittest discover -s quality_gate/tests -t .
```

On Windows, `RUN_QUALITY_GATE.cmd` defaults to `analyze` and forwards arguments.

## Repository health checks

```sh
python quality_gate/scripts/verify_corpus_integrity.py     # 612 corpus files unchanged
python quality_gate/scripts/verify_release_manifest.py     # manifest + checksums describe this tree
python quality_gate/scripts/verify_packaging.py            # no key material, runtime state, or foreign evidence
python quality_gate/scripts/make_approval_request.py       # regenerate the UNSIGNED approval requests
```

## What this application added over the v1.3.0 gate

- **A held-out evaluation corpus.** The original 125-case corpus is drawn from the BIPIA *test*
  splits, which is also what the detector was developed against, so its 1.00 recall measures fit
  rather than generalisation. `quality_gate/corpus/heldout_corpus.json` adds 328 cases the detector
  has never seen — the BIPIA *train* splits plus 203 benign business emails from a different donor —
  and their disjointness from the tuned corpus is asserted by test. Measured here: **0.98 recall,
  0.00 false-positive rate**. The single miss is documented in
  `quality_gate/docs/KNOWN_LIMITATIONS_NON_GOALS.md` and deliberately **not** fixed, because tuning
  against a held-out set destroys it.
- **SARIF output.** `analyze --sarif <path>` writes a SARIF 2.1.0 log, and CI publishes it to code
  scanning.
- **A provenance manifest drift check.** Five suites carry `SHA256SUMS.txt` / `MANIFEST.json` files
  written against an earlier packaging layout; 93 of their declared paths no longer exist. The gate
  now reports that instead of leaving manifests that read as verification but verify nothing. It
  reports only — those files are corpus, and the corpus is immutable.
- **A packaging guard and a release-manifest verifier**, closing two defects found in the v1.3.0
  build itself: a private wrapping key shipped inside the archive, and a release manifest and
  checksum file that described a different build.
- **Unsigned approval requests** for the three gates that need a named human, bound to the current
  revision and to the hash of every document under review.

## Promotion semantics

`readiness` is fail-closed and stricter than it looks: READY-01…08 are not sufficient on their own —
promotion also requires the pilot and the applicable deployment-environment qualifications.
Repository-local code can close the local pilot and the measured evaluation gates. It cannot
truthfully invent CI execution, staging, production integration, an isolated test tenant, or a named
human security/privacy approval, and it does not try. See `QUALITY_GATE_APPLICATION_REPORT.md` for
this repository's current disposition and `quality_gate/docs/GATE_OPENING_RUNBOOK.md` for the exact
steps that open each remaining gate.

## Non-goals

- The gate never silently modifies code, tests, or corpus, and never self-approves.
- It does not claim a production JA/DeepML compiler or runtime.
- It does not fabricate environment qualifications or human sign-offs.
- It does not claim transit encryption in repository-local mode, where there is no network transport.

License: MIT (`LICENSE`). Third-party notices: `THIRD-PARTY-NOTICES.md`.
