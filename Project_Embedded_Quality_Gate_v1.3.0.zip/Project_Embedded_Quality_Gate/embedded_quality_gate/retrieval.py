from __future__ import annotations

from datetime import datetime, timezone


def rank_sources(records,now=None,stale_seconds=86400):
 now=now or datetime.now(timezone.utc); ranked=[]
 for rec in records:
  try: t=datetime.fromisoformat(rec['observed_at'].replace('Z','+00:00')).astimezone(timezone.utc); age=(now-t).total_seconds()
  except Exception: age=float('inf')
  state='stale' if age>stale_seconds else 'current'
  score=(1 if state=='current' else 0, 1 if rec.get('authorized',True) else 0, -age)
  ranked.append({**rec,'freshness':state,'retrieval_score':score})
 return sorted(ranked,key=lambda r:r['retrieval_score'],reverse=True)
