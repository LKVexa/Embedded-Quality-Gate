"""Command line entry point for the Embedded Quality Gate."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from .adversarial import run_adversarial_suite
from .analyzers import analyze_repository, validate_dmk_references
from .crypto import EncryptionUnavailable, build_encryptor, crypto_status
from .e2e import run_e2e_suite
from .evaluation import run_heldout_evaluation, run_offline_evaluation
from .ingestion import inventory_repository
from .pilot import run_read_only_pilot
from .pipeline import run_diff_gate
from .quality import summarize
from .release import evaluate_delivery_preconditions, evaluate_readiness, invalidate_evidence_cache, promotion_allowed
from .repository import repo_revision
from .sarif import write_sarif
from .secure_storage import ImmutableEvidenceError, canonical_payload_hash, is_encrypted_file, write_json
from .util import utc_now
from .version import __version__

RUN_ID_RE=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$')


def _run_id(value:str|None) -> str:
    rid=('EQG-'+re.sub(r'[^0-9TZ]','',utc_now())) if value is None else value
    if rid in {'.','..'} or not RUN_ID_RE.fullmatch(rid):
        raise ValueError('run-id must be 1-128 characters of letters, digits, dot, underscore or hyphen; traversal/path syntax is forbidden')
    return rid


def _quality_thresholds(root:Path):
    try: data=json.loads((root/'quality_gate'/'config'/'thresholds.json').read_text(encoding='utf-8'))
    except Exception: data={}
    q=data.get('quality',{})
    return float(q.get('minimum_grounding_rate',0.98)),float(q.get('maximum_false_positive_rate',0.05))


def cmd_analyze(args):
    root=Path(args.repo).resolve(); rev=repo_revision(root)
    result=analyze_repository(root); refs=validate_dmk_references(root); summary=summarize(result['findings'],result['checked_files'])
    report={'revision':rev,'summary':summary,'dmk_references':refs,'manifest_drift':result.get('manifest_drift',{})}
    if getattr(args,'sarif',None):
        # SARIF is an additional output channel, never a substitute for the exit
        # code: a run that writes SARIF still blocks on the same conditions.
        written=write_sarif(args.sarif,summary['findings'],version=__version__,revision=rev)
        report['sarif']=str(written)
    print(json.dumps(report,indent=2))
    return 2 if summary['release_blocking'] or refs['missing'] else 0


def cmd_gate(args):
    root=Path(args.repo).resolve()
    if args.diff_file=='-': text=sys.stdin.read()
    else: text=Path(args.diff_file).read_text(encoding='utf-8')
    try:
        result=run_diff_gate(root,text,max_bytes=args.max_bytes)
    except ValueError as exc:
        print(json.dumps({'status':'BLOCKED','reason':f'malformed diff: {exc}'},indent=2)); return 2
    result={'revision':repo_revision(root),'mode':args.mode,**result}
    print(json.dumps(result,indent=2))
    return 0 if result['status']=='PASS' else 2


def cmd_inventory(args):
    root=Path(args.repo).resolve(); rev=repo_revision(root)
    print(json.dumps({'revision':rev,'files':inventory_repository(root,rev,max_files=args.max_files)},indent=2)); return 0


def cmd_pilot(args):
    result=run_read_only_pilot(Path(args.repo).resolve()); print(json.dumps(result,indent=2)); return 0 if result['passed'] else 2


def cmd_evaluate(args):
    """Run verification suites and persist immutable, encrypted evidence."""
    root=Path(args.repo).resolve()
    try: rid=_run_id(args.run_id)
    except ValueError as exc:
        print(json.dumps({'error':'invalid_run_id','detail':str(exc)},indent=2)); return 2
    out=root/'quality_gate'/'evidence'/rid
    if out.exists():
        if (out/'run_manifest.json').exists():
            print(json.dumps({'error':'immutable_run_exists','detail':f'evidence run already exists: {rid}'},indent=2)); return 2
        print(json.dumps({'error':'incomplete_run_exists','detail':f'a previous attempt left a partial run {rid} without a valid manifest; choose a new run-id (append-only)'},indent=2)); return 2
    rev=repo_revision(root); created=utc_now()
    # Key creation is a write-side effect and is explicit here; read-only readiness never creates keys.
    enc=build_encryptor(root,create_if_missing=True)
    if not enc.available:
        print(json.dumps({'error':'encryption_unavailable','detail':getattr(enc.provider,'reason','no provider')},indent=2)); return 2
    adversarial={**run_adversarial_suite(root),'run_id':rid,'revision':rev}
    e2e={**run_e2e_suite(),'run_id':rid,'revision':rev}
    offline={**run_offline_evaluation(root),'run_id':rid,'revision':rev}
    heldout={**run_heldout_evaluation(root),'run_id':rid,'revision':rev}
    crypto={**crypto_status(root),'run_id':rid,'revision':rev}
    pilot={**run_read_only_pilot(root),'run_id':rid,'revision':rev}
    min_ground,max_fp=_quality_thresholds(root)
    threshold_ok=(offline.get('measured') and offline.get('grounding_rate') is not None and offline.get('false_positive_rate') is not None
                  and offline['grounding_rate']>=min_ground and offline['false_positive_rate']<=max_fp)
    # Fail closed if generalisation could not be measured at all: a missing
    # held-out corpus must not quietly reduce the run to the tuned number.
    # The measured rates themselves are reported against declared floors and do
    # not gate the run - see quality_gate/config/thresholds.json heldout.rationale.
    heldout_measured=bool(heldout.get('measured'))
    evaluation_ok=bool(adversarial.get('all_blocked') and e2e.get('all_passed') and offline.get('guardrails_fail_closed')
                       and threshold_ok and crypto.get('at_rest',{}).get('status')=='enforced' and pilot.get('passed')
                       and heldout_measured)
    payloads={
        'adversarial_results.json':adversarial,'e2e_results.json':e2e,'offline_evaluation.json':offline,
        'crypto_status.json':crypto,'pilot_results.json':pilot,
        'heldout_evaluation.json':heldout,
    }
    manifest={
        'schema_version':'eqg.run-manifest/1.0','run_id':rid,'revision':rev,'created_at':created,
        'evaluation_passed':evaluation_ok,
        'thresholds':{'minimum_grounding_rate':min_ground,'maximum_false_positive_rate':max_fp},
        'artifacts':{name:canonical_payload_hash(value) for name,value in payloads.items()},
    }
    try:
        for name,value in payloads.items(): write_json(root,out/name,value,immutable=True,create_key_if_missing=True)
        # Record whether the enforcement point actually put ciphertext on disk,
        # rather than treating backend availability as proof of encrypted storage.
        manifest['encrypted_artifacts_verified']=all(is_encrypted_file(root,out/name) for name in payloads)
        manifest['evaluation_passed']=bool(manifest['evaluation_passed'] and manifest['encrypted_artifacts_verified'])
        write_json(root,out/'run_manifest.json',manifest,immutable=True,create_key_if_missing=True)
        invalidate_evidence_cache()
    except (EncryptionUnavailable,ImmutableEvidenceError,Exception) as exc:  # fail closed on any evidence persistence fault
        print(json.dumps({'error':'evidence_persistence_failed','run_id':rid,'detail':f'{type(exc).__name__}: {exc}'},indent=2)); return 2
    report={
        'run_id':rid,'revision':rev,'evaluation_passed':manifest['evaluation_passed'],
        'adversarial':{'blocked':adversarial['blocked_count'],'of':adversarial['case_count']},
        'e2e':{'passed':e2e['passed'],'of':e2e['scenario_count']},
        'offline_evaluation':{'measured':offline['measured'],'grounding_rate':offline['grounding_rate'],
                              'false_positive_rate':offline['false_positive_rate'],'corpus':offline['corpus']},
        'heldout_evaluation':{'measured':heldout_measured,'grounding_rate':heldout.get('grounding_rate'),
                              'false_positive_rate':heldout.get('false_positive_rate'),
                              'floor_met':heldout.get('floor_met'),'gating':heldout.get('gating'),
                              'corpus':heldout.get('corpus',{})},
        'pilot':{'passed':pilot['passed'],'source_unchanged':pilot['source_unchanged']},
        'encryption':{'at_rest':crypto['at_rest']['status'],'artifacts_verified':manifest['encrypted_artifacts_verified']},
        'evidence_dir':out.relative_to(root).as_posix(),
    }
    print(json.dumps(report,indent=2)); return 0 if manifest['evaluation_passed'] else 2


def cmd_readiness(args):
    root=Path(args.repo).resolve() if args.repo else None
    facts=json.loads(Path(args.facts).read_text(encoding='utf-8')) if args.facts else {}
    gates=evaluate_readiness(facts,root); pre=evaluate_delivery_preconditions(root) if root else []
    allowed=promotion_allowed(gates,pre)
    print(json.dumps({'promotion_allowed':allowed,'readiness_gates':[g.__dict__ for g in gates],
                      'delivery_preconditions':[g.__dict__ for g in pre]},indent=2,default=list))
    return 0 if allowed else 3


def cmd_crypto(args): print(json.dumps(crypto_status(Path(args.repo).resolve()),indent=2)); return 0


def main(argv=None):
    ap=argparse.ArgumentParser(prog='embedded-quality-gate'); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('analyze'); p.add_argument('--repo',default='.')
    p.add_argument('--sarif',default=None,help='also write findings as a SARIF 2.1.0 log at this path')
    p.set_defaults(func=cmd_analyze)
    p=sub.add_parser('gate',help='run minimal-impact deterministic checks over a unified diff')
    p.add_argument('--repo',default='.'); p.add_argument('--diff-file',required=True,help='unified diff file, or - for stdin')
    p.add_argument('--mode',choices=('save','stage','pre-pr'),default='pre-pr'); p.add_argument('--max-bytes',type=int,default=5*1024*1024); p.set_defaults(func=cmd_gate)
    p=sub.add_parser('inventory'); p.add_argument('--repo',default='.'); p.add_argument('--max-files',type=int,default=100000); p.set_defaults(func=cmd_inventory)
    p=sub.add_parser('pilot'); p.add_argument('--repo',default='.'); p.set_defaults(func=cmd_pilot)
    p=sub.add_parser('evaluate'); p.add_argument('--repo',default='.'); p.add_argument('--run-id',default=None); p.set_defaults(func=cmd_evaluate)
    p=sub.add_parser('readiness'); p.add_argument('--repo',default='.'); p.add_argument('--facts',default=None); p.set_defaults(func=cmd_readiness)
    p=sub.add_parser('crypto'); p.add_argument('--repo',default='.'); p.set_defaults(func=cmd_crypto)
    args=ap.parse_args(argv); return args.func(args)

if __name__=='__main__': raise SystemExit(main())
