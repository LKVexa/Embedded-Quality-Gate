__version__ = "1.3.0"
SCHEMA_VERSION = "eqg.contracts/1.3"
POLICY_VERSION = "eqg.policy/1.3"
