"""Fail-closed JSON storage for paths covered by the at-rest encryption policy.

The v1.1.0 package implemented a cryptographic provider but its evidence and
state writers still called the plaintext JSON writer directly.  This module is
the enforcement point: paths named by ``encryption.json`` are envelope-
encrypted before bytes reach disk, and immutable evidence files are created
with exclusive-create semantics so a run can never overwrite prior evidence.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .crypto import EncryptionIntegrityError, EncryptionUnavailable, Envelope, build_encryptor, load_config
from .util import canonical_json

STORAGE_SCHEMA = "eqg.secure-json/1.0"


class SecureStorageError(RuntimeError):
    pass


class ImmutableEvidenceError(SecureStorageError):
    pass


def _relative(root: Path, path: Path) -> str:
    root = Path(root).resolve()
    path = Path(path).resolve(strict=False)
    try:
        return path.relative_to(root).as_posix()
    except ValueError as exc:
        raise SecureStorageError(f"storage path escapes repository: {path}") from exc


def _matches(pattern: str, rel: str) -> bool:
    # The shipped policy uses directory/** patterns.  Support exact paths and
    # those prefixes without pretending to implement a full glob engine.
    if pattern.endswith("/**"):
        base = pattern[:-3].rstrip("/")
        return rel == base or rel.startswith(base + "/")
    return rel == pattern


def requires_encryption(root: Path, path: Path, config: dict[str, Any] | None = None) -> bool:
    rel = _relative(root, path)
    cfg = config if config is not None else load_config(root)
    return any(_matches(str(p), rel) for p in cfg.get("at_rest", {}).get("encrypt_paths", []))


def _serialize(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _wrapper(root: Path, path: Path, value: Any, *, create_if_missing: bool) -> dict[str, Any]:
    rel = _relative(root, path)
    encryptor = build_encryptor(root, create_if_missing=create_if_missing)
    if not encryptor.available:
        reason = getattr(encryptor.provider, "reason", "no provider")
        raise EncryptionUnavailable(f"refusing plaintext write to protected path {rel}: {reason}")
    env = encryptor.encrypt(_serialize(value), aad=rel.encode("utf-8"))
    return {
        "storage_schema": STORAGE_SCHEMA,
        "encrypted": True,
        "path": rel,
        "envelope": asdict(env),
    }


def _write_bytes(path: Path, data: bytes, *, immutable: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if immutable:
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as exc:
            raise ImmutableEvidenceError(f"immutable evidence already exists: {path}") from exc
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            # A partial exclusive-create is not silently overwritten. Remove it
            # only when this process itself failed before completing the create.
            try:
                path.unlink()
            except OSError:
                pass
            raise
        return

    # State/metric sidecars are mutable by design.  Use a temporary sibling and
    # replace atomically; this branch is never used for immutable evidence.
    import tempfile
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _reject_symlink_chain(root: Path, path: Path) -> None:
    root = Path(root).resolve()
    current = Path(path)
    for _ in range(256):
        if current.is_symlink():
            raise SecureStorageError(f"symlink not allowed on protected storage path: {current}")
        if current == root or current == current.parent:
            return
        current = current.parent


def write_json(
    root: Path,
    path: Path,
    value: Any,
    *,
    immutable: bool = False,
    create_key_if_missing: bool = False,
) -> None:
    """Persist JSON. Protected paths are envelope-encrypted.

    Key material is created only when ``create_key_if_missing`` is true (write
    paths such as evaluate/state). Read-only verification must not mint keys.
    Evidence under quality_gate/evidence/ is always exclusive-create.
    """
    root = Path(root).resolve()
    path = Path(path)
    rel = _relative(root, path)
    if rel.startswith("quality_gate/evidence/"):
        immutable = True
        _reject_symlink_chain(root, path)
    path = path.resolve(strict=False)
    if requires_encryption(root, path):
        value = _wrapper(root, path, value, create_if_missing=create_key_if_missing)
    _write_bytes(path, _serialize(value), immutable=immutable)


def _decode(root: Path, path: Path, raw: dict[str, Any]) -> Any:
    if raw.get("storage_schema") != STORAGE_SCHEMA:
        return raw
    if raw.get("encrypted") is not True or "envelope" not in raw:
        raise EncryptionIntegrityError("invalid secure-storage wrapper")
    rel = _relative(root, path)
    if raw.get("path") != rel:
        raise EncryptionIntegrityError("secure-storage path binding mismatch")
    encryptor = build_encryptor(root, create_if_missing=False)
    plaintext = encryptor.decrypt(Envelope.from_dict(raw["envelope"]), aad=rel.encode("utf-8"))
    try:
        return json.loads(plaintext.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise EncryptionIntegrityError("decrypted JSON payload is invalid") from exc


def read_json(root: Path, path: Path, *, require_encrypted: bool = False) -> Any:
    root = Path(root).resolve()
    path = Path(path).resolve(strict=False)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SecureStorageError(f"unable to read JSON artifact {path}: {exc}") from exc
    encrypted = isinstance(raw, dict) and raw.get("storage_schema") == STORAGE_SCHEMA
    if require_encrypted and not encrypted:
        raise EncryptionIntegrityError(f"protected artifact is plaintext: {_relative(root, path)}")
    return _decode(root, path, raw) if isinstance(raw, dict) else raw


def is_encrypted_file(root: Path, path: Path) -> bool:
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return False
    if not isinstance(raw, dict) or raw.get("storage_schema") != STORAGE_SCHEMA:
        return False
    try:
        _decode(Path(root), Path(path), raw)
    except Exception:
        return False
    return True


def canonical_payload_hash(value: Any) -> str:
    from .util import sha256_bytes
    return sha256_bytes(canonical_json(value).encode("utf-8"))
