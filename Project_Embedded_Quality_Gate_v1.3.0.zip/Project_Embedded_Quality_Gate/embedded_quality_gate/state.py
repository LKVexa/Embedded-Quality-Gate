from __future__ import annotations

from pathlib import Path

from .secure_storage import read_json, requires_encryption, write_json
from .util import utc_now

PHASES=[f'P{i:02d}' for i in range(18)]
TERMINAL={'PASS','BLOCKED','FAIL','NOT_APPLICABLE'}

class StateError(RuntimeError): pass

class RunState:
    def __init__(self,path: Path,run_id: str,revision: str,root: Path|None=None):
        self.path=Path(path); self.run_id=run_id; self.revision=revision
        self.root=Path(root).resolve() if root else self._infer_root(self.path)
        if self.path.exists():
            require=requires_encryption(self.root,self.path)
            self.data=read_json(self.root,self.path,require_encrypted=require)
            if self.data.get('run_id') != run_id or self.data.get('revision') != revision:
                raise StateError('stored run identity/revision does not match requested run')
        else:
            self.data={'run_id':run_id,'revision':revision,'created_at':utc_now(),'updated_at':utc_now(),
                       'phases':{p:'BLOCKED' for p in PHASES},'steps':{},'history':[]}
            self.save()
    @staticmethod
    def _infer_root(path: Path) -> Path:
        path=path.resolve(strict=False)
        parts=path.parts
        if '.eqg_runtime' in parts:
            idx=parts.index('.eqg_runtime')
            return Path(*parts[:idx]) if idx else Path(path.anchor)
        return path.parent.resolve()
    def save(self):
        self.data['updated_at']=utc_now()
        write_json(self.root,self.path,self.data,immutable=False,create_key_if_missing=True)
    def record_step(self,item_id,status,evidence=None,notes=''):
        if status not in TERMINAL: raise StateError('invalid terminal status')
        self.data['steps'][item_id]={'status':status,'evidence':list(evidence or []),'notes':notes,'at':utc_now()}
        self.data['history'].append({'item_id':item_id,'status':status,'at':utc_now()}); self.save()
    def set_phase(self,phase,status,prerequisites=()):
        if phase not in PHASES or status not in TERMINAL: raise StateError('invalid phase/status')
        for pre in prerequisites:
            if self.data['phases'].get(pre)!='PASS' and status=='PASS':
                raise StateError(f'cannot pass {phase}; prerequisite {pre} is not PASS')
        self.data['phases'][phase]=status; self.save()
