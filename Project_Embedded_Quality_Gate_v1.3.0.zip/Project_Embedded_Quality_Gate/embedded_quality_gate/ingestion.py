from __future__ import annotations

from pathlib import Path

from .scope import confined_path
from .util import sha256_file, stable_id, utc_now

ALLOWED_EXTENSIONS={'.ja','.jaa','.jad','.jasec','.jaops','.jaui','.deepml','.dmk','.md','.json','.txt','.csv','.py','.cmd','.ps1','.sh','.yml','.yaml'}
SKIP_DIRS={'.git','.eqg_runtime','quality_gate/evidence','__pycache__'}

def inventory_repository(root: Path, revision: str, max_files: int=100000):
    root=root.resolve(); records=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if any(rel==s or rel.startswith(s.rstrip('/')+'/') for s in SKIP_DIRS): continue
        if len(records)>=max_files: raise RuntimeError('repository file limit exceeded')
        stat=p.stat(); rec={'path':rel,'size':stat.st_size,'sha256':sha256_file(p),'source_revision':revision,
                            'observed_at':utc_now(),'extension':p.suffix.lower(),'classification':'repository'}
        rec['evidence_id']=stable_id('evidence',rec)
        records.append(rec)
    return records

def ingest_file(root: Path, rel: str, revision: str, max_bytes: int=4*1024*1024):
    p=confined_path(root,rel); size=p.stat().st_size
    if size>max_bytes: raise RuntimeError('file exceeds configured limit')
    rec={'path':p.relative_to(root.resolve()).as_posix(),'size':size,'sha256':sha256_file(p),
         'source_revision':revision,'observed_at':utc_now(),'classification':'repository'}
    rec['evidence_id']=stable_id('evidence',rec); return rec
