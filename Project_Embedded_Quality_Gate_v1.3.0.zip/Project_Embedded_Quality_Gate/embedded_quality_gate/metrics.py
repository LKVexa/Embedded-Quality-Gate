"""Operational counters and ground-truth accuracy tracking.

Serves: XOBS-02 (latency, cost, tool failures, abstention, approval, override
rates), XOBS-03 (false-positive/false-negative rates where ground truth
exists).

Cost is reported as INDETERMINATE rather than 0.00 when no priced provider is
configured: a self-hosted or absent model has an unknown cost, and printing a
zero would be a fabricated figure.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

INDETERMINATE = "INDETERMINATE"

COUNTERS = (
    "tool_calls", "tool_failures", "model_calls", "abstentions",
    "approvals", "rejections", "overrides", "scope_narrowings",
    "guardrail_blocks", "workflow_aborts",
)


@dataclass
class MetricsCollector:
    """Counters, latency samples, and confusion counts for one run."""

    counters: dict[str, int] = field(default_factory=lambda: dict.fromkeys(COUNTERS, 0))
    latencies_ms: dict[str, list[float]] = field(default_factory=dict)
    confusion: dict[str, int] = field(default_factory=lambda: {"tp": 0, "fp": 0, "tn": 0, "fn": 0})
    cost_units: float | None = None

    def incr(self, name: str, by: int = 1) -> int:
        if name not in self.counters:
            raise KeyError(f"unknown counter: {name}")
        self.counters[name] += by
        return self.counters[name]

    def observe_latency(self, operation: str, ms: float) -> None:
        self.latencies_ms.setdefault(operation, []).append(round(float(ms), 3))

    def observe_outcome(self, predicted_positive: bool, actually_positive: bool) -> None:
        """Record one ground-truth comparison (XOBS-03)."""
        key = ("tp" if actually_positive else "fp") if predicted_positive else ("fn" if actually_positive else "tn")
        self.confusion[key] += 1

    def rates(self) -> dict[str, Any]:
        """Accuracy rates, or None where the denominator is empty.

        A rate over zero observations is not zero — it does not exist — so it is
        reported as None rather than as a flattering 0.0.
        """
        c = self.confusion
        pos, neg = c["tp"] + c["fn"], c["fp"] + c["tn"]
        return {
            "false_negative_rate": round(c["fn"] / pos, 4) if pos else None,
            "false_positive_rate": round(c["fp"] / neg, 4) if neg else None,
            "observations": sum(c.values()),
        }

    def latency_summary(self) -> dict[str, dict[str, float]]:
        out = {}
        for op, samples in self.latencies_ms.items():
            ordered = sorted(samples)
            out[op] = {
                "count": len(ordered),
                "p50_ms": ordered[len(ordered) // 2],
                "max_ms": ordered[-1],
            }
        return out

    def snapshot(self) -> dict[str, Any]:
        tool_calls = self.counters["tool_calls"]
        decisions = self.counters["approvals"] + self.counters["rejections"]
        return {
            "counters": dict(self.counters),
            "latency": self.latency_summary(),
            "accuracy": self.rates(),
            "tool_failure_rate": round(self.counters["tool_failures"] / tool_calls, 4) if tool_calls else None,
            "abstention_rate": round(self.counters["abstentions"] / self.counters["model_calls"], 4)
            if self.counters["model_calls"] else None,
            "override_rate": round(self.counters["overrides"] / decisions, 4) if decisions else None,
            "cost": self.cost_units if self.cost_units is not None else INDETERMINATE,
        }
