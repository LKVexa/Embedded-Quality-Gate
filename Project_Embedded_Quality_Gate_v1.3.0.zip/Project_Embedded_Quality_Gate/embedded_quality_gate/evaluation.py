"""Offline evaluation measured against a named corpus.

Serves: XEVAL-01…XEVAL-05, VERIFY-03, IMPL-10.

The previous implementation ran five hand-written cases that compared the code
against itself and then set ``grounding_rate = 1.0 if all(...) else 0.0``. That
is a tautology, not a measurement, and the "100.00% grounding / 0.00% false
positive" line in the v1.0.0-rc1 report was an artefact of that expression.

This module measures. Detection recall is computed over labelled attack cases
and the false-positive rate over labelled benign controls, both from
``quality_gate/corpus/``. If the corpus is absent, the result carries
``measured: false`` and the rates are ``None`` — the evaluation reports that it
could not measure rather than emitting a number it did not compute.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .content_defense import scan_document
from .release import evaluate_readiness, promotion_allowed
from .uncertainty import EvidenceState

CORPUS_PATH = Path("quality_gate") / "corpus" / "content_defense_corpus.json"
HELDOUT_CORPUS_PATH = Path("quality_gate") / "corpus" / "heldout_corpus.json"
THRESHOLDS_PATH = Path("quality_gate") / "config" / "thresholds.json"


def _load_corpus(root: Path, relative: Path = CORPUS_PATH) -> dict[str, Any] | None:
    path = Path(root) / relative
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _score_corpus(corpus: dict[str, Any]) -> dict[str, Any]:
    """Score one labelled corpus. Shared by the tuned and held-out measurements
    so neither can drift into a different definition of recall."""
    tp = fn = fp = tn = 0
    misses: list[str] = []
    false_alarms: list[str] = []
    per_source: dict[str, dict[str, int]] = {}
    for case in corpus["cases"]:
        flagged = scan_document(case["text"], case["id"])["flagged"]
        bucket = per_source.setdefault(
            case.get("source", corpus.get("name", "corpus")),
            {"attack": 0, "benign": 0, "detected": 0, "false_alarm": 0},
        )
        if case["label"] == "attack":
            bucket["attack"] += 1
            if flagged:
                tp += 1
                bucket["detected"] += 1
            else:
                fn += 1
                misses.append(case["id"])
        else:
            bucket["benign"] += 1
            if flagged:
                fp += 1
                bucket["false_alarm"] += 1
                false_alarms.append(case["id"])
            else:
                tn += 1
    attacks = tp + fn
    benign = fp + tn
    return {
        "true_positive": tp, "false_negative": fn,
        "false_positive": fp, "true_negative": tn,
        "attack_count": attacks, "benign_count": benign,
        "grounding_rate": round(tp / attacks, 4) if attacks else None,
        "false_positive_rate": round(fp / benign, 4) if benign else None,
        "missed_cases": misses,
        "false_alarm_cases": false_alarms,
        "per_source": per_source,
    }


def evaluate_content_defense(root: Path) -> dict[str, Any]:
    """Measure detection recall and false-positive rate over the corpus."""
    corpus = _load_corpus(root)
    if not corpus or not corpus.get("cases"):
        return {
            "measured": False,
            "reason": f"no corpus at {CORPUS_PATH.as_posix()}; rates cannot be computed",
            "corpus": {},
            "grounding_rate": None,
            "false_positive_rate": None,
        }
    tp = fn = fp = tn = 0
    misses: list[str] = []
    false_alarms: list[str] = []
    for case in corpus["cases"]:
        flagged = scan_document(case["text"], case["id"])["flagged"]
        if case["label"] == "attack":
            if flagged:
                tp += 1
            else:
                fn += 1
                misses.append(case["id"])
        else:
            if flagged:
                fp += 1
                false_alarms.append(case["id"])
            else:
                tn += 1
    attacks = tp + fn
    benign = fp + tn
    return {
        "measured": True,
        "corpus": {
            "name": corpus.get("name"),
            "case_count": corpus.get("case_count"),
            "attack_count": attacks,
            "benign_count": benign,
        },
        "true_positive": tp, "false_negative": fn,
        "false_positive": fp, "true_negative": tn,
        # Grounding here is detection recall on labelled attacks: of the content
        # that genuinely carries an embedded instruction, how much did the gate
        # anchor a finding to. It is not a self-consistency score.
        "grounding_rate": round(tp / attacks, 4) if attacks else None,
        "false_positive_rate": round(fp / benign, 4) if benign else None,
        "missed_cases": misses,
        "false_alarm_cases": false_alarms,
    }


def evaluate_abstention() -> dict[str, Any]:
    """Guardrail behaviour cases: the gate must fail closed on weak evidence."""
    cases = []

    def case(name: str, actual: Any, expected: Any) -> None:
        cases.append({"name": name, "actual": actual, "expected": expected, "pass": actual == expected})

    case("missing_context_abstains", EvidenceState("missing", None, "fixture").disposition(), "abstain")
    case("stale_context_abstains", EvidenceState("stale", 0.9, "fixture").disposition(), "abstain")
    case("ambiguous_high_impact_reviews", EvidenceState("uncertain", 0.8, "fixture", True).disposition(), "review")
    case("low_confidence_abstains", EvidenceState("inferred", 0.4, "fixture").disposition(), "abstain")
    case("readiness_without_evidence_denies", promotion_allowed(evaluate_readiness({})), False)
    return {
        "cases": cases,
        "passed": sum(1 for c in cases if c["pass"]),
        "total": len(cases),
        "fail_closed": all(c["pass"] for c in cases),
    }


def run_offline_evaluation(root: Path | str = ".") -> dict[str, Any]:
    """Full offline evaluation: measured detection plus guardrail behaviour."""
    root = Path(root)
    detection = evaluate_content_defense(root)
    abstention = evaluate_abstention()
    reviewed = sum(1 for c in abstention["cases"] if c["actual"] == "review")
    return {
        "schema_version": "eqg.evaluation/1.1",
        "detection": detection,
        "abstention": abstention,
        "corpus": detection["corpus"],
        "measured": detection["measured"],
        "grounding_rate": detection["grounding_rate"],
        "false_positive_rate": detection["false_positive_rate"],
        # Review burden (XEVAL-04): the share of behaviour cases that require a
        # human rather than resolving automatically. Reported alongside task
        # completion, never instead of it.
        "review_burden_rate": round(reviewed / abstention["total"], 4) if abstention["total"] else None,
        "guardrails_fail_closed": abstention["fail_closed"],
    }


def _heldout_thresholds(root: Path) -> dict[str, Any]:
    path = Path(root) / THRESHOLDS_PATH
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("heldout", {})
    except (OSError, json.JSONDecodeError):
        return {}


def run_heldout_evaluation(root: Path | str = ".") -> dict[str, Any]:
    """Measure the detector against a corpus it was never tuned on.

    The tuned corpus (``content_defense_corpus.json``) is built from the BIPIA
    *test* splits, which is also what the detector's signals were developed
    against; a rate measured there shows fit, not generalisation. This corpus is
    disjoint by construction — BIPIA *train* splits plus benign business email
    from a different donor — so its rates answer a different question and are
    reported next to the tuned rates, never in place of them.

    Fail-closed on absence: a missing or unreadable corpus is an error, because
    silently reporting "no held-out measurement" would let the claim disappear.
    The measured rates themselves are checked against declared *floors* and are
    reported as floors, not as release gates — see thresholds.heldout.rationale.
    """
    root = Path(root)
    corpus = _load_corpus(root, HELDOUT_CORPUS_PATH)
    thresholds = _heldout_thresholds(root)
    if not corpus or not corpus.get("cases"):
        return {
            "schema_version": "eqg.heldout-evaluation/1.0",
            "measured": False,
            "reason": f"no corpus at {HELDOUT_CORPUS_PATH.as_posix()}; generalisation cannot be measured",
            "thresholds": thresholds,
            "floor_met": None,
            "gating": bool(thresholds.get("gating", False)),
        }
    scored = _score_corpus(corpus)
    recall = scored["grounding_rate"]
    fpr = scored["false_positive_rate"]
    min_recall = thresholds.get("min_attack_recall")
    max_fpr = thresholds.get("max_false_positive_rate")
    recall_ok = None if (recall is None or min_recall is None) else recall >= min_recall
    fpr_ok = None if (fpr is None or max_fpr is None) else fpr <= max_fpr
    return {
        "schema_version": "eqg.heldout-evaluation/1.0",
        "measured": True,
        "corpus": {
            "name": corpus.get("name"),
            "case_count": corpus.get("case_count"),
            "attack_count": scored["attack_count"],
            "benign_count": scored["benign_count"],
        },
        "detection": scored,
        "grounding_rate": recall,
        "false_positive_rate": fpr,
        "thresholds": thresholds,
        "recall_floor_met": recall_ok,
        "false_positive_floor_met": fpr_ok,
        "floor_met": None if (recall_ok is None or fpr_ok is None) else bool(recall_ok and fpr_ok),
        # Reported, not gating: see thresholds.heldout.rationale. Turning this
        # into a release gate changes the release semantics of an audited
        # programme and is the owner's decision, not this module's.
        "gating": bool(thresholds.get("gating", False)),
    }
