from __future__ import annotations

from collections import defaultdict

SEVERITY_RANK={'info':0,'low':1,'medium':2,'high':3,'critical':4}

def deduplicate(findings):
    out={}
    for f in findings:
        key=(f.finding_type,f.path,f.symbol,f.message)
        if key not in out or (SEVERITY_RANK[f.severity],f.confidence)>(SEVERITY_RANK[out[key].severity],out[key].confidence): out[key]=f
    return sorted(out.values(),key=lambda f:(-SEVERITY_RANK[f.severity],-f.confidence,f.path,f.message))

def summarize(findings, checked_files:int, unchecked_categories=None):
    findings=deduplicate(findings); by=defaultdict(int)
    for f in findings: by[f.severity]+=1
    return {'checked_files':checked_files,'finding_count':len(findings),'severity_counts':dict(by),
            'unchecked_categories':list(unchecked_categories or []),
            'release_blocking':any(f.severity in {'critical','high'} and not f.suppressed for f in findings),
            'findings':[{'id':f.id,'type':f.finding_type,'severity':f.severity,'confidence':f.confidence,'message':f.message,
                         'path':f.path,'symbol':f.symbol,'evidence_ids':list(f.evidence_ids),'inference':f.inference} for f in findings]}
