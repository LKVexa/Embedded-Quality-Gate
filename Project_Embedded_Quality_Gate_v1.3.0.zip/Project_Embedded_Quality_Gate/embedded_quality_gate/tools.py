from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .policy import AuthorityContext, PolicyEngine
from .scope import confined_path


class ToolDenied(PermissionError): pass

# Directories considered trusted for allowlisted executables. Caller PATH is
# not consulted: a poisoned PATH used to make shutil.which('python') return
# /tmp/python. sys.executable's parent is included so venv interpreters still
# resolve during tests and local runs.
_TRUSTED_PATH_DIRS = ('/usr/bin', '/bin', '/usr/local/bin', '/opt/homebrew/bin')


def trusted_path() -> str:
    dirs = [str(Path(sys.executable).resolve().parent), *_TRUSTED_PATH_DIRS]
    seen: list[str] = []
    for item in dirs:
        if item and item not in seen and Path(item).is_dir():
            seen.append(item)
    return os.pathsep.join(seen)


class SafeCommandRunner:
    """No-shell runner using trusted PATH resolution plus an explicit allowlist.

    A basename match alone is insufficient: ``/tmp/python`` used to satisfy an
    allowlist entry named ``python``.  The executable is resolved from a
    trusted PATH, not the caller environment, and path-qualified argv[0]
    values must resolve to that same trusted executable.
    """
    def __init__(self,root:Path,policy:PolicyEngine,allowlist=(),timeout_seconds=30):
        self.root=root.resolve(); self.policy=policy; self.allowlist=frozenset(str(x).lower() for x in allowlist); self.timeout=timeout_seconds
    def _resolve_tool(self, raw: str) -> str:
        name=Path(raw).name.lower()
        if name not in self.allowlist: raise ToolDenied(f'tool not allowlisted: {name}')
        search=trusted_path()
        trusted=shutil.which(name, path=search)
        if not trusted: raise ToolDenied(f'allowlisted tool not found on trusted PATH: {name}')
        raw_path=Path(raw)
        if raw_path.is_absolute() or raw_path.parent != Path('.'):
            try:
                if raw_path.resolve() != Path(trusted).resolve():
                    raise ToolDenied(f'path-qualified executable is not the trusted PATH target: {raw}')
            except OSError as exc:
                raise ToolDenied(f'cannot resolve executable: {raw}') from exc
        return trusted
    def run(self,argv,ctx:AuthorityContext,cwd='.'):
        if not argv or not isinstance(argv,(list,tuple)): raise ToolDenied('argv list required')
        trusted=self._resolve_tool(str(argv[0]))
        work=confined_path(self.root,cwd); self.policy.authorize(ctx,'execute',str(work.relative_to(self.root)))
        env={'PATH':trusted_path(),'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'}
        # noqa reason: argv[0] is resolved to an allowlisted executable on the
        # trusted PATH by _resolve_tool, the working directory is confined, the
        # environment is rebuilt, and shell=False. That is the whole point of
        # this class; S603 cannot see it.
        return subprocess.run([trusted,*[str(x) for x in argv[1:]]],cwd=work,env=env,shell=False,capture_output=True,text=True,  # noqa: S603
                              timeout=self.timeout,check=False)
