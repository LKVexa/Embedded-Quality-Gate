from __future__ import annotations

from pathlib import Path


class ScopeViolation(PermissionError): pass

def confined_path(root: Path, candidate: str | Path, *, allow_missing: bool=False) -> Path:
    root=root.resolve()
    # Resolve lexically first so an out-of-scope missing path is denied as a scope violation
    # instead of leaking a FileNotFoundError before the authorization boundary runs.
    p=(root/Path(candidate)).resolve(strict=False)
    try: p.relative_to(root)
    except ValueError as e: raise ScopeViolation(f'path escapes repository: {candidate}') from e
    if not allow_missing and not p.exists(): raise ScopeViolation(f'path does not exist: {candidate}')
    return p

def reject_symlink_escape(root: Path, candidate: str | Path) -> Path:
    p=confined_path(root,candidate)
    cur=p
    while cur != root.resolve():
        if cur.is_symlink():
            target=cur.resolve()
            try: target.relative_to(root.resolve())
            except ValueError as e: raise ScopeViolation(f'symlink escapes repository: {candidate}') from e
        cur=cur.parent
    return p
