from __future__ import annotations

from pathlib import Path

TEST_EXT={'.py','.ja','.jaa','.jad','.jasec','.jaops','.jaui','.deepml','.dmk','.jate'}
SKIP_PARTS={'.git','.eqg_runtime','__pycache__','evidence'}

def _is_associated(stem: str, test_stem: str) -> bool:
    stem=stem.lower(); test_stem=test_stem.lower()
    return test_stem in {f'test_{stem}', f'{stem}_test', stem} or test_stem.endswith(f'_{stem}_test')

def analyze_test_gaps(root:Path,changed_paths):
    tests=[]
    for p in root.rglob('*'):
        if not p.is_file() or any(part in SKIP_PARTS for part in p.parts): continue
        if p.suffix.lower() not in TEST_EXT: continue
        rel=p.relative_to(root)
        if p.name.startswith('test_') or p.name.endswith('_test.py') or 'tests' in rel.parts:
            tests.append(rel.as_posix())
    gaps=[]
    for rel in changed_paths:
        p=root/rel
        if p.suffix.lower() in {'.py','.ja','.jaa','.jad','.jasec','.jaops','.jaui','.deepml'}:
            stem=p.stem.lower().replace('.','_')
            if stem.startswith('test_') or stem.endswith('_test'):
                continue
            if not any(_is_associated(stem, Path(t).stem.lower()) for t in tests):
                gaps.append({'path':rel,'reason':'no directly associated test discovered'})
    return {'test_files':sorted(tests),'gaps':gaps,'coverage_state':'unknown_without_instrumented_toolchain'}
