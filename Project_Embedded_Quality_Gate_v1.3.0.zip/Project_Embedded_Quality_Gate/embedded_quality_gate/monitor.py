from __future__ import annotations


class PermissionMonitor:
 def __init__(self): self.events=[]
 def record(self,action,allowed,reason=''):
  evt={'action':action,'allowed':bool(allowed),'reason':reason,'alert':(not allowed and action in {'modify','commit','approve','deploy','execute'})}
  self.events.append(evt);return evt
 def alerts(self):return [e for e in self.events if e['alert']]
