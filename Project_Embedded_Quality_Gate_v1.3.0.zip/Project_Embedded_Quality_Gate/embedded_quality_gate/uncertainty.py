from __future__ import annotations

from dataclasses import dataclass

VALID={'known','supported','inferred','uncertain','stale','missing','out_of_scope'}
@dataclass(frozen=True)
class EvidenceState:
 state:str; confidence:float|None; reason:str; high_impact:bool=False
 def __post_init__(self):
  if self.state not in VALID: raise ValueError('invalid evidence state')
  if self.confidence is not None and not 0<=self.confidence<=1: raise ValueError('confidence out of range')
 def disposition(self,abstain_threshold=0.7):
  if self.state in {'stale','missing','out_of_scope'}: return 'abstain'
  if self.high_impact and self.state in {'inferred','uncertain'}: return 'review'
  if self.confidence is not None and self.confidence<abstain_threshold: return 'abstain'
  return 'continue'

def confidence_from_validation(correct:int,total:int):
 if total<=0:return None
 return correct/total
