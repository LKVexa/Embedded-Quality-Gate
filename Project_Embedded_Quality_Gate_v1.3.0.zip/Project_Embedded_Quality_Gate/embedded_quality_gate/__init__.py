"""Embedded Quality Gate repository-local reference implementation."""
from .version import __version__

__all__ = ["__version__"]
