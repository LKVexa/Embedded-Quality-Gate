"""Retention enforcement that cannot delete the audit trail.

Serves: data governance retention, and the append-only guarantee that
STORE/XSEC assert.

The previous implementation walked the whole tree, took every file older than
the cutoff and called `p.unlink()`. Nothing excluded the evidence tree or the
provenance chain, and it authorised under the generic `modify` action — so the
routine that enforced data governance could delete the record that proves the
gate behaved. Protected paths are now refused explicitly (and reported), and
deletion requires the distinct `execute` authority rather than `modify`.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from .policy import AuthorityContext, PolicyEngine

#: Path prefixes that retention must never delete, whatever their age.
PROTECTED_PREFIXES: tuple[str, ...] = (
    "quality_gate/evidence/",
    "quality_gate/traceability/",
    ".eqg_runtime/provenance/",
)

#: Exact filenames that are append-only wherever they appear.
PROTECTED_NAMES: tuple[str, ...] = (
    "09_provenance.jsonl",
    "provenance.jsonl",
    "evidence_manifest.json",
)


def is_protected(rel_path: str) -> bool:
    """True when `rel_path` belongs to the append-only audit trail."""
    if any(rel_path.startswith(p) for p in PROTECTED_PREFIXES):
        return True
    return rel_path.rsplit("/", 1)[-1] in PROTECTED_NAMES


def expired_files(root: Path, retention_days: int, now=None) -> list[Path]:
    """Files older than the retention window, protected paths excluded."""
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=retention_days)
    out = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if is_protected(rel):
            continue
        if datetime.fromtimestamp(p.stat().st_mtime, timezone.utc) < cutoff:
            out.append(p)
    return sorted(out)


def protected_expired_files(root: Path, retention_days: int, now=None) -> list[str]:
    """Audit-trail files past the window that were refused rather than deleted."""
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=retention_days)
    out = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if is_protected(rel) and datetime.fromtimestamp(p.stat().st_mtime, timezone.utc) < cutoff:
            out.append(rel)
    return sorted(out)


def enforce_retention(
    root: Path,
    retention_days: int,
    policy: PolicyEngine,
    ctx: AuthorityContext,
    dry_run: bool = True,
) -> dict[str, list[str]]:
    """Apply the retention window; never touches the append-only trail.

    Returns a record with `candidates`, `deleted`, and `refused_protected`, so a
    refusal is visible in the run artefact instead of being silently skipped.
    Deletion requires the `execute` action: a destructive operation must not
    ride on the same grant as an ordinary edit.
    """
    items = expired_files(root, retention_days, )
    refused = protected_expired_files(root, retention_days)
    candidates = [p.relative_to(root).as_posix() for p in items]
    if dry_run:
        return {"candidates": candidates, "deleted": [], "refused_protected": refused}
    policy.authorize(ctx, "execute", ".")
    deleted = []
    for p in items:
        rel = p.relative_to(root).as_posix()
        if is_protected(rel):  # belt and braces: never delete a protected path
            refused.append(rel)
            continue
        p.unlink()
        deleted.append(rel)
    return {"candidates": candidates, "deleted": deleted, "refused_protected": sorted(set(refused))}
