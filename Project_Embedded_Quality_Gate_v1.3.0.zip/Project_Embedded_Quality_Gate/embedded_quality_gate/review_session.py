from __future__ import annotations

from dataclasses import dataclass, field

from .util import utc_now


class ReviewError(RuntimeError):pass
@dataclass
class ReviewSession:
 scope_paths:list[str]; evidence_ids:list[str]; checked_categories:list[str]; unchecked_categories:list[str]
 state:str='preview'; history:list[dict]=field(default_factory=list); final_accountability:str='human'
 def _record(self,op,**kw):self.history.append({'at':utc_now(),'operation':op,**kw})
 def narrow_scope(self,paths):
  new=[p for p in paths if p in self.scope_paths]
  if not new: raise ReviewError('narrowed scope cannot be empty or wider than original')
  self.scope_paths=new;self._record('narrow_scope',paths=list(new));return self
 def reject(self,reason): self.state='rejected';self._record('reject',reason=reason);return self
 def request_more_evidence(self,reason): self.state='needs_evidence';self._record('request_more_evidence',reason=reason);return self
 def edit_draft(self,change_note): self._record('edit',change_note=change_note);return self
 def approve_preview(self):
  raise ReviewError('review session cannot self-issue approval; use approval policy with human authority')
