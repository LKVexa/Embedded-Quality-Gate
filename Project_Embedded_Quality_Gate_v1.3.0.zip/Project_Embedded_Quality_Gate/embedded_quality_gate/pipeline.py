"""Minimal-impact deterministic gate for save/stage/pre-PR integrations."""
from __future__ import annotations

from pathlib import Path

from .analyzers import CODE_EXT, analyze_repository
from .content_defense import scan_document
from .contracts import Finding
from .diff_parser import FileDiff, impacted_paths, parse_unified_diff, reconstruct_new_text
from .impact import minimal_impact
from .quality import summarize
from .scope import ScopeViolation, confined_path
from .testgap import analyze_test_gaps
from .util import sha256_bytes, stable_id


def _evidence(rel: str, payload: str) -> str:
    return stable_id('evidence', {'path': rel, 'sha256': sha256_bytes(payload.encode('utf-8', errors='replace'))})


def run_diff_gate(root: Path | str, diff_text: str, *, max_bytes: int=5*1024*1024) -> dict:
    root=Path(root).resolve()
    files=parse_unified_diff(diff_text,max_bytes=max_bytes)
    changed=impacted_paths(files)
    invalid=[]; normalized=[]
    for rel in changed:
        try:
            p=confined_path(root,rel,allow_missing=True)
            normalized.append(p.relative_to(root).as_posix())
        except ScopeViolation:
            invalid.append(rel)
    if invalid:
        return {'status':'BLOCKED','reason':'diff contains path(s) outside repository','invalid_paths':invalid,
                'changed_paths':changed,'impacted_paths':[],'summary':None,'test_gaps':None}
    impact=minimal_impact(root,normalized)
    analysis=analyze_repository(root,impact['impacted_paths'])
    extra: list[Finding] = []
    reconstructed=0
    missing_supported=[]
    for rel in impact['impacted_paths']:
        fd: FileDiff | None = None
        for item in files:
            new=_norm(item.new_path); old=_norm(item.old_path)
            if new==rel or old==rel:
                fd=item; break
        disk=root/rel
        text=None
        if disk.is_file():
            try: text=disk.read_text(encoding='utf-8')
            except UnicodeDecodeError:
                extra.append(Finding('encoding','high',1.0,'Changed source file is not UTF-8',(_evidence(rel,''),),rel))
                continue
        reconstructed_text=reconstruct_new_text(fd) if fd is not None else None
        if reconstructed_text is not None:
            reconstructed += 1
            from .analyzers import analyze_text
            extra.extend(analyze_text(reconstructed_text, rel))
            if not disk.is_file():
                analysis['checked_files']=analysis.get('checked_files',0)+1
            text = reconstructed_text if text is None else reconstructed_text
        if text is None:
            if Path(rel).suffix.lower() in CODE_EXT:
                missing_supported.append(rel)
            continue
        if _should_scan_defense(rel):
            scan=scan_document(text, rel)
            if scan.get('flagged'):
                extra.append(Finding('content_defense','high',1.0,
                    f"embedded instruction/payload detected ({scan.get('reason')}: {', '.join(scan.get('signals') or [])})",
                    (_evidence(rel,text),),rel))
    if missing_supported:
        extra.append(Finding('missing_changed_file','high',1.0,
            f"changed supported files have no on-disk or reconstructed content: {', '.join(missing_supported[:8])}",
            (_evidence('diff', diff_text[:200]),),'<diff>'))
    analysis['findings']=list(analysis.get('findings') or [])+extra
    gaps=analyze_test_gaps(root,impact['impacted_paths'])
    unchecked=['instrumented coverage'] if gaps['coverage_state'].startswith('unknown') else []
    summary=summarize(analysis['findings'],analysis['checked_files'],unchecked_categories=unchecked)
    return {'status':'BLOCKED' if summary['release_blocking'] else 'PASS',
            'changed_paths':normalized,'impact':impact,'summary':summary,'test_gaps':gaps,
            'reconstructed_files':reconstructed}


def _norm(path: str) -> str:
    return path[2:] if path.startswith(('a/','b/')) else path


def _should_scan_defense(rel: str) -> bool:
    if rel.startswith('quality_gate/corpus/'): return False
    suffix=Path(rel).suffix.lower()
    return suffix in CODE_EXT or suffix in {'.md','.txt','.rst'}
