from __future__ import annotations

import re
from dataclasses import asdict, dataclass

from .util import stable_id


@dataclass(frozen=True)
class Hunk:
    old_start:int; old_count:int; new_start:int; new_count:int; lines:tuple[str,...]
@dataclass(frozen=True)
class FileDiff:
    old_path:str; new_path:str; hunks:tuple[Hunk,...]
    @property
    def id(self): return stable_id('diff',asdict(self))

HUNK=re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@')
BINARY=re.compile(r'^Binary files (.+) and (.+) differ$')
GIT_HEADER=re.compile(r'^diff --git a/(.+) b/(.+)$')
RENAME_FROM=re.compile(r'^rename from (.+)$')
RENAME_TO=re.compile(r'^rename to (.+)$')

def _unquote_git_path(path: str) -> str:
    path=path.strip()
    if len(path)>=2 and path[0]=='"' and path[-1]=='"':
        inner=path[1:-1]
        inner=inner.replace('\\n','\n').replace('\\t','\t').replace('\\"','"').replace('\\\\','\\')
        path=inner
    if path.startswith('a/') or path.startswith('b/'):
        return path[2:]
    return path

def parse_unified_diff(text:str,max_bytes:int=5*1024*1024):
    if text.startswith('\ufeff'):
        text=text.lstrip('\ufeff')
    if len(text.encode('utf-8'))>max_bytes: raise ValueError('diff exceeds configured limit')
    files=[]; current=None; hunks=[]; h=None; lines=[]
    pending_git=None
    def finish_hunk():
        nonlocal h,lines,hunks
        if h:
            old_seen=sum(1 for line in lines if line.startswith((' ','-')))
            new_seen=sum(1 for line in lines if line.startswith((' ','+')))
            if old_seen!=h[1] or new_seen!=h[3]:
                raise ValueError(f'hunk line counts do not match header (old {old_seen}/{h[1]}, new {new_seen}/{h[3]})')
            hunks.append(Hunk(h[0],h[1],h[2],h[3],tuple(lines)))
        h=None; lines=[]
    def finish_file():
        nonlocal current,hunks
        finish_hunk()
        if current: files.append(FileDiff(current[0],current[1],tuple(hunks)))
        current=None; hunks=[]
    ls=text.splitlines(); i=0
    rename_from=None
    while i<len(ls):
        line=ls[i]
        git=GIT_HEADER.match(line)
        if git:
            pending_git=(_unquote_git_path('a/'+git.group(1)), _unquote_git_path('b/'+git.group(2)))
            i+=1; continue
        binary=BINARY.match(line)
        if binary:
            finish_file()
            files.append(FileDiff(_unquote_git_path(binary.group(1)),_unquote_git_path(binary.group(2)),tuple()))
            pending_git=None; i+=1; continue
        rf=RENAME_FROM.match(line)
        if rf:
            rename_from=_unquote_git_path(rf.group(1)); i+=1; continue
        rt=RENAME_TO.match(line)
        if rt:
            finish_file()
            old=rename_from or (pending_git[0] if pending_git else _unquote_git_path(rt.group(1)))
            new=_unquote_git_path(rt.group(1))
            files.append(FileDiff(old,new,tuple()))
            rename_from=None; pending_git=None; i+=1; continue
        if line.startswith('--- '):
            finish_file(); old=_unquote_git_path(line[4:].split('\t')[0])
            if i+1>=len(ls) or not ls[i+1].startswith('+++ '): raise ValueError('missing +++ after ---')
            new=_unquote_git_path(ls[i+1][4:].split('\t')[0])
            current=(old,new); pending_git=None; i+=2; continue
        m=HUNK.match(line)
        if m:
            if current is None:
                if pending_git:
                    current=pending_git
                else:
                    raise ValueError('hunk appears before file header')
            finish_hunk(); h=(int(m.group(1)),int(m.group(2) or 1),int(m.group(3)),int(m.group(4) or 1)); i+=1; continue
        if h is not None:
            if line.startswith((' ','+','-','\\')): lines.append(line)
            elif line.startswith('diff --git '):
                finish_file()
                git=GIT_HEADER.match(line)
                pending_git=(_unquote_git_path('a/'+git.group(1)), _unquote_git_path('b/'+git.group(2))) if git else None
            else: raise ValueError('malformed hunk line')
        i+=1
    finish_file()
    if pending_git and not any(f.new_path==pending_git[1] or f.old_path==pending_git[0] for f in files):
        files.append(FileDiff(pending_git[0],pending_git[1],tuple()))
    return files

def reconstruct_new_text(filediff: FileDiff | None) -> str | None:
    """Join added and context lines from hunks into reconstructed new-side text.

    This is exact for new files (typically one hunk covering the whole file) and
    a best-effort slice for partial modifications. None means nothing reconstructable.
    """
    if filediff is None or not filediff.hunks:
        return None
    out: list[str] = []
    for hunk in filediff.hunks:
        for line in hunk.lines:
            if line.startswith(('+',' ')):
                out.append(line[1:])
    return '\n'.join(out)+('\n' if out else '')

def impacted_paths(files):
    return sorted({f.new_path for f in files if f.new_path!='/dev/null'} | {f.old_path for f in files if f.old_path!='/dev/null'})
