from __future__ import annotations


class ToolOutputError(ValueError):pass
def validate_tool_result(result,max_output_chars=100000):
 if result is None: raise ToolOutputError('missing tool result')
 rc=getattr(result,'returncode',None);out=getattr(result,'stdout',None);err=getattr(result,'stderr',None)
 if not isinstance(rc,int) or not isinstance(out,str) or not isinstance(err,str): raise ToolOutputError('invalid tool result shape')
 if len(out)+len(err)>max_output_chars: raise ToolOutputError('tool output exceeds configured bound')
 return {'returncode':rc,'stdout':out,'stderr':err,'status':'success' if rc==0 else 'failure'}
