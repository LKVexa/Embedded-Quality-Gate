from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .util import sha256_file, stable_id, utc_now


@dataclass(frozen=True)
class SourceSpec:
    source_id:str; patterns:tuple[str,...]; required:bool=False; classification:str='repository'

DEFAULT_SOURCES=(
 SourceSpec('working_tree_diff',('*.diff','*.patch')),
 SourceSpec('repository_source',('*.ja','*.jaa','*.jad','*.jasec','*.jaops','*.jaui','*.jasp','*.jate','*.deepml','*.dmk','*.ebnf')),
 SourceSpec('coding_standards',('.editorconfig','pyproject.toml','setup.cfg','.flake8','.pylintrc','*.md')),
 SourceSpec('test_suites',('test_*.py','*_test.py','tests/**/*')),
 SourceSpec('security_rules',('SECURITY.md','*.jasec','*security*','*policy*')),
 SourceSpec('historical_review_patterns',('CHANGELOG*','HISTORY*','*review*','*defect*')),
)

def discover(root:Path,spec:SourceSpec,revision:str,max_matches=10000):
    root=root.resolve(); seen=set(); records=[]
    for pattern in spec.patterns:
        for p in root.rglob(pattern):
            if not p.is_file(): continue
            rel=p.relative_to(root).as_posix()
            if rel in seen or rel.startswith('quality_gate/evidence/'): continue
            seen.add(rel)
            if len(records)>=max_matches: raise RuntimeError(f'source {spec.source_id} match limit exceeded')
            rec={'source_id':spec.source_id,'path':rel,'sha256':sha256_file(p),'revision':revision,'observed_at':utc_now(),
                 'classification':spec.classification,'freshness':'current'}
            rec['evidence_id']=stable_id('evidence',rec);records.append(rec)
    state='available' if records else ('missing_required' if spec.required else 'missing_optional')
    return {'source_id':spec.source_id,'state':state,'records':records}

def discover_all(root:Path,revision:str,specs=DEFAULT_SOURCES):
    return {s.source_id:discover(root,s,revision) for s in specs}
