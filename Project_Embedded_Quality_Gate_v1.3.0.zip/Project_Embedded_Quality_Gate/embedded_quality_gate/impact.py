from __future__ import annotations

import re
from pathlib import Path

SUITE_REF=re.compile(r'\bSuite_(\d{2})_[A-Za-z0-9_]+\b')
SUITE_DIR=re.compile(r'^\s*###\s+(\d{2})\.')

def suite_inventory(root:Path):
    inv={}
    index=root/'ALL_SUITES_REPOSITORY_66_MODULES.md'
    if index.exists():
        for line in index.read_text(encoding='utf-8').splitlines():
            m=SUITE_DIR.match(line)
            if m: inv[int(m.group(1))]=line.split('.',1)[1].strip()
    return inv

def file_suite_map(root:Path):
    inv=suite_inventory(root); mapping={}
    for n,name in inv.items():
        d=root/name
        if d.exists():
            for p in d.rglob('*'):
                if p.is_file(): mapping[p.relative_to(root).as_posix()]=n
    return mapping

def dependency_graph(root:Path):
    fmap=file_suite_map(root); graph={n:set() for n in set(fmap.values())}
    for rel,n in fmap.items():
        p=root/rel
        if p.suffix.lower() not in {'.ja','.jaa','.jad','.jasec','.jaops','.jaui','.deepml','.md'}: continue
        try:text=p.read_text(encoding='utf-8')
        except UnicodeDecodeError:continue
        for ref in SUITE_REF.findall(text): graph.setdefault(n,set()).add(int(ref))
    return graph

def minimal_impact(root:Path,changed_paths):
    fmap=file_suite_map(root); graph=dependency_graph(root); changed=set(changed_paths); suites={fmap[p] for p in changed if p in fmap}
    reverse={n:set() for n in graph}
    for src,deps in graph.items():
        for dep in deps: reverse.setdefault(dep,set()).add(src)
    impacted=set(suites); queue=list(suites)
    while queue:
        n=queue.pop(0)
        for dependent in reverse.get(n,()):
            if dependent not in impacted: impacted.add(dependent);queue.append(dependent)
    impacted_files=set(changed)
    for p,n in fmap.items():
        if n in impacted: impacted_files.add(p)
    return {'changed_paths':sorted(changed),'changed_suites':sorted(suites),'impacted_suites':sorted(impacted),'impacted_paths':sorted(impacted_files)}
