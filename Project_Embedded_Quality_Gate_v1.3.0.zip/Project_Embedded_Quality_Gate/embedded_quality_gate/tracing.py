"""Run-level tracing across retrieval, tools, model calls and approval.

Serves: XOBS-01 (structured logs for state transitions), XOBS-05 (run-level
tracing).

Span model and attribute naming follow the OpenTelemetry semantic conventions
as used in microsoft/opentelemetry-distro-python (MIT) — operation names such
as `execute_tool` and `apply_guardrail`, and dotted attribute keys such as
`error.type`. The OTel SDK itself is deliberately not a dependency: the gate is
stdlib-only so it can run offline and air-gapped, so the convention is adopted
and the implementation is local.
"""
from __future__ import annotations

import secrets
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from typing import Any

# --- Operation names (OTel semantic conventions) ---------------------------
OP_INVOKE_AGENT = "invoke_agent"
OP_EXECUTE_TOOL = "execute_tool"
OP_CHAT = "chat"
OP_APPLY_GUARDRAIL = "apply_guardrail"
OP_RETRIEVE_EVIDENCE = "retrieve_evidence"
OP_HUMAN_APPROVAL = "human_approval"

# --- Attribute keys --------------------------------------------------------
ERROR_TYPE_KEY = "error.type"
ERROR_MESSAGE_KEY = "error.message"
RUN_ID_KEY = "eqg.run.id"
PHASE_KEY = "eqg.workflow.state"
DECISION_KEY = "eqg.decision"


@dataclass
class Span:
    """One timed operation within a run."""

    trace_id: str
    span_id: str
    parent_span_id: str | None
    name: str
    start_ns: int
    end_ns: int | None = None
    status: str = "UNSET"
    attributes: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_ms(self) -> float | None:
        if self.end_ns is None:
            return None
        return round((self.end_ns - self.start_ns) / 1_000_000, 3)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["duration_ms"] = self.duration_ms
        return d


class Tracer:
    """Collects spans for one run. Not thread-safe by design: one run, one tracer."""

    def __init__(self, run_id: str, trace_id: str | None = None):
        self.run_id = run_id
        self.trace_id = trace_id or secrets.token_hex(16)
        self.spans: list[Span] = []
        self._stack: list[str] = []

    @contextmanager
    def span(self, name: str, **attributes: Any):
        """Open a span; records OK, or ERROR with the exception type, on exit."""
        sp = Span(
            trace_id=self.trace_id,
            span_id=secrets.token_hex(8),
            parent_span_id=self._stack[-1] if self._stack else None,
            name=name,
            start_ns=time.perf_counter_ns(),
            attributes={RUN_ID_KEY: self.run_id, **attributes},
        )
        self.spans.append(sp)
        self._stack.append(sp.span_id)
        try:
            yield sp
            sp.status = "OK"
        except Exception as exc:
            sp.status = "ERROR"
            sp.attributes[ERROR_TYPE_KEY] = type(exc).__name__
            sp.attributes[ERROR_MESSAGE_KEY] = str(exc)
            raise
        finally:
            sp.end_ns = time.perf_counter_ns()
            self._stack.pop()

    def to_trace(self) -> dict[str, Any]:
        """The full trace for this run, ready to be written as evidence."""
        return {
            "trace_id": self.trace_id,
            "run_id": self.run_id,
            "span_count": len(self.spans),
            "error_count": sum(1 for s in self.spans if s.status == "ERROR"),
            "spans": [s.to_dict() for s in self.spans],
        }
