"""Envelope encryption for data at rest.

Serves: XSEC-04 (encrypt data in transit and at rest).

Architecture is adapted from microsoft/custom-azure-data-encryption (MIT): a
randomly generated data-encryption key (DEK) protects the payload, and the DEK
itself is wrapped by an asymmetric key held behind a provider boundary, so the
wrapped key can travel beside the ciphertext while the unwrapping key does not.

The donor's cipher code is deliberately NOT carried over. It used AES-CBC with
NUL padding stripped by ``rstrip``, which is both lossy and unauthenticated —
ciphertext in an append-only evidence store must not be malleable — and SHA-1
in OAEP/MGF1. This module uses AES-256-GCM (authenticated, with the record's
associated data bound in) and RSA-OAEP/SHA-256 instead, and replaces the
donor's Azure Key Vault dependency with a local key provider.

Fail-closed contract: when no crypto backend is available the provider refuses.
It never writes plaintext under an encryption claim, and it never reports that
data was encrypted when it was not.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .util import sha256_bytes

SCHEMA_VERSION = "eqg.envelope/1.0"
DATA_ALGORITHM = "AES-256-GCM"
KEY_ALGORITHM = "RSA-OAEP-SHA256"
DATA_KEY_BYTES = 32
NONCE_BYTES = 12


class EncryptionUnavailable(RuntimeError):
    """Raised when encryption was requested but no provider can perform it."""


class EncryptionIntegrityError(ValueError):
    """Raised when an envelope fails authentication or does not match its schema."""


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(text.encode("ascii"))


def backend_available() -> bool:
    """True when a real cryptographic backend is importable on this host."""
    try:
        import cryptography  # noqa: F401
    except Exception:
        return False
    return True


@dataclass(frozen=True)
class Envelope:
    """Ciphertext plus everything needed to unwrap it, minus the unwrapping key."""

    schema_version: str
    algorithm: str
    key_algorithm: str
    key_id: str
    wrapped_key: str
    nonce: str
    ciphertext: str
    aad_sha256: str

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Envelope:
        missing = [f for f in Envelope.__dataclass_fields__ if f not in data]
        if missing:
            raise EncryptionIntegrityError(f"envelope missing fields: {', '.join(missing)}")
        if data["schema_version"] != SCHEMA_VERSION:
            raise EncryptionIntegrityError(f"unsupported envelope schema: {data['schema_version']}")
        return Envelope(**{f: data[f] for f in Envelope.__dataclass_fields__})


class KeyProvider:
    """Boundary between the gate and whatever holds the key-wrapping key."""

    key_id = "unconfigured"
    available = False

    def wrap(self, data_key: bytes) -> bytes:
        raise EncryptionUnavailable("no key provider is configured")

    def unwrap(self, wrapped_key: bytes) -> bytes:
        raise EncryptionUnavailable("no key provider is configured")


class NullKeyProvider(KeyProvider):
    """The fail-closed default: refuses rather than pretending.

    Selected when encryption is disabled, no backend is installed, or key
    material is absent. Its refusal is the honest answer, and callers are
    expected to record it as such rather than falling back to plaintext.
    """

    key_id = "none"
    available = False

    def __init__(self, reason: str = "no cryptographic backend available"):
        self.reason = reason

    def wrap(self, data_key: bytes) -> bytes:
        raise EncryptionUnavailable(self.reason)

    def unwrap(self, wrapped_key: bytes) -> bytes:
        raise EncryptionUnavailable(self.reason)


class LocalRsaKeyProvider(KeyProvider):
    """Local reference provider: an on-disk RSA key wraps each data key.

    This stands in for a managed key service. It is deliberately explicit that
    the private key sits on the same host as the ciphertext, which is a real
    limitation and is recorded in KNOWN_LIMITATIONS_NON_GOALS.md — a production
    deployment must substitute a provider whose private key never leaves a
    managed boundary.
    """

    available = True

    def __init__(self, key_path: Path, key_id: str, key_bits: int = 3072, create_if_missing: bool = True):
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        self.key_id = key_id
        self._key_path = Path(key_path)
        if self._key_path.exists():
            self._private_key = serialization.load_pem_private_key(
                self._key_path.read_bytes(), password=None
            )
        elif not create_if_missing:
            self.available = False
            self.reason = f"key material is absent: {self._key_path}"
            self._private_key = None
            return
        else:
            self._private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_bits)
            self._key_path.parent.mkdir(parents=True, exist_ok=True)
            pem = self._private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            self._key_path.write_bytes(pem)
            try:
                os.chmod(self._key_path, 0o600)
            except OSError:
                pass

    def _padding(self):
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding

        return padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        )

    def wrap(self, data_key: bytes) -> bytes:
        return self._private_key.public_key().encrypt(data_key, self._padding())

    def unwrap(self, wrapped_key: bytes) -> bytes:
        return self._private_key.decrypt(wrapped_key, self._padding())


class EnvelopeEncryptor:
    """Encrypts payloads under a fresh data key wrapped by the provider."""

    def __init__(self, provider: KeyProvider):
        self.provider = provider

    @property
    def available(self) -> bool:
        return bool(self.provider.available) and backend_available()

    def encrypt(self, plaintext: bytes, aad: bytes = b"") -> Envelope:
        """Encrypt ``plaintext``, binding ``aad`` into the authentication tag."""
        if not self.available:
            raise EncryptionUnavailable("encryption requested but no provider is available")
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        data_key = secrets.token_bytes(DATA_KEY_BYTES)
        nonce = secrets.token_bytes(NONCE_BYTES)
        ciphertext = AESGCM(data_key).encrypt(nonce, plaintext, aad or None)
        return Envelope(
            schema_version=SCHEMA_VERSION,
            algorithm=DATA_ALGORITHM,
            key_algorithm=KEY_ALGORITHM,
            key_id=self.provider.key_id,
            wrapped_key=_b64(self.provider.wrap(data_key)),
            nonce=_b64(nonce),
            ciphertext=_b64(ciphertext),
            aad_sha256=sha256_bytes(aad),
        )

    def decrypt(self, envelope: Envelope | dict[str, Any], aad: bytes = b"") -> bytes:
        """Decrypt an envelope; raises if the tag or associated data do not match."""
        if isinstance(envelope, dict):
            envelope = Envelope.from_dict(envelope)
        if not self.available:
            raise EncryptionUnavailable("decryption requested but no provider is available")
        if envelope.aad_sha256 != sha256_bytes(aad):
            raise EncryptionIntegrityError("associated data does not match the envelope")
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        data_key = self.provider.unwrap(_unb64(envelope.wrapped_key))
        try:
            return AESGCM(data_key).decrypt(_unb64(envelope.nonce), _unb64(envelope.ciphertext), aad or None)
        except InvalidTag as exc:
            raise EncryptionIntegrityError("envelope failed authentication") from exc


def load_config(root: Path) -> dict[str, Any]:
    """Read quality_gate/config/encryption.json, or an explicit disabled default."""
    path = Path(root) / "quality_gate" / "config" / "encryption.json"
    if not path.exists():
        return {"at_rest": {"enabled": False}, "in_transit": {"enabled": False, "reason": "no encryption config present"}}
    return json.loads(path.read_text(encoding="utf-8"))


def build_encryptor(root: Path, config: dict[str, Any] | None = None, *, create_if_missing: bool = True) -> EnvelopeEncryptor:
    """Build the encryptor described by the config, falling back fail-closed."""
    cfg = config if config is not None else load_config(root)
    at_rest = cfg.get("at_rest", {})
    if not at_rest.get("enabled"):
        return EnvelopeEncryptor(NullKeyProvider("at-rest encryption is disabled by configuration"))
    if not backend_available():
        return EnvelopeEncryptor(NullKeyProvider("the 'crypto' extra is not installed on this host"))
    if at_rest.get("provider") != "local_rsa":
        return EnvelopeEncryptor(NullKeyProvider(f"unsupported provider: {at_rest.get('provider')!r}"))
    key_rel = at_rest.get("key_material_path", ".eqg_runtime/keys/eqg_local_key.pem")
    from .scope import ScopeViolation, confined_path
    try:
        key_path = confined_path(Path(root), key_rel, allow_missing=True)
    except ScopeViolation:
        return EnvelopeEncryptor(NullKeyProvider(f"key material path escapes repository: {key_rel!r}"))
    return EnvelopeEncryptor(LocalRsaKeyProvider(key_path, at_rest.get("key_id", "eqg-local-reference-key"), create_if_missing=create_if_missing))


def crypto_status(root: Path, config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Report what this host can actually claim about XSEC-04.

    Deliberately returns three-valued statuses. ``not_applicable`` is used for
    transit in a mode with no network: that is neither a pass nor a failure, and
    reporting it as either would be a fabricated claim.
    """
    cfg = config if config is not None else load_config(root)
    enc = build_encryptor(root, cfg, create_if_missing=False)
    transit = cfg.get("in_transit", {})
    at_rest_status = "enforced" if enc.available else "unavailable"
    reason = "" if enc.available else getattr(enc.provider, "reason", "no provider")
    return {
        "at_rest": {
            "status": at_rest_status,
            "algorithm": DATA_ALGORITHM if enc.available else None,
            "key_algorithm": KEY_ALGORITHM if enc.available else None,
            "key_id": enc.provider.key_id,
            "reason": reason,
            "encrypt_paths": cfg.get("at_rest", {}).get("encrypt_paths", []),
        },
        "in_transit": {
            "status": "enforced" if transit.get("enabled") else "not_applicable",
            "reason": transit.get("reason", ""),
            "required_for_environments": transit.get("required_for_environments", []),
        },
        "backend_available": backend_available(),
    }
