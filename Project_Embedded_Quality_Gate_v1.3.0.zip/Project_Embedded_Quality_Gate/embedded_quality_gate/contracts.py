from __future__ import annotations

from collections.abc import Iterable
from dataclasses import asdict, dataclass
from typing import Any

from .util import stable_id


class ContractError(ValueError): pass

def require_fields(data: dict[str,Any], fields: Iterable[str]) -> None:
    missing=[f for f in fields if f not in data or data[f] in (None,'')]
    if missing: raise ContractError(f"missing required fields: {', '.join(missing)}")

@dataclass(frozen=True)
class ScopeContract:
    repository_id: str
    revision: str
    allowed_paths: tuple[str,...] = (".",)
    allowed_actions: tuple[str,...] = ("read","analyze")
    source: str = "local_repository"
    schema_version: str = "eqg.scope/1.0"
    def __post_init__(self):
        if not self.repository_id or not self.revision: raise ContractError('repository_id and revision required')
        if not self.allowed_paths: raise ContractError('allowed_paths cannot be empty')
    @property
    def id(self): return stable_id('scope',asdict(self))

@dataclass(frozen=True)
class EvidenceRef:
    evidence_id: str
    kind: str
    source_revision: str
    sha256: str
    location: str
    observed_at: str
    freshness: str = "current"

@dataclass(frozen=True)
class Finding:
    finding_type: str
    severity: str
    confidence: float
    message: str
    evidence_ids: tuple[str,...]
    path: str = ""
    symbol: str = ""
    checked_category: str = "deterministic"
    suppressed: bool = False
    inference: bool = False
    schema_version: str = "eqg.finding/1.0"
    def __post_init__(self):
        if self.severity not in {'info','low','medium','high','critical'}: raise ContractError('invalid severity')
        if not 0 <= self.confidence <= 1: raise ContractError('confidence out of range')
        if not self.evidence_ids: raise ContractError('finding requires evidence')
    @property
    def id(self): return stable_id('finding',asdict(self))

@dataclass(frozen=True)
class Decision:
    decision: str
    reason: str
    evidence_ids: tuple[str,...]
    authority_id: str = ""
    scope_id: str = ""
    schema_version: str = "eqg.decision/1.0"
    def __post_init__(self):
        if self.decision not in {'allow','deny','abstain','review'}: raise ContractError('invalid decision')
        if self.decision != 'deny' and not self.evidence_ids: raise ContractError('non-deny decision requires evidence')
    @property
    def id(self): return stable_id('decision',asdict(self))
