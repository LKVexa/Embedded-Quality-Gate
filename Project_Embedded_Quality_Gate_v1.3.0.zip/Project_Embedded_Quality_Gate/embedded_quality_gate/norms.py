from __future__ import annotations

from collections import Counter
from pathlib import Path


def repository_norms(root:Path):
    ext=Counter();module_prefix=Counter();no_network=0;security_files=0
    for p in root.rglob('*'):
        if not p.is_file() or 'quality_gate' in p.parts or 'embedded_quality_gate' in p.parts: continue
        ext[p.suffix.lower()]+=1
        if p.suffix.lower() in {'.ja','.jaa','.jad','.jasec','.jaops','.jaui','.deepml','.dmk'}:
            try:text=p.read_text(encoding='utf-8')
            except UnicodeDecodeError:continue
            for line in text.splitlines():
                if line.startswith('module '): module_prefix[line.split()[1].split('.')[0]]+=1;break
            if 'policy no_network' in text:no_network+=1
            if p.suffix.lower()=='.jasec':security_files+=1
    return {'extension_counts':dict(ext),'module_prefixes':dict(module_prefix),'no_network_declarations':no_network,'security_source_files':security_files}
