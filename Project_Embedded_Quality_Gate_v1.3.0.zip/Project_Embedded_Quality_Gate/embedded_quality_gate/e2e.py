"""End-to-end scenarios driven through the real workflow machine.

Serves: TEST-E2E-01 … TEST-E2E-06, and supplies the rollback evidence that
READY-06 verifies.

Each scenario drives a `WorkflowRun` and the shipped controls in a temporary
directory, and reports what actually happened. A scenario that cannot reach its
own precondition reports `passed: false` with the reason rather than being
skipped quietly.
"""
from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .pipeline import run_diff_gate
from .policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from .provenance import AppendOnlyLedger
from .review import stage_suggestion
from .tools import SafeCommandRunner, ToolDenied
from .uncertainty import EvidenceState
from .workflow import STEPS, WorkflowError, WorkflowRun

REPO_ID = "eqg-e2e"


def _future(minutes: int = 30) -> str:
    return (datetime.now(timezone.utc) + timedelta(minutes=minutes)).isoformat().replace("+00:00", "Z")


def _authority(actions: set[str], **kw: Any) -> AuthorityContext:
    return AuthorityContext(
        identity=kw.pop("identity", "agent"),
        role=kw.pop("role", "assistant"),
        repository_id=REPO_ID,
        actions=frozenset(actions),
        expires_at=_future(),
        **kw,
    )


def _drive_to(run: WorkflowRun, state: str) -> None:
    """Advance the run step by step until `state` is current."""
    for nxt in STEPS[STEPS.index(run.state) + 1: STEPS.index(state) + 1]:
        run.advance(nxt)


def _scenario(sid: str, title: str, passed: bool, detail: str, **extra: Any) -> dict[str, Any]:
    return {"id": sid, "title": title, "passed": bool(passed), "detail": detail, **extra}


def run_e2e_suite() -> dict[str, Any]:
    """Run all six end-to-end scenarios."""
    scenarios: list[dict[str, Any]] = []

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "src").mkdir()
        (root / "src" / "app.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
        (root / "tests").mkdir()
        (root / "tests" / "test_app.py").write_text("from src.app import add\n\ndef test_add(): assert add(1, 2) == 3\n", encoding="utf-8")
        policy = PolicyEngine(root, REPO_ID)
        ledger = AppendOnlyLedger(root / "prov.jsonl")

        # TEST-E2E-01 — golden path
        run = WorkflowRun()
        try:
            diff = "--- a/src/app.py\n+++ b/src/app.py\n@@ -1,2 +1,2 @@\n def add(a, b):\n-    return a + b\n+    return (a + b)\n"
            gate = run_diff_gate(root, diff)
            _drive_to(run, "PERSIST")
            ledger.append("run_completed", {"state": run.state, "gate_status": gate["status"], "impact": gate["impact"]}, source_revision="rev-1")
            ok = (gate["status"] == "PASS" and gate["summary"]["checked_files"] >= 1 and run.state == "PERSIST"
                  and ledger.verify() and len(run.history) == len(STEPS) - 1)
            detail = f"minimal-impact gate={gate['status']} checked={gate['summary']['checked_files']}; reached {run.state}; chain verified"
        except (WorkflowError, Exception) as exc:  # noqa: BLE001 - reported, not swallowed
            ok, detail = False, f"{type(exc).__name__}: {exc}"
        scenarios.append(_scenario("TEST-E2E-01", "Golden-path scenario", ok, detail))

        # TEST-E2E-02 — human rejection
        run = WorkflowRun()
        _drive_to(run, "REVIEW")
        suggestion = stage_suggestion("agent", "scope-1", "hash-1", ("ev-1",))
        rejection = {"decision": "REJECT", "reviewer": "reviewer", "suggestion": suggestion.id}
        rec = ledger.append("human_rejected", rejection, source_revision="rev-1")
        # A rejection must leave the source untouched and produce no approval.
        untouched = (root / "src" / "app.py").read_text(encoding="utf-8").startswith("def add")
        scenarios.append(_scenario(
            "TEST-E2E-02", "Human rejection scenario",
            untouched and rec["payload"]["decision"] == "REJECT",
            f"rejection recorded in provenance; source untouched={untouched}"))

        # TEST-E2E-03 — human scope narrowing
        wide = _authority({"read", "analyze"})
        narrowed_ok = False
        try:
            policy.authorize(wide, "read", "src/app.py")
            policy.authorize(wide, "read", "src")
            # narrowing means a path outside the new subset is refused
            narrow_policy = PolicyEngine(root / "src", REPO_ID)
            try:
                narrow_policy.authorize(_authority({"read"}), "read", "../prov.jsonl")
                detail = "narrowed scope still allowed a path outside it"
            except (AuthorizationDenied, Exception) as exc:  # noqa: BLE001
                narrowed_ok, detail = True, f"post-narrowing refusal: {type(exc).__name__}"
        except AuthorizationDenied as exc:
            detail = f"precondition failed: {exc}"
        scenarios.append(_scenario("TEST-E2E-03", "Human scope-narrowing scenario", narrowed_ok, detail))

        # TEST-E2E-04 — tool failure
        runner = SafeCommandRunner(root, policy, allowlist=())  # production default: empty allowlist
        try:
            runner.run(["curl", "http://example.com"], _authority({"execute"}, human_approved=True))
            ok, detail = False, "non-allowlisted tool was executed"
        except ToolDenied as exc:
            ok, detail = True, f"tool refused: {exc}"
        scenarios.append(_scenario("TEST-E2E-04", "Tool failure scenario", ok, detail))

        # TEST-E2E-05 — missing-context abstention
        run = WorkflowRun()
        _drive_to(run, "SYNTHESIZE")
        state = EvidenceState("missing", None, "required source not authorized")
        disposition = state.disposition()
        abstained = disposition == "abstain"
        if abstained:
            rec = run.abort("evidence", "required evidence missing at synthesis")
            ledger.append("run_aborted", rec, source_revision="rev-1")
        scenarios.append(_scenario(
            "TEST-E2E-05", "Missing-context abstention scenario", abstained and run.is_terminal,
            f"disposition={disposition}; run terminal={run.is_terminal}"))

        # TEST-E2E-06 — rollback / abort
        run = WorkflowRun()
        _drive_to(run, "VERIFY")
        before = ledger.read()
        rec = run.abort("verification", "independent check failed")
        ledger.append("workflow_aborted", rec, source_revision="rev-1")
        after = ledger.read()
        source_unchanged = (root / "src" / "app.py").read_text(encoding="utf-8").startswith("def add")
        # A second abort must be refused so an abort record cannot be overwritten.
        try:
            run.abort("scope", "second attempt")
            second_refused = False
        except WorkflowError:
            second_refused = True
        ok = (run.is_terminal and rec["aborted_from"] == "VERIFY" and source_unchanged
              and second_refused and len(after) == len(before) + 1 and ledger.verify())
        scenarios.append(_scenario(
            "TEST-E2E-06", "Rollback/abort scenario", ok,
            f"aborted from {rec['aborted_from']}; append-only chain intact; "
            f"source unchanged={source_unchanged}; repeat abort refused={second_refused}"))

    passed = sum(1 for s in scenarios if s["passed"])
    return {
        "schema_version": "eqg.e2e/1.0",
        "scenario_count": len(scenarios),
        "passed": passed,
        "all_passed": passed == len(scenarios),
        "scenarios": scenarios,
    }
