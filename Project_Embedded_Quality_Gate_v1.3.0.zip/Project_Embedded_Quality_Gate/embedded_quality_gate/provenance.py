from __future__ import annotations

import json
import os
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .crypto import Envelope, build_encryptor
from .secure_storage import requires_encryption
from .util import canonical_json, sha256_bytes, utc_now


class LedgerError(RuntimeError): pass

class AppendOnlyLedger:
    """Hash-chained append-only ledger with cross-process append serialization.

    When the ledger is placed under an encryption-protected repository path,
    each line is envelope-encrypted independently and bound to its path/index.
    Scratch ledgers outside a configured repository remain plaintext for tests.
    """
    STORAGE_SCHEMA='eqg.secure-jsonl/1.0'
    def __init__(self,path:Path,root:Path|None=None):
        self.path=Path(path); self.root=Path(root).resolve() if root else self._infer_root(self.path)
    @staticmethod
    def _infer_root(path:Path):
        p=path.resolve(strict=False); parts=p.parts
        for i in range(len(parts)-1):
            if parts[i]=='quality_gate' and parts[i+1]=='evidence':
                return Path(*parts[:i]) if i else Path(p.anchor)
        return None
    @contextmanager
    def _locked(self):
        lock=self.path.with_name(self.path.name+'.lock'); lock.parent.mkdir(parents=True,exist_ok=True)
        f=lock.open('a+b')
        try:
            if os.name=='nt':
                import msvcrt
                f.seek(0,os.SEEK_END)
                if f.tell()==0: f.write(b'0'); f.flush()
                f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_LOCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX)
            yield
        finally:
            try:
                if os.name=='nt':
                    import msvcrt
                    f.seek(0)
                    msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(f.fileno(),fcntl.LOCK_UN)
            finally: f.close()
    def _protected(self):
        return self.root is not None and requires_encryption(self.root,self.path)
    def _aad(self,index:int):
        # A real check, not an assert: associated data binds the ciphertext to its
        # path, and `python -O` strips asserts.
        if self.root is None: raise ValueError('associated data requires a repository root')
        rel=self.path.resolve(strict=False).relative_to(self.root).as_posix()
        return f'{rel}#{index}'.encode()
    def _encode(self,rec:dict,index:int):
        if not self._protected(): return canonical_json(rec)
        enc=build_encryptor(self.root,create_if_missing=True)
        if not enc.available: raise LedgerError('protected provenance ledger cannot be written: encryption unavailable')
        env=enc.encrypt(canonical_json(rec).encode('utf-8'),aad=self._aad(index))
        return canonical_json({'storage_schema':self.STORAGE_SCHEMA,'index':index,'envelope':asdict(env)})
    def _decode(self,line:str,index:int):
        try: raw=json.loads(line)
        except json.JSONDecodeError as e: raise LedgerError(f'invalid ledger JSON at line {index+1}') from e
        if isinstance(raw,dict) and raw.get('storage_schema')==self.STORAGE_SCHEMA:
            if self.root is None or raw.get('index')!=index: raise LedgerError(f'encrypted ledger index/path binding mismatch at line {index+1}')
            try:
                pt=build_encryptor(self.root,create_if_missing=False).decrypt(Envelope.from_dict(raw['envelope']),aad=self._aad(index))
                return json.loads(pt.decode('utf-8'))
            except Exception as exc: raise LedgerError(f'encrypted ledger integrity failure at line {index+1}') from exc
        if self._protected(): raise LedgerError(f'protected provenance ledger contains plaintext at line {index+1}')
        return raw
    def read(self):
        if not self.path.exists(): return []
        out=[]
        for index,line in enumerate(self.path.read_text(encoding='utf-8').splitlines()):
            if line.strip(): out.append(self._decode(line,index))
        return out
    @staticmethod
    def _verify_rows(rows):
        prev='0'*64
        for i,rec in enumerate(rows):
            if rec.get('previous_hash')!=prev: raise LedgerError(f'broken previous hash at record {i}')
            body={k:v for k,v in rec.items() if k!='record_hash'}
            expected=sha256_bytes(canonical_json(body).encode('utf-8'))
            if rec.get('record_hash')!=expected: raise LedgerError(f'bad record hash at record {i}')
            prev=expected
        return True
    def verify(self): return self._verify_rows(self.read())
    def append(self,event_type:str,payload:dict[str,Any],*,source_revision:str,authority_id:str=''):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with self._locked():
            rows=self.read(); self._verify_rows(rows); prev=rows[-1]['record_hash'] if rows else '0'*64
            body={'event_type':event_type,'timestamp':utc_now(),'source_revision':source_revision,
                  'authority_id':authority_id,'payload':payload,'previous_hash':prev}
            rec=dict(body); rec['record_hash']=sha256_bytes(canonical_json(body).encode('utf-8'))
            encoded=self._encode(rec,len(rows))
            with self.path.open('a',encoding='utf-8',newline='\n') as f:
                f.write(encoded+'\n'); f.flush(); os.fsync(f.fileno())
            return rec
