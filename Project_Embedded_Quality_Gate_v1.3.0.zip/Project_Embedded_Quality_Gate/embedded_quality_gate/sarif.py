"""SARIF 2.1.0 output for gate findings.

Serves: IMPL-06 (machine-consumable findings), DEPLOY-02 (CI can publish gate
results to code scanning rather than only to a job log).

Record shape adopted from the GitHub Junkyard donor ``sarif-js-sdk``
(``packages/eslint-formatter-sarif/sarif.js``, MIT, Microsoft Corporation). No
donor code is copied: that formatter is JavaScript and pulls ``lodash``,
``utf8`` and ``jschardet``, and this package is deliberately stdlib-only so it
can run offline and air-gapped. What transfers is the log structure — the
version/schema header, ``runs[].tool.driver`` with its rule table, and
``results[]`` carrying ``ruleId``, ``level``, ``message.text`` and a physical
location — plus the donor's severity-to-level mapping.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

SARIF_VERSION = "2.1.0"
SARIF_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"
TOOL_NAME = "embedded-quality-gate"
TOOL_URI = "https://github.com/davidpaulrussell/embedded-quality-gate"

#: Gate severity → SARIF level. ``critical``/``high`` are the release-blocking
#: severities, so they are the ones that must surface as ``error``.
LEVEL_BY_SEVERITY = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note",
    "info": "note",
}


def _rule(finding_type: str) -> dict[str, Any]:
    return {
        "id": finding_type,
        "name": finding_type,
        "shortDescription": {"text": f"{finding_type} finding reported by the embedded quality gate"},
        "defaultConfiguration": {"level": "warning"},
    }


def _location(finding: dict[str, Any]) -> list[dict[str, Any]]:
    path = finding.get("path") or ""
    if not path:
        return []
    physical: dict[str, Any] = {"artifactLocation": {"uri": path, "uriBaseId": "%SRCROOT%"}}
    symbol = str(finding.get("symbol") or "")
    if symbol.startswith("line:"):
        try:
            line = int(symbol.split(":", 1)[1])
        except (ValueError, IndexError):
            line = 0
        if line > 0:
            physical["region"] = {"startLine": line}
    return [{"physicalLocation": physical}]


def build_sarif_log(findings: list[dict[str, Any]], *, version: str, revision: str = "") -> dict[str, Any]:
    """Build a SARIF log from ``summarize()``-shaped finding dictionaries."""
    rule_ids = sorted({str(f.get("type") or "quality") for f in findings})
    results = []
    for finding in findings:
        rule_id = str(finding.get("type") or "quality")
        result: dict[str, Any] = {
            "ruleId": rule_id,
            "level": LEVEL_BY_SEVERITY.get(str(finding.get("severity")), "warning"),
            "message": {"text": str(finding.get("message") or "")},
        }
        locations = _location(finding)
        if locations:
            result["locations"] = locations
        # Gate provenance travels with the result so a code-scanning alert can
        # be traced back to the exact evidence records that produced it.
        properties = {k: finding[k] for k in ("id", "confidence", "inference", "evidence_ids") if k in finding}
        if properties:
            result["properties"] = properties
        results.append(result)
    run: dict[str, Any] = {
        "tool": {
            "driver": {
                "name": TOOL_NAME,
                "version": version,
                "informationUri": TOOL_URI,
                "rules": [_rule(r) for r in rule_ids],
            }
        },
        "results": results,
    }
    if revision:
        run["versionControlProvenance"] = [{"repositoryUri": "", "revisionId": revision}]
    return {"version": SARIF_VERSION, "$schema": SARIF_SCHEMA, "runs": [run]}


def write_sarif(path: Path | str, findings: list[dict[str, Any]], *, version: str, revision: str = "") -> Path:
    """Write a SARIF log and return the path written."""
    out = Path(path)
    if out.parent != Path(""):
        out.parent.mkdir(parents=True, exist_ok=True)
    log = build_sarif_log(findings, version=version, revision=revision)
    out.write_text(json.dumps(log, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    return out
