"""Deterministic detection of instructions embedded in repository content.

Serves: TEST-ADV-01 (malicious repository/document instructions), VERIFY-01
(every finding maps to exact changed lines), XEVAL-03 (grounding correctness).

Repository content is *data*. Text inside a file that addresses the model and
tells it what to emit is an indirect prompt injection, and the gate must treat
it as a finding rather than as an instruction. Detection is deterministic and
explainable: every hit names the signal that fired and the exact line, so a
reviewer can check the call rather than trust a score.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass

#: (id, weight, description, pattern). Weights are summed per line; a line at or
#: above THRESHOLD is reported. Weights are ordinal, not probabilities, and are
#: never presented as confidence.
SIGNALS: tuple[tuple[str, int, str, re.Pattern], ...] = (
    ("INJ-OVERRIDE", 3, "attempts to override prior instructions",
     re.compile(r"\b(ignore|disregard|forget)\b[^.\n]{0,40}\b(previous|prior|above|earlier|all)\b[^.\n]{0,20}\b(instruction|prompt|rule|direction)s?\b", re.I)),
    # Deliberately weight 2, not 3: a demonstrative reference to a code artifact
    # ("the following snippet") is ordinary technical prose on its own, and
    # firing on it alone would flag every README. It becomes a finding when it
    # combines with content that addresses the model or exfiltrates.
    ("INJ-EMIT-CODE", 2, "refers to a specific code artifact for the reader to place",
     re.compile(r"\b(the\s+)?(following|below|subsequent|next|this|these)\b[^.\n]{0,50}\b(code|snippet|block|excerpt|segment|script|line)s?\b", re.I)),
    ("INJ-ADDRESSES-MODEL", 2, "addresses the assistant directly inside content",
     re.compile(r"\b(you are (an? )?(ai|assistant|model|language model)|as an ai\b|"
                r"(in|into|to)\s+your\s+(response|answer|output|reply)|"
                r"your\s+(code\s+)?(response|implementation|algorithm|answer|output|solution|script|program|reply))\b", re.I)),
    ("INJ-EXFIL-NET", 3, "network exfiltration of local data",
     re.compile(r"requests\.(post|put)\s*\(|urllib\.request\.urlopen\s*\(|socket\.socket\s*\(", re.I)),
    # A network fetch is not suspicious by itself, but in combination with an
    # instruction to copy/emit code it is a common payload shape.  Weight 2
    # keeps ordinary client code benign while closing corpus misses that used
    # GET rather than POST/PUT. v1.3.0 also covers urllib.Request, aiohttp,
    # and http.client so a GET-shaped payload cannot hide behind a different
    # client library.
    ("INJ-NETWORK-ACTION", 2, "payload performs an outbound network request",
     re.compile(r"requests\.(get|head|patch|delete)\s*\(|httpx\.(get|post|put|patch|delete)\s*\(|"
                r"urllib\.request\.(urlretrieve|Request)\s*\(|aiohttp\.(ClientSession|request|get)\s*\(|"
                r"http\.client\.HTTPS?Connection\s*\(", re.I)),
    # Likewise an unbounded loop is legitimate in servers/event loops, so it
    # only contributes to a document-level finding when paired with a directive
    # or another suspicious signal. `while 1` is the same shape as `while True`.
    ("INJ-UNBOUNDED-LOOP", 2, "payload contains an unbounded loop",
     re.compile(r"\bwhile\s+(True|1)\s*:", re.I)),
    ("INJ-EXFIL-READ", 2, "reads local credentials, environment, or user identity",
     re.compile(r"\bgetpass\.getuser\b|\bos\.environ\b|open\s*\(\s*['\"][^'\"]*(passwd|password|secret|credential|\.ssh|id_rsa)", re.I)),
    # Weight 2 on purpose: real repositories legitimately call os.system or
    # touch system paths, so this must not fire alone. It fires in combination
    # with a directive to insert the code — which is the actual attack shape,
    # and is what separates a payload from a project's own source.
    ("INJ-DANGEROUS-PAYLOAD", 2, "payload performs a system-altering or unsafe local operation",
     re.compile(r"os\.system\s*\(|subprocess\.(run|Popen|call|check_output)\s*\(|"
                r"pickle\.loads\s*\(|authorized_keys|/etc/(hosts|passwd|shadow)|"
                r"[~/\\.]ssh[/\\]|Fernet\s*\(|shutil\.rmtree\s*\(|"
                r"Win32_NetworkAdapterConfiguration|ipconfig\s*/release|netsh\s+|chmod\s+777", re.I)),
    ("INJ-DYNAMIC-EXEC", 3, "dynamic execution of decoded content",
     re.compile(r"\b(eval|exec)\s*\(\s*(base64|codecs|bytes\.fromhex|__import__)", re.I)),
    ("INJ-SECRET-DISCLOSE", 3, "asks for secret or configuration disclosure",
     re.compile(r"\b(reveal|disclose|print|output|show)\b[^.\n]{0,40}\b(password|secret|api[ _-]?key|token|credential|system prompt|metaprompt)s?\b", re.I)),
)

#: A single line at or above this score is a finding on its own.
LINE_THRESHOLD = 3

#: A document is a finding when distinct signals combine to at least this
#: weight. Injection is a document-level property: an instruction line that
#: addresses the model and a separate code block that exfiltrates are two
#: halves of one attack, and neither half alone should have to carry it.
DOC_THRESHOLD = 4

#: ...but never on one signal alone, or ordinary prose that merely says
#: "the following code" would qualify.
DOC_MIN_DISTINCT_SIGNALS = 2

THRESHOLD = LINE_THRESHOLD  # retained for callers of the previous API


@dataclass(frozen=True)
class ContentFinding:
    """One detection, anchored to an exact line so a human can verify it."""

    path: str
    line: int
    score: int
    signals: tuple[str, ...]
    excerpt: str

    def to_dict(self) -> dict:
        return asdict(self)


def scan_text(text: str, path: str = "<memory>", max_excerpt: int = 160) -> list[ContentFinding]:
    """Scan `text` line by line and return every line at or above THRESHOLD."""
    findings: list[ContentFinding] = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        score = 0
        hits: list[str] = []
        for sig_id, weight, _desc, pattern in SIGNALS:
            if pattern.search(line):
                score += weight
                hits.append(sig_id)
        if score >= LINE_THRESHOLD:
            findings.append(ContentFinding(path, lineno, score, tuple(hits), line.strip()[:max_excerpt]))
    return findings


def scan_document(text: str, path: str = "<memory>") -> dict:
    """Scan a whole document, at line level and as a combination.

    A document is flagged when any single line crosses `LINE_THRESHOLD`, or
    when at least `DOC_MIN_DISTINCT_SIGNALS` different signals appear anywhere
    in it and their combined weight reaches `DOC_THRESHOLD`. The second rule is
    what catches the common shape of an indirect injection, where the directive
    and the payload sit on different lines.
    """
    findings = scan_text(text, path)
    weights = {sig_id: weight for sig_id, weight, _d, _p in SIGNALS}
    doc_signals = sorted({
        sig_id
        for line in text.splitlines()
        for sig_id, _w, _d, pattern in SIGNALS
        if line.strip() and pattern.search(line)
    })
    doc_score = sum(weights[s] for s in doc_signals)
    line_flag = bool(findings)
    combo_flag = len(doc_signals) >= DOC_MIN_DISTINCT_SIGNALS and doc_score >= DOC_THRESHOLD
    return {
        "path": path,
        "flagged": line_flag or combo_flag,
        "reason": "line" if line_flag else ("combination" if combo_flag else "none"),
        "max_score": max((f.score for f in findings), default=0),
        "document_score": doc_score,
        "signals": doc_signals,
        "findings": [f.to_dict() for f in findings],
    }


def signal_catalogue() -> list[dict]:
    """The catalogue a reviewer reads to understand why something fired."""
    return [{"id": i, "weight": w, "description": d} for i, w, d, _ in SIGNALS]
