from __future__ import annotations

from dataclasses import dataclass

from .contracts import ContractError


class ModelUnavailable(RuntimeError): pass

@dataclass(frozen=True)
class ModelConfig:
    provider:str='none'; model:str='none'; prompt_version:str='eqg-model-prompt/1.0'; context_policy:str='authorized-evidence-only/1.0'

class NoModelProvider:
    def synthesize(self,context):
        return {'status':'abstain','reason':'No model provider configured; deterministic findings remain authoritative.','findings':[],'questions':['Configure an authorized model provider only if probabilistic synthesis is required.']}

class DeterministicFixtureProvider:
    """Test-only provider. It cannot claim external facts and must cite supplied evidence."""
    def synthesize(self,context):
        evid=[e['evidence_id'] for e in context.get('evidence',[]) if 'evidence_id' in e]
        if not evid: return {'status':'abstain','reason':'No authorized evidence','findings':[],'questions':['Provide evidence.']}
        return {'status':'ok','reason':'Synthetic deterministic fixture output','findings':[{'message':'fixture synthesis','evidence_ids':[evid[0]],'confidence':0.5,'inference':True}], 'questions':[]}

def build_context(scope_id, evidence, deterministic_findings, max_evidence=100, allow_secret=False):
    authorized=[]
    for e in evidence:
        classification=str(e.get('classification','repository')).lower()
        if classification=='secret' and not allow_secret: continue
        if e.get('authorized',True) is not True: continue
        authorized.append(e)
        if len(authorized)>=max_evidence: break
    return {'scope_id':scope_id,'evidence':authorized,
            'deterministic_findings':[{'id':f.id,'evidence_ids':list(f.evidence_ids),'message':f.message} for f in deterministic_findings]}

def validate_output(output, authorized_evidence_ids):
    forbidden={'approval','approved','approval_token','authority','permission_grant','deploy'}
    if forbidden.intersection(output): raise ContractError('model output contains prohibited authority/approval field')
    if output.get('status') not in {'ok','abstain','review'}: raise ContractError('invalid model status')
    allowed=set(authorized_evidence_ids)
    for finding in output.get('findings',[]):
        refs=finding.get('evidence_ids') or []
        if not refs: raise ContractError('model finding missing evidence')
        if any(r not in allowed for r in refs): raise ContractError('model output cites unauthorized evidence')
        if 'confidence' not in finding: raise ContractError('model finding missing confidence')
        if not finding.get('inference',False): raise ContractError('model-derived finding must be labeled inference')
    return True
