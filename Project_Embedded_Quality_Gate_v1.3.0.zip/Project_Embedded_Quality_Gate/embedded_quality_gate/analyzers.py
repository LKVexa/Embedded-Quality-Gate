from __future__ import annotations

import ast
import json
import re
from collections.abc import Iterable
from pathlib import Path

from .contracts import Finding
from .util import sha256_bytes, sha256_file, stable_id

DSL_EXT={'.ja','.jaa','.jad','.jasec','.jaops','.jaui','.jasp','.jate','.deepml','.dmk','.ebnf'}
CODE_EXT=DSL_EXT|{'.py','.json'}
SECRET_EXT=CODE_EXT|{'.yml','.yaml','.toml','.ini','.cfg','.env'}
SECRET_PATTERNS=[
    ('private_key',re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')),
    ('aws_access_key',re.compile(r'AKIA[0-9A-Z]{16}')),
]
SKIP_PARTS={'.git','.eqg_runtime','__pycache__','evidence','node_modules','.venv'}

def _evidence_id(path:Path,root:Path):
    return stable_id('evidence',{'path':path.relative_to(root).as_posix(),'sha256':sha256_file(path)})

def _structural_text(text:str):
    text=re.sub(r'\(\*.*?\*\)', '', text, flags=re.S)
    text=re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    return text

def brace_balance(text:str):
    depth=0
    for ch in _structural_text(text):
        if ch=='{': depth+=1
        elif ch=='}':
            depth-=1
            if depth<0: return False
    return depth==0

def _candidate_files(root: Path, include_paths: Iterable[str] | None):
    if include_paths is None:
        yield from sorted(root.rglob('*'))
        return
    seen=set()
    for raw in include_paths:
        p=(root/raw).resolve(strict=False)
        try: p.relative_to(root.resolve())
        except ValueError: continue
        if p.is_file() and p not in seen:
            seen.add(p); yield p
        elif p.is_dir():
            for q in sorted(p.rglob('*')):
                if q.is_file() and q not in seen:
                    seen.add(q); yield q

def analyze_repository(root:Path, include_paths: Iterable[str] | None=None):
    """Run deterministic syntax/structure/secret checks over supported code.

    ``include_paths`` enables the save/stage/pre-PR path to analyze only the
    minimal impacted set instead of silently rescanning the entire repository.
    YAML/TOML/ENV files are secret-scanned even though they are not syntax-checked
    as Python/JSON (no YAML parser is bundled).
    """
    root=root.resolve(); findings=[]; checked=0
    for p in _candidate_files(root,include_paths):
        if not p.is_file() or any(part in SKIP_PARTS for part in p.parts): continue
        ext=p.suffix.lower()
        if ext not in SECRET_EXT: continue
        try: text=p.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            if ext in CODE_EXT:
                findings.append(Finding('encoding','high',1.0,'Source file is not UTF-8',(_evidence_id(p,root),),p.relative_to(root).as_posix()))
            continue
        evid=_evidence_id(p,root); rel=p.relative_to(root).as_posix()
        if ext in CODE_EXT:
            checked+=1
            if ext=='.py':
                try: ast.parse(text,filename=rel)
                except SyntaxError as exc:
                    findings.append(Finding('syntax','high',1.0,f'Python syntax error: {exc.msg}',(evid,),rel,f'line:{exc.lineno or 0}'))
            elif ext=='.json':
                try: json.loads(text)
                except json.JSONDecodeError as ext_err:
                    findings.append(Finding('syntax','high',1.0,f'JSON syntax error: {ext_err.msg}',(evid,),rel,f'line:{ext_err.lineno}'))
            else:
                if not brace_balance(text): findings.append(Finding('syntax','high',1.0,'Unbalanced braces',(evid,),rel))
                has_identity=bool(re.search(r'(?m)^\s*module\s+[A-Za-z0-9_.-]+',text))
                if ext=='.jasp':
                    has_identity=has_identity or bool(re.search(r'(?m)^\s*subsuite\s+[A-Za-z0-9_.-]+\s+[A-Za-z0-9_.-]+\s*\{',text))
                if not has_identity: findings.append(Finding('structure','medium',1.0,'Missing module/subsuite identity declaration',(evid,),rel))
        for kind,pat in SECRET_PATTERNS:
            if pat.search(text): findings.append(Finding('secret','critical',1.0,f'Possible {kind} material in repository',(evid,),rel))
    drift={'manifests_scanned':0,'unresolved_entries':0,'mismatched_entries':0}
    if include_paths is None:
        result=check_manifest_drift(root)
        findings.extend(result.pop('findings')); drift=result
    return {'checked_files':checked,'findings':findings,'manifest_drift':drift}

#: Provenance manifests a repository may carry beside its content. They are read
#: only: the drift check never rewrites one, because in this repository they are
#: part of the protected corpus.
MANIFEST_NAMES=('SHA256SUMS.txt','SHA256SUMS','CHECKSUMS.sha256','MANIFEST.json')
_SUMS_LINE=re.compile(r'^([0-9a-fA-F]{64})\s+\*?(.+)$')

def _declared_from_sums(text:str):
    for raw in text.splitlines():
        line=raw.strip()
        if not line or line.startswith('#'): continue
        m=_SUMS_LINE.match(line)
        if m: yield m.group(2).strip(), m.group(1).lower()

def _declared_from_manifest(data):
    """Pull path->sha256 pairs out of a JSON manifest without assuming one schema.

    Recognises the three shapes this corpus actually uses — a ``scripts`` map of
    name -> {sha256}, a ``files`` map of path -> sha256, and a ``scripts`` list of
    entries each carrying its own ``file``/``path``/``name`` and ``sha256`` — and
    ignores anything else rather than guessing.
    """
    if not isinstance(data,dict): return
    for key in ('scripts','files','artifacts'):
        block=data.get(key)
        if isinstance(block,dict):
            for name,value in block.items():
                if isinstance(value,str) and len(value)==64: yield name,value.lower()
                elif isinstance(value,dict) and isinstance(value.get('sha256'),str): yield name,value['sha256'].lower()
        elif isinstance(block,list):
            # A list of entries, each naming its own path: the shape Observer's
            # manifest uses. Skipping it silently would leave a manifest
            # unchecked, which is the exact failure this check exists to catch.
            for entry in block:
                if not isinstance(entry,dict): continue
                name=entry.get('file') or entry.get('path') or entry.get('name')
                digest=entry.get('sha256')
                if isinstance(name,str) and isinstance(digest,str) and len(digest)==64:
                    yield name,digest.lower()

def check_manifest_drift(root:Path, exclude:Iterable[str]=()):
    """Report provenance manifests that no longer describe what is on disk.

    Serves: PROV-*, the standing requirement that evidence must not point at a
    stale target. A manifest listing files that were renamed or migrated away is
    exactly that: provenance that reads as verified and is not.

    Read-only by construction — every file is opened for reading and none is
    written — because in this repository the manifests are corpus files and the
    corpus is immutable.
    """
    root=root.resolve(); findings=[]; scanned=0; unresolved=0; mismatched=0
    excluded={e.rstrip('/') for e in exclude}
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.name not in MANIFEST_NAMES: continue
        if any(part in SKIP_PARTS for part in p.parts): continue
        rel=p.relative_to(root).as_posix()
        if any(rel==e or rel.startswith(e+'/') for e in excluded): continue
        try: text=p.read_text(encoding='utf-8')
        except (OSError,UnicodeDecodeError): continue
        if p.name=='MANIFEST.json':
            try: declared=list(_declared_from_manifest(json.loads(text)))
            except json.JSONDecodeError: continue
        else:
            declared=list(_declared_from_sums(text))
        if not declared: continue
        scanned+=1
        evid=_evidence_id(p,root)
        missing_here=[]; changed_here=[]
        for name,digest in declared:
            target=(p.parent/name)
            if not target.is_file():
                missing_here.append(name); continue
            if sha256_file(target).lower()!=digest: changed_here.append(name)
        unresolved+=len(missing_here); mismatched+=len(changed_here)
        if missing_here:
            findings.append(Finding('provenance','low',1.0,
                f'Manifest declares {len(missing_here)} of {len(declared)} path(s) that do not exist on disk '
                f'(first: {missing_here[0]}); the manifest describes an earlier layout and cannot verify this tree',
                (evid,),rel))
        if changed_here:
            findings.append(Finding('provenance','medium',1.0,
                f'Manifest digest mismatch on {len(changed_here)} path(s) (first: {changed_here[0]})',
                (evid,),rel))
    return {'manifests_scanned':scanned,'unresolved_entries':unresolved,'mismatched_entries':mismatched,'findings':findings}

def analyze_text(text: str, rel: str) -> list[Finding]:
    """Deterministic checks on reconstructed or in-memory source."""
    findings: list[Finding] = []
    evid = stable_id('evidence', {'path': rel, 'sha256': sha256_bytes(text.encode('utf-8', errors='replace'))})
    ext = Path(rel).suffix.lower()
    if ext == '.py':
        try:
            ast.parse(text, filename=rel)
        except SyntaxError as exc:
            findings.append(Finding('syntax', 'high', 1.0, f'Python syntax error: {exc.msg}', (evid,), rel, f'line:{exc.lineno or 0}'))
    elif ext == '.json':
        try:
            json.loads(text)
        except json.JSONDecodeError as exc:
            findings.append(Finding('syntax', 'high', 1.0, f'JSON syntax error: {exc.msg}', (evid,), rel, f'line:{exc.lineno}'))
    elif ext in DSL_EXT:
        if not brace_balance(text):
            findings.append(Finding('syntax', 'high', 1.0, 'Unbalanced braces', (evid,), rel))
    return findings

def validate_dmk_references(root:Path):
    missing=[]; refs=[]
    for p in root.rglob('*.jad'):
        if any(part in SKIP_PARTS for part in p.parts): continue
        text=p.read_text(encoding='utf-8')
        for name in re.findall(r'from\s+dmk\("([^"]+)"\)',text):
            refs.append((p,name))
            q=(p.parent/name).resolve()
            try: q.relative_to(root.resolve())
            except ValueError: missing.append({'source':p.relative_to(root).as_posix(),'ref':name,'reason':'scope_escape'}); continue
            if not q.exists(): missing.append({'source':p.relative_to(root).as_posix(),'ref':name,'reason':'missing'})
    return {'references':len(refs),'missing':missing}
