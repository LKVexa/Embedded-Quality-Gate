"""Structured, redacted event logging and counters.

Serves: XOBS-01 (structured logs for workflow state transitions), XSEC (log
redaction).

`redact` previously matched six exact key names and never inspected values, so
a credential pasted into a message body was written to the log verbatim. It now
delegates to the vendored redaction library, which masks by value as well as by
key while leaving hash-chain join keys byte-identical (see redaction_policy).
"""
from __future__ import annotations

import json
from pathlib import Path

from .redaction_policy import eqg_redactor, scrub_record
from .util import atomic_write_json, utc_now

_REDACTOR = eqg_redactor()


def redact(value):
    """Mask secrets and PII in an arbitrary JSON-like structure.

    Applies both rules: credential-named keys are masked regardless of their
    value, and the vendored masker then catches credential- and PII-shaped
    values wherever they appear.
    """
    return scrub_record(value, _REDACTOR)


class EventLog:
    """Append-only JSONL event log with a counter sidecar."""

    def __init__(self, path: Path, metrics_path: Path | None = None):
        self.path = path
        self.metrics_path = metrics_path

    def emit(self, event, fields):
        """Write one redacted event; returns the record as written."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        rec = {"at": utc_now(), "event": event, "fields": redact(fields)}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
        if self.metrics_path:
            metrics = {}
            if self.metrics_path.exists():
                metrics = json.loads(self.metrics_path.read_text(encoding="utf-8"))
            metrics[event] = metrics.get(event, 0) + 1
            atomic_write_json(self.metrics_path, metrics)
        return rec
