"""Self-verifying release-readiness and delivery-precondition gates.

PASS is reserved for claims the repository can verify from revision-bound
artifacts. Missing evidence is never promoted from caller-supplied booleans.
"""
from __future__ import annotations

import ast
import csv
import hmac
import json
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

from .repository import invalidate_revision_cache, repo_revision
from .secure_storage import canonical_payload_hash, read_json
from .util import sha256_file

# noqa reason: these are gate status constants, not credentials.
PASS='PASS'  # noqa: S105
BLOCKED='BLOCKED'
INDETERMINATE='INDETERMINATE'

WRITE_AUTHORIZED_MODULES=frozenset({
    'state.py','provenance.py','observability.py','util.py','backup.py','retention.py',
    'crypto.py','secure_storage.py','cli.py',
    # sarif.py writes exactly one artifact, at a path the operator passes to
    # `analyze --sarif`, and only when that flag is given. Declaring it here is
    # the mechanism this gate provides for a module whose job includes writing;
    # what it forbids is *undeclared* write authority.
    'sarif.py',
})
SCRATCH_ONLY_MODULES=frozenset({'adversarial.py','e2e.py'})
VENDORED_MODULES=frozenset({'redaction.py'})
_WRITE_ATTRS=frozenset({'write_text','write_bytes','mkdir','unlink','rmdir','rmtree','copy2','copyfile','copytree','touch','makedirs','fsync','mkstemp'})
_WRITE_MODES=('w','a','x','+')

@dataclass(frozen=True)
class GateResult:
    name:str; status:str; reason:str; evidence:tuple[str,...]=()


PLACEHOLDER_FRAGMENTS = (
    'YYYY-MM-DD', 'REPLACE_WITH', 'NAMED_HUMAN', 'CURRENT_REPOSITORY',
    'PASS_OR_BLOCKED', 'DESCRIBE_ENVIRONMENT', 'REQUIRED WHEN',
    'NAMED_HUMAN_OR_TRUSTED', 'RUN: PYTHON',
)
MODEL_REVIEWER_NAMES = {
    'grok', 'chatgpt', 'claude', 'gpt', 'gpt-4', 'gpt-5', 'assistant',
    'model', 'llm', 'copilot', 'gemini', 'cursor', 'the model', 'eqg',
    'embedded quality gate', 'ai', 'bot', 'anthropic', 'openai',
}
ALLOWED_REVIEWER_ROLES = {'security_privacy_reviewer', 'human_reviewer', 'release_authority'}
REVIEW_DOCUMENTS = (
    'quality_gate/docs/THREAT_MODEL.md',
    'quality_gate/docs/DATA_FLOW_TRUST_BOUNDARIES.md',
    'quality_gate/docs/KNOWN_LIMITATIONS_NON_GOALS.md',
    'quality_gate/docs/ENCRYPTION_KEY_MANAGEMENT.md',
    'quality_gate/docs/DATA_GOVERNANCE.md',
)
QUALIFICATION_ENVIRONMENTS = {
    'DEPLOY-02': 'ci',
    'DEPLOY-03': 'staging',
    'DEPLOY-04': 'production_readonly',
    'DEPLOY-05': 'privileged_path',
    'DEPLOY-06': 'isolated_test',
}


def invalidate_evidence_cache() -> None:
    latest_evidence_dir.cache_clear()
    invalidate_revision_cache()


def _rel(root: Path, path: Path | None) -> str:
    if path is None:
        return ''
    try:
        return Path(path).resolve().relative_to(Path(root).resolve()).as_posix()
    except Exception:
        return str(path)


def _is_placeholder(value: Any) -> bool:
    if value is None:
        return True
    text = str(value).strip()
    if not text:
        return True
    upper = text.upper()
    return any(fragment in upper for fragment in PLACEHOLDER_FRAGMENTS)


def review_document_hashes(root: Path) -> dict[str, str]:
    root = Path(root).resolve()
    out: dict[str, str] = {}
    for rel in REVIEW_DOCUMENTS:
        path = root / rel
        if path.is_file():
            out[rel] = sha256_file(path)
    return out


def _parse_iso_utc(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return None

def _read_plain(path: Path) -> Any|None:
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception: return None


def _read_evidence(root: Path, path: Path) -> Any|None:
    try: return read_json(root,path,require_encrypted=True)
    except Exception: return None


def _manifest_valid(root: Path, run: Path, current_revision: str|None=None) -> tuple[bool,str,dict|None]:
    manifest_path=run/'run_manifest.json'
    manifest=_read_evidence(root,manifest_path)
    if not isinstance(manifest,dict): return False,'missing/decrypt-failed encrypted run manifest',None
    current_revision=current_revision or repo_revision(root)
    if manifest.get('revision') != current_revision: return False,'run manifest is for a different repository revision',manifest
    if manifest.get('run_id') != run.name: return False,'run manifest id does not match directory',manifest
    artifacts=manifest.get('artifacts',{})
    if not isinstance(artifacts,dict) or not artifacts: return False,'run manifest has no artifact inventory',manifest
    for name,expected in artifacts.items():
        target=run/name
        payload=_read_evidence(root,target)
        if payload is None: return False,f'artifact missing/decrypt-failed: {name}',manifest
        if not hmac.compare_digest(str(canonical_payload_hash(payload)), str(expected)): return False,f'artifact payload hash mismatch: {name}',manifest
        if isinstance(payload,dict) and payload.get('revision') not in (None,manifest.get('revision')):
            return False,f'artifact revision mismatch: {name}',manifest
    return True,'revision-bound encrypted evidence manifest verified',manifest


@lru_cache(maxsize=8)
def latest_evidence_dir(root: Path) -> Path|None:
    """Return the newest *valid current-revision* run, never lexical user input."""
    root=Path(root).resolve(); base=root/'quality_gate'/'evidence'
    if not base.is_dir(): return None
    current_revision=repo_revision(root)
    valid=[]
    for run in base.iterdir():
        if not run.is_dir(): continue
        ok,_why,manifest=_manifest_valid(root,run,current_revision)
        if ok and manifest and manifest.get('evaluation_passed') is True:
            created=_parse_iso_utc(str(manifest.get('created_at','')))
            if created is None: continue
            valid.append((created,run))
    return max(valid,key=lambda x:x[0])[1] if valid else None


def _current_artifact(root: Path,name: str):
    run=latest_evidence_dir(root)
    if not run: return None,None
    target=run/name
    return target,_read_evidence(root,target)


def _v_guardrails(root:Path):
    target,data=_current_artifact(root,'adversarial_results.json')
    if target is None or not isinstance(data,dict): return INDETERMINATE,'no valid current-revision adversarial evidence',()
    cases=data.get('cases',[])
    if not cases: return INDETERMINATE,'adversarial artifact contains no cases',(str(target),)
    failed=[c.get('id','?') for c in cases if not c.get('blocked')]
    if failed: return BLOCKED,f"guardrail not enforced for: {', '.join(failed)}",(str(target),)
    return PASS,f'{len(cases)} adversarial cases blocked by enforced controls',(str(target),)


def _v_evaluation(root:Path):
    target,data=_current_artifact(root,'offline_evaluation.json')
    if target is None or not isinstance(data,dict): return INDETERMINATE,'no valid current-revision offline evaluation evidence',()
    corpus=data.get('corpus',{})
    if not data.get('measured') or not corpus.get('name') or not corpus.get('case_count'):
        return INDETERMINATE,'evaluation did not measure a named corpus',(str(target),)
    fp=data.get('false_positive_rate'); grounding=data.get('grounding_rate')
    if fp is None or grounding is None: return INDETERMINATE,'evaluation rates are absent',(str(target),)
    thresholds=_read_plain(root/'quality_gate'/'config'/'thresholds.json') or {}; q=thresholds.get('quality',{})
    max_fp=q.get('maximum_false_positive_rate',0.05); min_grounding=q.get('minimum_grounding_rate',0.98)
    if not data.get('guardrails_fail_closed',False): return BLOCKED,'offline guardrail behavior did not fail closed',(str(target),)
    if fp>max_fp or grounding<min_grounding:
        return BLOCKED,f'grounding {grounding} / false-positive {fp} outside policy thresholds',(str(target),)
    return PASS,f"grounding {grounding}, false-positive {fp} over {corpus['case_count']} corpus cases",(str(target),)


def _open_write_mode(node:ast.Call,label:str):
    mode=None
    if len(node.args)>=2 and isinstance(node.args[1],ast.Constant): mode=node.args[1].value
    for kw in node.keywords:
        if kw.arg=='mode' and isinstance(kw.value,ast.Constant): mode=kw.value.value
    return [f'{label}(mode={mode!r})'] if isinstance(mode,str) and any(c in mode for c in _WRITE_MODES) else []


def _module_writes(source:str):
    try: tree=ast.parse(source)
    except SyntaxError: return ['<unparseable>']
    found=[]
    for node in ast.walk(tree):
        if not isinstance(node,ast.Call): continue
        f=node.func
        if isinstance(f,ast.Attribute):
            if f.attr in _WRITE_ATTRS: found.append(f.attr)
            elif f.attr=='replace' and isinstance(f.value,ast.Name) and f.value.id=='os': found.append('os.replace')
            elif f.attr=='open': found.extend(_open_write_mode(node,'open'))
        elif isinstance(f,ast.Name):
            if f.id in _WRITE_ATTRS: found.append(f.id)
            elif f.id=='open': found.extend(_open_write_mode(node,'open'))
    return sorted(set(found))


def _scratch_only_ok(source:str):
    try: tree=ast.parse(source)
    except SyntaxError: return False,'unparseable'
    imports=any((isinstance(n,ast.Import) and any(a.name=='tempfile' for a in n.names)) or (isinstance(n,ast.ImportFrom) and n.module=='tempfile') for n in ast.walk(tree))
    uses=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='TemporaryDirectory' for n in ast.walk(tree))
    if not imports or not uses: return False,'does not establish TemporaryDirectory scratch'
    for node in tree.body:
        if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            if _module_writes(ast.unparse(node)): return False,'performs a write at module scope'
    return True,'writes confined to TemporaryDirectory scratch'


def _v_no_hidden_write_authority(root:Path):
    pkg=root/'embedded_quality_gate'
    if not pkg.is_dir(): return INDETERMINATE,'package directory not found',()
    offenders=[]; scratch=[]
    for py in sorted(pkg.glob('*.py')):
        if py.name in WRITE_AUTHORIZED_MODULES or py.name in VENDORED_MODULES: continue
        source=py.read_text(encoding='utf-8',errors='replace'); writes=_module_writes(source)
        if not writes: continue
        if py.name in SCRATCH_ONLY_MODULES:
            ok,why=_scratch_only_ok(source); (scratch if ok else offenders).append(f'{py.name} ({why})'); continue
        offenders.append(f"{py.name} ({', '.join(writes)})")
    if offenders: return BLOCKED,f"write calls outside authorised modules: {'; '.join(offenders)}",(str(pkg),)
    return PASS,f'AST scan of {len(list(pkg.glob("*.py")))} modules found no repository writes outside the authorised set; {len(scratch)} scratch harness(es) qualified',(str(pkg),)


def _split_refs(value:str): return [x.strip() for x in (value or '').split(';') if x.strip()]


def _v_traceable_outputs(root:Path):
    matrix=root/'quality_gate'/'traceability'/'TRACEABILITY_MATRIX_APPLIED.csv'
    closeout=root/'quality_gate'/'traceability'/'REQUIREMENT_CLOSEOUT.csv'
    if not matrix.exists() or not closeout.exists(): return INDETERMINATE,'traceability/closeout artifacts are incomplete',()
    try:
        with matrix.open(encoding='utf-8') as mh:
            rows=list(csv.DictReader(mh))
        with closeout.open(encoding='utf-8') as ch:
            closed=list(csv.DictReader(ch))
    except Exception as exc: return BLOCKED,f'traceability CSV unreadable: {exc}',(str(matrix),)
    if not rows: return INDETERMINATE,'traceability matrix is empty',(str(matrix),)
    parents=[r for r in rows if r.get('kind')=='parent_requirement']
    audit=[r for r in rows if r.get('kind')=='audit_addition']
    if len(parents)!=197 or len(audit)!=12:
        return BLOCKED,f'traceability census mismatch: {len(parents)} source parents / {len(audit)} audit additions',(str(matrix),)
    missing_fields=[r.get('trace_id','?') for r in rows if not r.get('status') or not r.get('owner') or not _split_refs(r.get('target_artifacts','')) or not _split_refs(r.get('verification','')) or not _split_refs(r.get('evidence_refs',''))]
    if missing_fields: return BLOCKED,f'{len(missing_fields)} traceability rows lack owner/artifact/verification/evidence fields',(str(matrix),)
    missing_paths=[]
    for r in rows:
        for field in ('target_artifacts','verification','evidence_refs','approval_refs'):
            for ref in _split_refs(r.get(field,'')):
                if '*' in ref:
                    matches=list(root.glob(ref)) if not ref.startswith('/') else []
                    if not matches:
                        missing_paths.append(f"{r.get('trace_id')}:{ref}")
                    continue
                if not (root/ref).exists(): missing_paths.append(f"{r.get('trace_id')}:{ref}")
    if missing_paths: return BLOCKED,f'{len(missing_paths)} referenced artifacts do not exist',(str(matrix),)
    parent_status={r['trace_id']:r['status'] for r in parents}
    close_status={r.get('requirement_id'):r.get('status') for r in closed}
    mismatches=[rid for rid,st in parent_status.items() if close_status.get(rid)!=st]
    if mismatches: return BLOCKED,f'{len(mismatches)} parent statuses disagree with REQUIREMENT_CLOSEOUT.csv',(str(matrix),str(closeout))
    run=latest_evidence_dir(root)
    if run is None: return INDETERMINATE,'traceability is present but no valid current-revision evidence run binds it to this build',(str(matrix),)
    return PASS,f'{len(rows)} traceability rows validated; 197 source obligations are census-complete and a current-revision encrypted evidence run is present',(str(matrix),str(closeout),str(run/'run_manifest.json'))


def _v_bypass_tests(root:Path):
    target,data=_current_artifact(root,'adversarial_results.json')
    if target is None or not isinstance(data,dict): return INDETERMINATE,'no valid current-revision adversarial evidence',()
    cases={c.get('id'):c for c in data.get('cases',[])}; required={'TEST-ADV-04','TEST-ADV-07'}
    missing=sorted(x for x in required if x not in cases)
    failed=sorted(x for x in required if x in cases and not cases[x].get('blocked'))
    if missing or failed: return BLOCKED,f'bypass cases missing/failed: {missing+failed}',(str(target),)
    return PASS,'approval-bypass and unauthorized-write cases exercised and blocked',(str(target),)


def _v_rollback(root:Path):
    target,data=_current_artifact(root,'e2e_results.json')
    if target is None or not isinstance(data,dict): return INDETERMINATE,'no valid current-revision E2E evidence',()
    scenarios={c.get('id'):c for c in data.get('scenarios',[])}; rb=scenarios.get('TEST-E2E-06')
    if not rb: return BLOCKED,'rollback/abort scenario was not exercised',(str(target),)
    if not rb.get('passed'): return BLOCKED,f"rollback scenario failed: {rb.get('detail','')}",(str(target),)
    return PASS,'rollback/abort exercised end to end',(str(target),)


def _v_security_review(root:Path):
    sig=root/'quality_gate'/'approvals'/'security_privacy_review.json'
    if not sig.exists(): return BLOCKED,'no named human security/privacy review sign-off is recorded',()
    data=_read_plain(sig) or {}
    required=('reviewer','reviewer_role','decision','reviewed_revision','reviewed_at','scope')
    if any(not data.get(k) for k in required) or data.get('decision')!='APPROVED':
        return BLOCKED,'security/privacy review is incomplete or not approved',(_rel(root,sig),)
    if data.get('template') is True: return BLOCKED,'security/privacy template is not a human approval',(_rel(root,sig),)
    if any(_is_placeholder(data.get(k)) for k in required):
        return BLOCKED,'security/privacy review still contains template placeholder values',(_rel(root,sig),)
    reviewer=str(data.get('reviewer','')).strip()
    if reviewer.lower() in MODEL_REVIEWER_NAMES or 'replace' in reviewer.lower():
        return BLOCKED,'security/privacy reviewer identity is a placeholder or model identity',(_rel(root,sig),)
    role=str(data.get('reviewer_role','')).strip()
    if role not in ALLOWED_REVIEWER_ROLES:
        return BLOCKED,f'security/privacy reviewer_role {role!r} is not an allowed human review role',(_rel(root,sig),)
    when=_parse_iso_utc(str(data.get('reviewed_at','')))
    if when is None:
        return BLOCKED,'security/privacy reviewed_at is not a valid ISO-8601 timestamp',(_rel(root,sig),)
    now=datetime.now(timezone.utc)
    if when > now:
        return BLOCKED,'security/privacy reviewed_at is in the future',(_rel(root,sig),)
    if (now - when).days > 90:
        return BLOCKED,'security/privacy review is older than 90 days',(_rel(root,sig),)
    if data.get('reviewed_revision') != repo_revision(root):
        return BLOCKED,'security/privacy approval is stale: reviewed_revision does not match current repository',(_rel(root,sig),)
    refs=data.get('evidence_refs') or []
    if not isinstance(refs,list) or not refs:
        return BLOCKED,'security/privacy review has no evidence_refs',(_rel(root,sig),)
    missing=[ref for ref in refs if isinstance(ref,str) and not _is_placeholder(ref) and not str(ref).startswith(('http://','https://')) and not (root/ref).exists()]
    if missing:
        return BLOCKED,f'security/privacy evidence_refs do not exist: {missing[:4]}',(_rel(root,sig),)
    if all(_is_placeholder(ref) or not str(ref).strip() for ref in refs):
        return BLOCKED,'security/privacy evidence_refs are placeholders',(_rel(root,sig),)
    expected=review_document_hashes(root)
    recorded=data.get('reviewed_document_hashes')
    if not isinstance(recorded,dict) or not recorded:
        return BLOCKED,'security/privacy review is not bound to hashes of the load-bearing review documents',(_rel(root,sig),)
    mismatches=[rel for rel,digest in expected.items() if recorded.get(rel)!=digest]
    if mismatches:
        return BLOCKED,f'security/privacy document hashes are stale: {mismatches}',(_rel(root,sig),)
    return PASS,f"security/privacy review approved by {data['reviewer']} for the current revision",(_rel(root,sig),)


def _v_limitations(root:Path):
    doc=root/'quality_gate'/'docs'/'KNOWN_LIMITATIONS_NON_GOALS.md'
    if not doc.exists(): return BLOCKED,'known limitations and non-goals are not published',()
    if len(doc.read_text(encoding='utf-8').strip())<200: return BLOCKED,'limitations document is a stub',(str(doc),)
    return PASS,'limitations and non-goals published',(str(doc),)

VERIFIERS:dict[str,Callable[[Path],tuple[str,str,tuple[str,...]]]]={
 'guardrails_enforced':_v_guardrails,'evaluation_thresholds':_v_evaluation,
 'no_hidden_write_authority':_v_no_hidden_write_authority,'traceable_outputs':_v_traceable_outputs,
 'human_gate_bypass_tests':_v_bypass_tests,'rollback_exercised':_v_rollback,
 'security_privacy_review':_v_security_review,'limitations_published':_v_limitations,
}


def evaluate_readiness(facts:dict|None=None,root:Path|None=None):
    facts=facts or {}; out=[]
    for name,verify in VERIFIERS.items():
        if root is None: out.append(GateResult(name,INDETERMINATE,'no repository root supplied; readiness cannot be verified from facts alone')); continue
        status,reason,evidence=verify(Path(root).resolve())
        if status==PASS and name in facts and not facts[name]: status,reason=BLOCKED,f'verified, but caller asserted {name} is not satisfied'
        out.append(GateResult(name,status,reason,evidence))
    return out


def _qualification(root:Path, item_id:str, filename:str, *, allow_na:bool=False, current_revision:str|None=None):
    path=root/'quality_gate'/'environments'/filename
    rel=_rel(root,path)
    if not path.exists(): return GateResult(item_id,INDETERMINATE if item_id=='DEPLOY-02' else BLOCKED,f'no qualification record: {rel or filename}')
    data=_read_plain(path) or {}
    if data.get('template') is True: return GateResult(item_id,INDETERMINATE if item_id=='DEPLOY-02' else BLOCKED,'qualification template has not been completed',(rel,))
    current_revision=current_revision or repo_revision(root)
    status=data.get('status')
    if status=='NOT_APPLICABLE':
        if not allow_na:
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE is not accepted for this environment',(rel,))
        if _is_placeholder(data.get('approved_by')) or _is_placeholder(data.get('reason')):
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE disposition is a placeholder',(rel,))
        if data.get('revision') not in (None, current_revision) and data.get('revision') != current_revision:
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE qualification is stale for the current repository revision',(rel,))
        if data.get('revision') and data.get('revision') != current_revision:
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE qualification is stale for the current repository revision',(rel,))
        # N/A still has to name the current revision so a leftover disposition cannot outlive the code.
        if data.get('revision') != current_revision:
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE qualification must name the current repository revision',(rel,))
        if str(data.get('approved_by','')).strip().lower() in MODEL_REVIEWER_NAMES:
            return GateResult(item_id,BLOCKED,'NOT_APPLICABLE approved_by is a model identity',(rel,))
        return GateResult(item_id,PASS,'explicit human-approved not-applicable disposition',(rel,))
    if status!='PASS': return GateResult(item_id,BLOCKED,f"environment qualification status is {status or 'missing'}",(rel,))
    required=('environment','qualified_at','qualified_by','revision','smoke_pass','security_pass','rollback_pass','credentials_boundary','data_boundary')
    if any(data.get(k) in (None,'') for k in required): return GateResult(item_id,BLOCKED,'qualification record lacks required fields',(rel,))
    if any(_is_placeholder(data.get(k)) for k in ('environment','qualified_at','qualified_by','revision','credentials_boundary','data_boundary')):
        return GateResult(item_id,BLOCKED,'qualification record still contains template placeholder values',(rel,))
    expected_env=QUALIFICATION_ENVIRONMENTS.get(item_id)
    if expected_env and data.get('environment') != expected_env:
        return GateResult(item_id,BLOCKED,f"qualification environment {data.get('environment')!r} does not match {expected_env}",(rel,))
    when=_parse_iso_utc(str(data.get('qualified_at','')))
    if when is None:
        return GateResult(item_id,BLOCKED,'qualified_at is not a valid ISO-8601 timestamp',(rel,))
    if when > datetime.now(timezone.utc):
        return GateResult(item_id,BLOCKED,'qualified_at is in the future',(rel,))
    if data.get('revision') != current_revision: return GateResult(item_id,BLOCKED,'qualification is stale for the current repository revision',(rel,))
    if not all(data.get(k) is True for k in ('smoke_pass','security_pass','rollback_pass')):
        return GateResult(item_id,BLOCKED,'smoke/security/rollback qualification did not all pass',(rel,))
    refs=data.get('evidence_refs') or []
    if not isinstance(refs,list) or not refs:
        return GateResult(item_id,BLOCKED,'qualification has no evidence_refs',(rel,))
    local_hits=0
    url_hits=0
    for ref in refs:
        if not isinstance(ref,str) or not ref.strip() or _is_placeholder(ref):
            continue
        if ref.startswith(('https://','http://')):
            url_hits += 1
            continue
        if (root/ref).exists():
            local_hits += 1
    if local_hits==0 and url_hits==0:
        return GateResult(item_id,BLOCKED,'qualification evidence_refs do not resolve to an existing local path or URL',(rel,))
    if local_hits==0 and latest_evidence_dir(root) is None:
        return GateResult(item_id,BLOCKED,'qualification cites only remote URLs and there is no current encrypted evidence run',(rel,))
    return GateResult(item_id,PASS,'environment qualification is current and complete',(rel,))


def evaluate_delivery_preconditions(root:Path):
    root=Path(root).resolve(); current_revision=repo_revision(root); results=[]
    run=latest_evidence_dir(root)
    pilot=(run/'pilot_results.json') if run else None
    data=_read_evidence(root,pilot) if pilot else None
    if isinstance(data,dict) and data.get('passed') and data.get('revision_before')==current_revision==data.get('revision_after'):
        results.append(GateResult('XEVAL-06',PASS,'read/draft-only pilot passed without repository mutation',(str(pilot),)))
    else:
        results.append(GateResult('XEVAL-06',BLOCKED,'no valid current-revision read/draft-only pilot evidence',(() if pilot is None else (str(pilot),))))
    # Developer/local sandbox is the host executing the current evidence run.
    if run: results.append(GateResult('DEPLOY-01',PASS,'developer/local sandbox qualified by current encrypted evaluation run',(str(run/'run_manifest.json'),)))
    else: results.append(GateResult('DEPLOY-01',INDETERMINATE,'no current local evaluation run'))
    results.extend([
        _qualification(root,'DEPLOY-02','ci_qualification.json',current_revision=current_revision),
        _qualification(root,'DEPLOY-03','staging_qualification.json',current_revision=current_revision),
        _qualification(root,'DEPLOY-04','production_readonly_qualification.json',allow_na=True,current_revision=current_revision),
        _qualification(root,'DEPLOY-05','privileged_path_qualification.json',allow_na=True,current_revision=current_revision),
        _qualification(root,'DEPLOY-06','isolated_test_qualification.json',current_revision=current_revision),
    ])
    return results


def promotion_allowed(gates,preconditions=None):
    """Promotion requires the READY set *and* delivery preconditions.

    Passing only READY verifier results is not enough: that was the v1.1 hole
    where local READY-01…08 could theoretically promote while DEPLOY gates were
    still open. Callers that omit preconditions cannot promote.
    """
    if preconditions is None:
        return False
    all_gates=list(gates)+list(preconditions)
    return bool(all_gates) and all(g.status==PASS for g in all_gates)
