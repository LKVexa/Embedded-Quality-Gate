from __future__ import annotations

import re

LEVELS=('public','internal','restricted','secret')
SECRET=re.compile(r'(?:-----BEGIN .*PRIVATE KEY-----|AKIA[0-9A-Z]{16}|(?i:password\s*[:=]\s*\S+)|(?i:token\s*[:=]\s*[A-Za-z0-9._-]{16,}))')
def classify_text(text:str,default='internal'):
 if SECRET.search(text): return 'secret'
 return default if default in LEVELS else 'restricted'
def can_export(classification:str,allowed_levels=('public','internal')):
 return classification in allowed_levels
