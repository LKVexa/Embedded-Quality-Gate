"""Repository-local read/draft-only pilot qualification.

This is deliberately not a staging or production qualification. It satisfies
XEVAL-06's requirement to exercise the gate under non-writing permissions and
produces evidence that the repository did not change during the pilot.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from .analyzers import analyze_repository
from .policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from .quality import summarize
from .repository import repo_revision


def _future(minutes: int=30) -> str:
    return (datetime.now(timezone.utc)+timedelta(minutes=minutes)).isoformat().replace('+00:00','Z')


def run_read_only_pilot(root: Path | str='.') -> dict:
    root=Path(root).resolve(); repo_id='eqg-pilot'
    before=repo_revision(root)
    policy=PolicyEngine(root,repo_id)
    ctx=AuthorityContext('pilot-agent','drafter',repo_id,frozenset({'read','analyze','draft'}),_future(),False,'',True)
    allowed=[]; denied=[]
    for action in ('read','analyze','draft'):
        try:
            policy.authorize(ctx,action,'.'); allowed.append(action)
        except AuthorizationDenied as exc:
            denied.append({'action':action,'reason':str(exc),'unexpected':True})
    for action in ('modify','commit','approve','deploy','communicate','execute'):
        try:
            policy.authorize(ctx,action,'.')
            denied.append({'action':action,'reason':'ALLOWED','unexpected':True})
        except AuthorizationDenied as exc:
            denied.append({'action':action,'reason':str(exc),'unexpected':False})
    analysis=analyze_repository(root)
    summary=summarize(analysis['findings'],analysis['checked_files'])
    after=repo_revision(root)
    unexpected=[d for d in denied if d['unexpected']]
    passed=(set(allowed)=={'read','analyze','draft'} and not unexpected and before==after and not summary['release_blocking'])
    return {
        'schema_version':'eqg.pilot/1.0',
        'mode':'repository_local_read_draft_only',
        'revision_before':before,'revision_after':after,'source_unchanged':before==after,
        'allowed_actions':allowed,'privileged_action_checks':denied,
        'analysis_summary':summary,'passed':passed,
        'qualification_scope':'XEVAL-06 only; does not qualify CI/staging/production environments',
    }
