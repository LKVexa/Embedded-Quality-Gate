"""The governed core workflow and its abort path.

Serves: FLOW-01…FLOW-11 as the linear states below, and FLOW-12 as the abort
transition available from any of them.

Previously `abort()` assigned a state that was not in `STEPS`, so the next
`advance()` raised `ValueError` from `STEPS.index()` rather than the package's
own `WorkflowError`, nothing was recorded, and an aborted run could be driven
onwards. `ABORTED` is now terminal, every refusal raises `WorkflowError`, and
the abort records a reason plus the state it aborted from.
"""
from __future__ import annotations

from dataclasses import dataclass, field

#: FLOW-01 … FLOW-11, in order. FLOW-12 is `abort()`, not a state.
STEPS: tuple[str, ...] = (
    "AUTHENTICATE",       # FLOW-01 authenticate and establish authority
    "PIN_SCOPE",          # FLOW-02 pin target artifacts and revisions
    "INGEST",             # FLOW-03 collect only authorized evidence
    "IMPACT",             # FLOW-04 normalize and index the evidence
    "DETERMINISTIC",      # FLOW-05 deterministic analysis first
    "SYNTHESIZE",         # FLOW-06 model reasoning over authorized context only
    "SUMMARIZE",          # FLOW-07 bounded draft / recommendation
    "VERIFY",             # FLOW-08 independent verification
    "REVIEW",             # FLOW-09 expose evidence and uncertainty to the human
    "DECIDE",             # FLOW-10 human decision before any state change
    "PERSIST",            # FLOW-11 record the evidence and decision trail
)

TERMINAL = "ABORTED"

#: Conditions that FLOW-12 recognises as grounds for a clean abort.
ABORT_REASONS = ("scope", "evidence", "authorization", "verification")


class WorkflowError(RuntimeError):
    """Raised for any refused transition. Never leaks a bare ValueError."""


@dataclass
class WorkflowRun:
    """A single governed run. Transitions forward one step at a time, or aborts."""

    state: str = "AUTHENTICATE"
    history: list[str] = field(default_factory=list)
    aborted_from: str | None = None
    abort_reason: str | None = None

    @property
    def is_terminal(self) -> bool:
        return self.state == TERMINAL

    def advance(self, next_state: str) -> str:
        """Move exactly one step forward; refuse anything else."""
        if self.is_terminal:
            raise WorkflowError(f"run is terminal ({TERMINAL}); no further transitions are permitted")
        if next_state not in STEPS:
            raise WorkflowError(f"unknown workflow state: {next_state!r}")
        cur = STEPS.index(self.state)
        nxt = STEPS.index(next_state)
        if nxt != cur + 1:
            raise WorkflowError(f"unsafe transition {self.state}->{next_state}")
        self.history.append(self.state)
        self.state = next_state
        return self.state

    def abort(self, reason: str, detail: str = "") -> dict[str, str]:
        """FLOW-12 — abort cleanly from any state and record why.

        Returns the record the caller must append to the provenance chain. The
        run becomes terminal; a second abort is refused so an abort record can
        never be overwritten by a later one.
        """
        if self.is_terminal:
            raise WorkflowError("run is already aborted")
        if reason not in ABORT_REASONS:
            raise WorkflowError(f"abort reason must be one of {ABORT_REASONS}, got {reason!r}")
        self.aborted_from = self.state
        self.abort_reason = reason
        self.history.append(f"ABORT:{self.state}:{reason}")
        self.state = TERMINAL
        return {
            "event": "workflow_aborted",
            "aborted_from": self.aborted_from,
            "reason": reason,
            "detail": detail,
            "completed_steps": ",".join(s for s in self.history if not s.startswith("ABORT:")),
        }

    def rollback(self, reason: str, detail: str = "") -> dict[str, str]:
        """Alias for :meth:`abort` in the vocabulary the source plan uses."""
        return self.abort(reason, detail)
