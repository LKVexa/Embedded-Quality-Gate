"""Backup and verified restore.

Serves: AUDIT-11 (backup/restore and disaster-recovery verification).

The previous module was two `shutil.copy2` calls with no verification, so a
restore that silently produced different bytes would have been reported as a
success. Every operation here compares SHA-256 before and after, and the
restore drill is a read-only rehearsal that never writes over live data.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from .util import sha256_file

#: Declared recovery objectives for the repository-local reference deployment.
RPO_MINUTES = 0     # backups are taken synchronously with the run that produces the data
RTO_MINUTES = 15    # restore is a file copy plus verification on the same host


class RestoreVerificationError(RuntimeError):
    """Raised when restored bytes do not match the bytes that were backed up."""


@dataclass(frozen=True)
class BackupRecord:
    source: str
    backup: str
    sha256: str
    bytes: int


def backup_file(src: Path, dst: Path) -> BackupRecord:
    """Copy `src` to `dst` and record the digest actually written."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    digest = sha256_file(dst)
    if digest != sha256_file(src):
        raise RestoreVerificationError(f"backup of {src} does not match its source")
    return BackupRecord(str(src), str(dst), digest, dst.stat().st_size)


def restore_file(backup: Path, dst: Path, expected_sha256: str | None = None) -> str:
    """Restore `backup` to `dst`, verifying the result before returning."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup, dst)
    digest = sha256_file(dst)
    if expected_sha256 and digest != expected_sha256:
        raise RestoreVerificationError(
            f"restored {dst} has digest {digest}, expected {expected_sha256}"
        )
    return digest


def restore_drill(record: BackupRecord, scratch_dir: Path) -> dict[str, object]:
    """Rehearse a restore into scratch space and report whether it verified.

    Non-destructive by construction: the live path is never written, so the
    drill can be run against production evidence without weakening the
    append-only guarantee.
    """
    scratch_dir.mkdir(parents=True, exist_ok=True)
    target = scratch_dir / (Path(record.backup).name + ".restored")
    try:
        digest = restore_file(Path(record.backup), target, record.sha256)
        verified, reason = True, ""
    except (RestoreVerificationError, OSError) as exc:
        digest, verified, reason = "", False, str(exc)
    return {
        "source": record.source,
        "verified": verified,
        "digest": digest,
        "reason": reason,
        "rpo_minutes": RPO_MINUTES,
        "rto_minutes": RTO_MINUTES,
        "destructive": False,
    }
