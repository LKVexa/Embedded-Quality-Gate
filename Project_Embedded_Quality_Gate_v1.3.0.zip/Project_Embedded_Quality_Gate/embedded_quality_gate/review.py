from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone

from .policy import AuthorityContext, AuthorizationDenied, PolicyEngine
from .util import stable_id, utc_now


@dataclass(frozen=True)
class Suggestion:
    author_identity:str; scope_id:str; content_hash:str; evidence_ids:tuple[str,...]; created_at:str
    @property
    def id(self): return stable_id('suggestion',asdict(self))

@dataclass(frozen=True)
class Approval:
    suggestion_id:str; approver_identity:str; scope_id:str; approved_at:str; expires_at:str
    @property
    def id(self): return stable_id('approval',asdict(self))

def _parse_time(value: str) -> datetime:
    try:
        return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone.utc)
    except Exception as exc:
        raise AuthorizationDenied('invalid approval expiry') from exc

def stage_suggestion(author_identity,scope_id,content_hash,evidence_ids):
    if not evidence_ids: raise ValueError('suggestion must be evidence-linked')
    return Suggestion(author_identity,scope_id,content_hash,tuple(evidence_ids),utc_now())

def approve_suggestion(suggestion, ctx:AuthorityContext, policy:PolicyEngine, expires_at:str):
    policy.authorize(ctx,'approve','.')
    if ctx.identity==suggestion.author_identity: raise AuthorizationDenied('self-approval prohibited')
    if ctx.approval_scope not in {suggestion.scope_id,'*'}: raise AuthorizationDenied('approval scope mismatch')
    requested=_parse_time(expires_at); authority_expiry=_parse_time(ctx.expires_at); now=datetime.now(timezone.utc)
    if requested <= now: raise AuthorizationDenied('approval expiry must be in the future')
    if requested > authority_expiry + timedelta(seconds=1): raise AuthorizationDenied('approval cannot outlive the approving authority')
    return Approval(suggestion.id,ctx.identity,suggestion.scope_id,utc_now(),expires_at)
