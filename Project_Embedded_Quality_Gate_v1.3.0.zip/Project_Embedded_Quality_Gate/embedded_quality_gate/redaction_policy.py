"""EQG redaction policy — extends the vendored redaction defaults.

Serves: XSEC (redacted structured logs), XOBS-01, TEST-ADV-05.

The gate's provenance is a SHA-256 hash chain that verifies over exact bytes.
Redacting a hash, revision, run id or evidence id would break chain
verification, so those join keys are declared as identifier keys and pass
through byte-identical. Everything else — including free-text fields that may
carry a pasted credential — is masked.
"""
from __future__ import annotations

from typing import Any

from .redaction import DEFAULT_ALLOWLIST, SECRET_NAME_WORDS, RedactionConfig, Redactor

#: Join keys whose exact bytes are load-bearing for hash-chain verification.
EQG_IDENTIFIER_KEYS: frozenset[str] = frozenset({
    "revision", "source_revision", "run_id", "scope_id", "authority_id",
    "evidence_id", "finding_id", "decision_id", "approval_id",
    "sha256", "hash", "prev_hash", "chain_hash", "content_hash", "digest",
})

#: Structural fields whose exact value must survive verbatim.
EQG_ALLOWLIST: frozenset[str] = DEFAULT_ALLOWLIST | frozenset({
    "fields.repository_id", "fields.schema_version", "fields.policy_version",
})

EQG_REDACTION_CONFIG = RedactionConfig(
    allowlist=EQG_ALLOWLIST,
    extra_identifier_keys=EQG_IDENTIFIER_KEYS,
)


def eqg_redactor() -> Redactor:
    """Return the gate's configured redactor."""
    return Redactor(EQG_REDACTION_CONFIG)


REDACTED = "[REDACTED:SECRET]"


_SECRET_WORDS: frozenset[str] = frozenset(SECRET_NAME_WORDS)

#: Field names that contain a secret-ish word but name metadata, not a secret.
#: A key *identifier* and a key *algorithm* are published parts of an envelope;
#: masking them would break decryption without protecting anything.
NON_SECRET_KEYS: frozenset[str] = frozenset({
    "key_id", "key_algorithm", "keyid", "key_material_path", "public_key_id",
    "authorization_model", "auth_action",
})


def _is_secret_key(key: object) -> bool:
    """True when a mapping key names a credential, whatever its value looks like."""
    if not isinstance(key, str):
        return False
    lowered = key.lower()
    if lowered in EQG_IDENTIFIER_KEYS or lowered in NON_SECRET_KEYS:
        return False
    parts = {p for p in lowered.replace("-", "_").split("_") if p}
    return bool(parts & _SECRET_WORDS) or lowered in _SECRET_WORDS


def scrub_record(value: Any, redactor: Redactor | None = None) -> Any:
    """Redact by key name *and* by value.

    The vendored library masks by value: it recognises credential shapes wherever
    they appear in text. That misses a field literally named ``password`` whose
    value is an unremarkable string, which the gate's previous key-name matcher
    did catch. Neither rule subsumes the other, so both run — key names first,
    then the value masker over what remains.
    """
    redactor = redactor or eqg_redactor()

    def walk(node: Any) -> Any:
        if isinstance(node, dict):
            return {k: (REDACTED if _is_secret_key(k) and not isinstance(node[k], (dict, list)) else walk(v))
                    for k, v in node.items()}
        if isinstance(node, list):
            return [walk(v) for v in node]
        return node

    return redactor.scrub(walk(value))
