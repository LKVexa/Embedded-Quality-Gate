"""Repository identity helpers shared by CLI and release verification."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from .util import canonical_json, sha256_bytes, sha256_file

# Generated closeout/release artifacts are excluded from the content revision so
# evidence can refer to a stable target revision without becoming self-referential.
GENERATED = {
    "QUALITY_GATE_APPLICATION_REPORT.md",
    "RELEASE_MANIFEST.json",
    "CHECKSUMS.sha256",
    "AUDIT_AND_REMEDIATION_v1.2.0.md",
    "AUDIT_AND_REMEDIATION_v1.3.0.md",
    "quality_gate/traceability/TRACEABILITY_MATRIX_APPLIED.csv",
    "quality_gate/traceability/REQUIREMENT_CLOSEOUT.csv",
    "quality_gate/traceability/PHASE_CLOSEOUT.csv",
    "quality_gate/traceability/PROGRAM_COMPLETION.yaml",
    "quality_gate/approvals/security_privacy_review.json",
    "quality_gate/environments/ci_qualification.json",
    "quality_gate/environments/staging_qualification.json",
    "quality_gate/environments/production_readonly_qualification.json",
    "quality_gate/environments/privileged_path_qualification.json",
    "quality_gate/environments/isolated_test_qualification.json",
}


#: Approval and qualification *requests* are generated from the current revision
#: and record it inside themselves. Counting them in the revision would make the
#: record self-referential: writing the request would change the revision the
#: request names.
GENERATED_REQUEST_DIRS = ("quality_gate/approvals/", "quality_gate/environments/")


def _is_generated(rel: str) -> bool:
    if rel in GENERATED:
        return True
    return rel.endswith(".request.json") and rel.startswith(GENERATED_REQUEST_DIRS)


@lru_cache(maxsize=8)
def repo_revision(root: Path) -> str:
    """Return a deterministic content hash for the repository under test."""
    root = Path(root).resolve()
    records: list[tuple[str, str]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        parts = path.parts
        if ".eqg_runtime" in parts or "__pycache__" in parts or ".git" in parts:
            continue
        if rel.startswith("quality_gate/evidence/") or _is_generated(rel):
            continue
        records.append((rel, sha256_file(path)))
    return sha256_bytes(canonical_json(records).encode("utf-8"))


def invalidate_revision_cache() -> None:
    repo_revision.cache_clear()
