from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .scope import ScopeViolation, confined_path
from .util import stable_id

READ_ACTIONS={'read','analyze','draft'}
PRIVILEGED_ACTIONS={'modify','commit','approve','deploy','communicate','execute'}
ALL_ACTIONS=READ_ACTIONS|PRIVILEGED_ACTIONS

# Safe fallback used for scratch fixtures and repositories without policy.json.
DEFAULT_ROLE_ACTIONS={
    'reader': {'read'},
    'analyst': {'read','analyze'},
    'assistant': {'read','analyze','draft'},
    'drafter': {'read','analyze','draft'},
    'human_reviewer': {'read','analyze','draft','approve'},
    'release_authority': {'read','analyze','draft','approve','deploy'},
    'repository_operator': {'read','analyze','draft','modify'},
    # maintenance-only fixture role retained for retention tests; it is still
    # subject to explicit human approval and repository confinement.
    'operator': {'execute'},
}

@dataclass(frozen=True)
class AuthorityContext:
    identity: str
    role: str
    repository_id: str
    actions: frozenset[str]
    expires_at: str
    human_approved: bool=False
    approval_scope: str=''
    synthetic_fixture: bool=False
    @property
    def id(self): return stable_id('authority',{
        'identity':self.identity,'role':self.role,'repository_id':self.repository_id,
        'actions':sorted(self.actions),'expires_at':self.expires_at,'human_approved':self.human_approved,
        'approval_scope':self.approval_scope,'synthetic_fixture':self.synthetic_fixture})

class AuthorizationDenied(PermissionError): pass

class PolicyEngine:
    """Default-deny, role-bound, exact-action, repository-confined policy engine.

    v1.1.0 trusted ``AuthorityContext.actions`` as the grant source.  A caller
    could therefore manufacture a context with a role that was never allowed a
    privileged action.  v1.2.0 intersects context actions with the repository's
    configured role grant so the context can only *narrow* authority, never
    create it.

    v1.3.0: an *existing but unreadable* policy.json fails closed (no roles)
    rather than falling back to the built-in map, which would widen a
    production policy that was more restrictive than the defaults.
    """
    def __init__(self, repository_root: Path, repository_id: str):
        self.root=repository_root.resolve(); self.repository_id=repository_id
        self.role_actions=self._load_role_actions()
    def _load_role_actions(self):
        cfg=self.root/'quality_gate'/'config'/'policy.json'
        if not cfg.exists():
            # Scratch fixtures without a quality_gate tree keep the built-in map.
            # A repository that already has quality_gate/config but no policy
            # file is a missing control, not a licence to widen to defaults.
            if (self.root/'quality_gate'/'config').is_dir():
                return {}
            return {k:set(v) for k,v in DEFAULT_ROLE_ACTIONS.items()}
        try:
            data=json.loads(cfg.read_text(encoding='utf-8'))
            perms=data.get('permissions',{})
            if not isinstance(perms,dict) or not perms:
                raise ValueError('permissions map missing or empty')
            return {str(role): set(map(str, actions)) for role,actions in perms.items()}
        except Exception:
            # Existing policy that cannot be parsed must not widen authority.
            return {}
    def _fresh(self, ctx: AuthorityContext) -> bool:
        try:
            t=datetime.fromisoformat(ctx.expires_at.replace('Z','+00:00'))
            return t.astimezone(timezone.utc) > datetime.now(timezone.utc)
        except Exception: return False
    def authorize(self, ctx: AuthorityContext|None, action: str, path: str='.') -> Path:
        if action not in ALL_ACTIONS: raise AuthorizationDenied(f'unknown action denied: {action}')
        if ctx is None: raise AuthorizationDenied('missing authority')
        if ctx.repository_id != self.repository_id: raise AuthorizationDenied('repository mismatch')
        if not self._fresh(ctx): raise AuthorizationDenied('expired or invalid authority')
        role_grants=self.role_actions.get(ctx.role)
        if role_grants is None: raise AuthorizationDenied(f'unknown role denied: {ctx.role}')
        if action not in ctx.actions: raise AuthorizationDenied(f'action not granted by authority context: {action}')
        if action not in role_grants: raise AuthorizationDenied(f'role {ctx.role} is not permitted to {action}')
        if action in PRIVILEGED_ACTIONS and not ctx.human_approved:
            raise AuthorizationDenied(f'explicit human approval required for {action}')
        if action == 'approve' and ctx.synthetic_fixture is False and ctx.role not in {'human_reviewer','release_authority'}:
            raise AuthorizationDenied('approval role required')
        try: return confined_path(self.root,path,allow_missing=action in {'draft','modify'})
        except ScopeViolation as e: raise AuthorizationDenied(str(e)) from e
