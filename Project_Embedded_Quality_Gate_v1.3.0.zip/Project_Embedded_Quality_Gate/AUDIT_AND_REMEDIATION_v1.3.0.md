# Embedded Quality Gate v1.2.0 → v1.3.0 Independent Audit and Remediation

**Audit date:** 2026-09-04  
**Target:** Embedded Quality Gate for Code and Tests  
**Input version:** 1.2.0 (audited-fixed package)  
**Remediated version:** 1.3.0  
**Disposition:** Local/reference implementation further repaired; production promotion remains fail-closed pending external qualification and a named human security/privacy approval. Model output did not create READY-07.

## Executive finding

v1.2.0 closed the worst v1.1.0 integrity holes (plaintext evidence writers, threshold exit-0, run-id traversal, role self-grant). Independent re-audit of the shipped v1.2.0 tree found that several remaining gates were still **file-droppable**: a three-boolean qualification JSON or a six-field READY-07 file was enough to open them, `DATA_GOVERNANCE.md` still contradicted the encryption implementation, allowlisted tools still resolved against a poisoned PATH, and the advertised pre-PR `gate` command did not analyze new-side diff content. Those are gate-integrity defects, not documentation nits.

v1.3.0 repairs those defects without lowering thresholds and without fabricating CI, staging, production, tenant, or human-review evidence.

## Final audited results on this host

| Check | Result |
|---|---|
| Unit/integration suite | **78/78 PASS** |
| Original corpus integrity | **612/612 intact** |
| Deterministic repository analysis | **PASS**, no release-blocking findings |
| Supported files deterministically checked | **629** |
| DMK references | **62/62 resolve** |
| Adversarial suite | **7/7 blocked** |
| End-to-end suite | **6/6 PASS** |
| Content-defense corpus | **125 cases** (50 attack / 75 benign) |
| Grounding / attack recall | **1.00** (threshold 0.98) |
| False-positive rate | **0.00** (maximum 0.05) |
| Read/draft-only pilot | **PASS**, repository hash unchanged |
| Protected run evidence | **Encrypted and decrypt/manifest verified** |
| Promotion | **DENIED / fail-closed**, as required |

## Problems parsed from v1.2.0 and fixed in v1.3.0

1. **Critical — remaining DEPLOY gates were file-droppable.** Qualification records did not check evidence_refs, placeholders, environment name, timestamps, or credential/data boundaries. A JSON file with three `true` booleans opened the gate. **Fix:** reject placeholders and model identities; require evidence_refs, environment match, ISO-8601 time, and boundaries; N/A must name the current revision.
2. **Critical — READY-07 was “file exists.”** Six non-empty strings and `decision=APPROVED` were enough. **Fix:** reject model identities and placeholders; allowlisted reviewer roles; ISO-8601 `reviewed_at` within 90 days; existing evidence_refs; SHA-256 binding to the five load-bearing review documents. Still a named-file human attestation, not PKI — and the model did not write the live approval.
3. **High — allowlisted tools resolved against ambient PATH.** `/tmp/python` on a poisoned PATH satisfied `python`. **Fix:** resolve against a trusted PATH (interpreter dir + `/usr/bin:/bin:/usr/local/bin`); child env uses that PATH.
4. **High — malformed or missing policy.json could widen authority.** Parse errors fell back to DEFAULT_ROLE_ACTIONS (including `operator: execute`). **Fix:** existing unreadable policy grants nothing; a repo that has `quality_gate/config` but no policy.json also grants nothing.
5. **High — `gate` ignored new-side diff content.** A syntax-error file that existed only in the patch returned PASS. **Fix:** reconstruct new-side text from hunks and run Python/JSON/DSL analysis plus content-defense on the impacted set. Missing reconstructed supported files BLOCK.
6. **High — binary, rename, and quoted git paths were dropped.** **Fix:** parse `Binary files`, `rename from/to`, `diff --git`, and C-quoted paths; strip BOM; map parse failures to BLOCKED.
7. **High — content defense was not on the operational path.** **Fix:** `run_diff_gate` scans impacted source/markdown (skipping the labelled corpus).
8. **Medium — `promotion_allowed` without delivery preconditions could theoretically promote READY-only.** **Fix:** omitting preconditions now returns false.
9. **Medium — latest evidence used lexical `created_at` and accepted failed evaluations.** **Fix:** parse ISO-8601; require `evaluation_passed`.
10. **Medium — DATA_GOVERNANCE.md still claimed 90-day retention and “no keys stored.”** **Fix:** rewritten to match the encryption/retention implementation.
11. **Medium — CI hardcoded smoke/security/rollback True.** **Fix:** workflow derives those bits from encrypted evaluate artifacts.
12. **Medium — protected writes minted keys; state allowed plaintext reads.** **Fix:** `create_key_if_missing` defaults false; protected state requires ciphertext.
13. **Medium — wrapping-key path could escape the repository.** **Fix:** confined to the repo.
14. **Medium — evidence writes were opt-in immutable.** **Fix:** `quality_gate/evidence/**` is exclusive-create; symlink chains are refused.
15. **Low — test-gap used substring association (`util` matched `utility`).** **Fix:** `test_<stem>` / `<stem>_test` only.
16. **Low — non-UTF-8 source was medium (not release-blocking).** **Fix:** encoding findings on supported code are high.

## Remaining gates and exactly how to open them

These remain closed **on purpose**. Opening them requires real environments or a named human. See `quality_gate/docs/GATE_OPENING_RUNBOOK.md`.

1. **DEPLOY-02 — CI (INDETERMINATE):** run `.github/workflows/validation.yml` on this revision; retain the emitted `ci_qualification.json` (derived from evaluate artifacts, not hardcoded) and encrypted evidence.
2. **DEPLOY-03 — staging (BLOCKED):** smoke, security/bypass, and rollback in an actual staging environment; complete `staging_qualification.json`.
3. **DEPLOY-04 — production read-only (BLOCKED):** qualify that integration, or a named human-approved `NOT_APPLICABLE` that names the **current** revision.
4. **DEPLOY-05 — privileged path (BLOCKED):** qualify a separately authorized path, or current-revision human-approved N/A.
5. **DEPLOY-06 — isolated tenant (BLOCKED):** exercise leakage, sensitive-output, retention/redaction, security, and rollback against an isolated test tenant.
6. **READY-07 — security/privacy review (BLOCKED):** a named human reviewer must complete `quality_gate/approvals/security_privacy_review.json` with document hashes. Model output cannot create this approval.

## Honesty remaining (not force-opened)

- READY-07 is still a named file, now bound to document hashes and identity checks. It is not an IdP signature.
- Traceability rows still cite historical v1.1 evidence paths; READY-04 verifies those files exist and that a current encrypted run is present, and no longer claims per-row current-run binding it does not have.
- Content-defense corpus recall is measured on BIPIA phrasing; the gate path now also scans diffs, but the labelled holdout is still that corpus.
- Local RSA wrapping key remains on the same host as ciphertext.

## Overall assessment

**Efficacy to the name:** v1.3.0 is an Embedded Quality Gate for Code and Tests in the local/reference sense: diff-scoped pre-PR analysis reconstructs and checks new-side code, deterministic checks run before promotion, evidence is encrypted and immutable, authority is role-bound and fail-closed, and promotion requires READY **and** delivery preconditions.

**Operability:** local analyze / gate / evaluate / readiness / pilot paths run and fail closed. Remaining closed gates are evidence obligations, not missing code paths.
